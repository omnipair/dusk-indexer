import { AnchorProvider, Program } from "@coral-xyz/anchor";
import {
  PublicKey,
  SystemProgram,
  Transaction,
  type AccountMeta,
  type TransactionInstruction,
} from "@solana/web3.js";

import { address, type AddressLike } from "./address.js";
import { deriveLeveragePositionAddress } from "./constants.js";
import { toBN } from "./governance.js";
import DELEGATE_IDL from "./idl_delegate.js";
import type { LeverageDelegate } from "./types_delegate.js";
import { getAssociatedTokenAddressSync, TOKEN_PROGRAM_ID } from "@solana/spl-token";
import { governanceIntegerBN } from "./governance.js";
import type { RawAmount } from "./write.js";

/** Hard-coded additional fee on successful built-in order execution. */
export const ORDER_PROTOCOL_FEE_BPS = 10n;

/** Net protocol fee in raw units, rounded up. Token-2022 transfer fees are additional. */
export function calculateOrderProtocolFee(executedValue: RawAmount): bigint {
  const value = BigInt(governanceIntegerBN(executedValue, "executedValue").toString());
  if (value < 0n || value > 0xffffffffffffffffn) throw new RangeError("executedValue must fit u64");
  return (value * ORDER_PROTOCOL_FEE_BPS + 9_999n) / 10_000n;
}

/** Supply under `protocolFee` when executing any built-in order. Create this
 * ATA if needed. Treasury comes from Dusk's canonical FutarchyAuthority.
 */
export function orderProtocolFeeAccounts(treasury: PublicKey, mint: PublicKey,
  tokenProgram = TOKEN_PROGRAM_ID) {
  return { feeRecipient: getAssociatedTokenAddressSync(mint, treasury, true, tokenProgram) };
}

export const LEVERAGE_DELEGATE_PROGRAM_ID = address(
  "AXNfmZt5e1UM4daeTzW3H7zNo4boobBcnFm8RzJYxvAv"
);

export type LeverageDelegateProgram = Program<LeverageDelegate>;

export function leverageDelegateIdl(
  programId: AddressLike = LEVERAGE_DELEGATE_PROGRAM_ID
): LeverageDelegate {
  const idl = JSON.parse(JSON.stringify(DELEGATE_IDL)) as LeverageDelegate;
  idl.address = address(programId).toBase58() as LeverageDelegate["address"];
  return idl;
}

export function createLeverageDelegateProgram(options: {
  provider: AnchorProvider;
  programId?: AddressLike;
}): LeverageDelegateProgram {
  return new Program<LeverageDelegate>(
    leverageDelegateIdl(options.programId),
    options.provider
  );
}

/**
 * Conditional order kinds.
 *
 * The program stores `kind` as an opaque u8 and does not define an enum for
 * it, so the meaning is a caller convention. These are the values the protocol
 * already uses; changing them silently reinterprets every existing order.
 */
export const LEVERAGE_ORDER_KIND = {
  takeProfit: 1,
  stopLoss: 2,
} as const;

export type LeverageOrderKind = keyof typeof LEVERAGE_ORDER_KIND;

const ORDER_SEED = Buffer.from("leverage_order");

/**
 * A conditional order's address.
 *
 * Keyed by position, owner and order id, so one position can carry several
 * orders and two owners cannot collide on the same id.
 */
export function deriveLeverageOrderAddress(
  leveragePosition: PublicKey,
  owner: PublicKey,
  orderId: bigint | number | string,
  programId: PublicKey = LEVERAGE_DELEGATE_PROGRAM_ID
): [PublicKey, number] {
  const id = Buffer.alloc(8);
  id.writeBigUInt64LE(BigInt(orderId));
  return PublicKey.findProgramAddressSync(
    [ORDER_SEED, leveragePosition.toBuffer(), owner.toBuffer(), id],
    programId
  );
}

export interface CreateLeverageOrderParams {
  market: AddressLike;
  owner: AddressLike;
  /** Identifies the leverage position the order acts on. */
  positionId: AddressLike;
  orderId: bigint | number | string;
  kind: LeverageOrderKind;
  /** Trigger price in NAD; the order closes out when it is crossed. */
  triggerCloseoutPriceNad: bigint | number | string;
  /** How much of the position to close, in basis points. */
  closeBps: number;
  leveragePosition?: AddressLike;
  order?: AddressLike;
  remainingAccounts?: AccountMeta[];
}

export interface CancelLeverageOrderParams {
  owner: AddressLike;
  orderId: bigint | number | string;
  /** Identifies the leverage position the order acts on. */
  positionId?: AddressLike;
  /** Required when `positionId` is not given. */
  market?: AddressLike;
  leveragePosition?: AddressLike;
  /** Supply the order address directly to skip derivation entirely. */
  order?: AddressLike;
}

/**
 * Conditional orders on leverage positions.
 *
 * These live in the delegate program rather than in Dusk itself, so they need
 * their own client. The position must already have delegated to this program
 * — see `buildCreateLeverageDelegationInstruction` — or the order has no
 * authority to act.
 */
export class DuskLeverageOrders {
  constructor(readonly program: LeverageDelegateProgram) {}

  async createOrderInstruction(
    params: CreateLeverageOrderParams
  ): Promise<TransactionInstruction> {
    const market = address(params.market);
    const owner = address(params.owner);
    const leveragePosition = address(
      params.leveragePosition ??
        deriveLeveragePositionAddress(market, address(params.positionId))[0]
    );

    if (!Number.isInteger(params.closeBps) || params.closeBps <= 0 || params.closeBps > 10_000) {
      throw new Error("Leverage order closeBps must be between 1 and 10000");
    }

    const order = address(
      params.order ??
        deriveLeverageOrderAddress(
          leveragePosition,
          owner,
          params.orderId,
          this.program.programId
        )[0]
    );

    return this.program.methods
      .createLeverageOrder({
        orderId: toBN(BigInt(params.orderId.toString())),
        kind: LEVERAGE_ORDER_KIND[params.kind],
        triggerCloseoutPriceNad: toBN(
          BigInt(params.triggerCloseoutPriceNad.toString())
        ),
        closeBps: params.closeBps,
      } as never)
      .accounts({
        market,
        leveragePosition,
        order,
        owner,
        systemProgram: SystemProgram.programId,
      } as never)
      .remainingAccounts(params.remainingAccounts ?? [])
      .instruction();
  }

  async createOrderTransaction(
    params: CreateLeverageOrderParams
  ): Promise<Transaction> {
    return new Transaction().add(await this.createOrderInstruction(params));
  }

  /**
   * Cancel a conditional order and return its rent to the owner.
   *
   * The program resolves the order's position from the account itself, so
   * cancelling needs neither the market nor the position — but the address
   * still has to be derived from them unless `order` is supplied.
   */
  async cancelOrderInstruction(
    params: CancelLeverageOrderParams
  ): Promise<TransactionInstruction> {
    const owner = address(params.owner);
    const order = address(params.order ?? this.resolveOrderAddress(params));

    return this.program.methods
      .cancelLeverageOrder({
        orderId: toBN(BigInt(params.orderId.toString())),
      } as never)
      .accounts({ order, owner } as never)
      .instruction();
  }

  async cancelOrderTransaction(
    params: CancelLeverageOrderParams
  ): Promise<Transaction> {
    return new Transaction().add(await this.cancelOrderInstruction(params));
  }

  private resolveOrderAddress(params: CancelLeverageOrderParams): PublicKey {
    const leveragePosition = params.leveragePosition
      ? address(params.leveragePosition)
      : (() => {
          if (!params.market || !params.positionId) {
            throw new Error(
              "Cancelling an order needs `order`, or `leveragePosition`, or both `market` and `positionId`"
            );
          }
          return deriveLeveragePositionAddress(
            address(params.market),
            address(params.positionId)
          )[0];
        })();
    return deriveLeverageOrderAddress(
      leveragePosition,
      address(params.owner),
      params.orderId,
      this.program.programId
    )[0];
  }
}
