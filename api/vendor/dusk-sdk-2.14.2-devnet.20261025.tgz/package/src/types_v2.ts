/**
 * Program IDL in camelCase format in order to be used in JS/TS.
 *
 * Note that this is only a type helper and is not the actual IDL. The original
 * IDL can be found at `target/idl/dusk.json`.
 */
export type Dusk = {
  "address": "JA8Zxxm4t4zopBL8e3dQQXWfQ3a5pBUPY9Sp9RnybV2X",
  "metadata": {
    "name": "dusk",
    "version": "2.0.0",
    "spec": "0.1.0",
    "description": "Dusk market architecture program for Omnipair V2"
  },
  "instructions": [
    {
      "name": "addLeverageMargin",
      "discriminator": [
        56,
        245,
        65,
        29,
        221,
        125,
        238,
        241
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "positionOwner"
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "debtInterestVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "owner",
          "docs": [
            "Token payer; need not own the leverage position."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "addLeverageMarginArgs"
            }
          }
        }
      ]
    },
    {
      "name": "addLiquidity",
      "discriminator": [
        181,
        157,
        89,
        67,
        143,
        182,
        52,
        72
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "ownerBaseAccount",
          "writable": true
        },
        {
          "name": "ownerQuoteAccount",
          "writable": true
        },
        {
          "name": "ownerYlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "docs": [
            "any liquidity mutation."
          ],
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "docs": [
            "any liquidity mutation."
          ],
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "addLiquidityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "beginFlashLiquidation",
      "discriminator": [
        18,
        242,
        47,
        42,
        203,
        45,
        98,
        252
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true,
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      109,
                      97,
                      114,
                      107,
                      101,
                      116,
                      95,
                      118,
                      50
                    ]
                  },
                  {
                    "kind": "account",
                    "path": "market.base_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.quote_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.params_hash",
                    "account": "market"
                  }
                ]
              }
            },
            {
              "name": "borrowPosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "leveragePosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "collateralMint"
            },
            {
              "name": "debtMint"
            },
            {
              "name": "collateralVault",
              "writable": true
            },
            {
              "name": "reserveVault",
              "writable": true
            },
            {
              "name": "interestVault",
              "writable": true
            },
            {
              "name": "insuranceVault",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "ownerDebtAccount",
              "writable": true
            },
            {
              "name": "futarchyAuthority",
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      102,
                      117,
                      116,
                      97,
                      114,
                      99,
                      104,
                      121,
                      95,
                      97,
                      117,
                      116,
                      104,
                      111,
                      114,
                      105,
                      116,
                      121
                    ]
                  }
                ]
              }
            },
            {
              "name": "referralPartner",
              "optional": true
            },
            {
              "name": "referralAccrual",
              "writable": true,
              "optional": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "debtTokenProgram"
            }
          ]
        },
        {
          "name": "session",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  105,
                  113,
                  117,
                  105,
                  100,
                  97,
                  116,
                  105,
                  111,
                  110,
                  45,
                  115,
                  101,
                  115,
                  115,
                  105,
                  111,
                  110
                ]
              },
              {
                "kind": "arg",
                "path": "args.position"
              }
            ]
          }
        },
        {
          "name": "repaymentVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  105,
                  113,
                  117,
                  105,
                  100,
                  97,
                  116,
                  105,
                  111,
                  110,
                  45,
                  112,
                  97,
                  121,
                  109,
                  101,
                  110,
                  116
                ]
              },
              {
                "kind": "arg",
                "path": "args.position"
              },
              {
                "kind": "account",
                "path": "accounts.debt_mint",
                "account": "flashLiquidationAccounts"
              }
            ]
          }
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "beginFlashLiquidationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "beginHlpFlash",
      "docs": [
        "Release hLP target collateral, bound to an exact top-level settlement",
        "later in this same transaction. No routing program is privileged."
      ],
      "discriminator": [
        41,
        207,
        247,
        103,
        180,
        58,
        131,
        13
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true
            },
            {
              "name": "futarchyAuthority"
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "targetMint"
            },
            {
              "name": "borrowedMint"
            },
            {
              "name": "targetReserve",
              "writable": true
            },
            {
              "name": "borrowedReserve",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "insuranceVault",
              "writable": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "borrowedTokenProgram"
            }
          ]
        },
        {
          "name": "session",
          "writable": true
        },
        {
          "name": "repaymentVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  45,
                  102,
                  108,
                  97,
                  115,
                  104,
                  45,
                  112,
                  97,
                  121,
                  109,
                  101,
                  110,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "session"
              }
            ]
          }
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "beginHlpFlashArgs"
            }
          }
        }
      ]
    },
    {
      "name": "borrow",
      "discriminator": [
        228,
        253,
        131,
        202,
        207,
        116,
        89,
        18
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "debtAssetMint"
        },
        {
          "name": "collateralAssetMint"
        },
        {
          "name": "reserveVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "optional": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "borrowArgs"
            }
          }
        }
      ]
    },
    {
      "name": "burnRetiredHlpReceipt",
      "discriminator": [
        186,
        145,
        76,
        141,
        32,
        30,
        63,
        95
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "retiredMint",
          "writable": true
        },
        {
          "name": "cohort",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  99,
                  111,
                  104,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "retiredMint"
              }
            ]
          }
        },
        {
          "name": "ownerHlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "burnRetiredHlpReceiptArgs"
            }
          }
        }
      ]
    },
    {
      "name": "claimReferralInterest",
      "discriminator": [
        16,
        89,
        1,
        198,
        140,
        72,
        89,
        13
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "referralPartner",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  112,
                  97,
                  114,
                  116,
                  110,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "authority"
              }
            ]
          }
        },
        {
          "name": "assetMint"
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  97,
                  99,
                  99,
                  114,
                  117,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "referralPartner"
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "assetMint"
              }
            ]
          }
        },
        {
          "name": "interestVault",
          "writable": true
        },
        {
          "name": "recipientTokenAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "closeInsolventHlp",
      "docs": [
        "Permissionlessly closes an hLP whose current-slot symmetric-EMA backing",
        "cannot cover funding debt. Native recovery uses EMA price, smoothed depth,",
        "concentration and configured fees. Recovery protects principal first;",
        "insurance covers only principal loss and unpaid interest is canceled.",
        "Realized funding interest is cash-limited and funds the bounded caller",
        "reward. Existing funded holder claims remain claimable after cleanup."
      ],
      "discriminator": [
        158,
        172,
        48,
        134,
        121,
        161,
        194,
        168
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "caller",
          "writable": true,
          "signer": true
        },
        {
          "name": "borrowedMint"
        },
        {
          "name": "borrowedReserveVault",
          "writable": true
        },
        {
          "name": "borrowedInterestVault",
          "writable": true
        },
        {
          "name": "insuranceVault",
          "writable": true
        },
        {
          "name": "callerBountyAccount",
          "writable": true
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "targetHlpYlpVault",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "closeInsolventHlpArgs"
            }
          }
        }
      ]
    },
    {
      "name": "closeLeverage",
      "discriminator": [
        45,
        157,
        207,
        176,
        194,
        6,
        218,
        253
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "positionOwner",
          "writable": true
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "debtInterestVault",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "delegateFeeRecipient",
          "docs": [
            "Protocol treasury token account for delegated close order fees."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "delegateExecutorAccount",
          "docs": [
            "Executor-owned token account for delegated close incentives."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "leverageDelegation",
          "optional": true
        },
        {
          "name": "delegatedProgram",
          "optional": true
        },
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "closeLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "closeLeverageDelegation",
      "discriminator": [
        252,
        151,
        253,
        52,
        242,
        118,
        104,
        109
      ],
      "accounts": [
        {
          "name": "leverageDelegation",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  100,
                  101,
                  108,
                  101,
                  103,
                  97,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "arg",
                "path": "args.position"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "closeLeverageDelegationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "configureReferralPartner",
      "discriminator": [
        36,
        179,
        42,
        204,
        66,
        161,
        198,
        254
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "referralPartner",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  112,
                  97,
                  114,
                  116,
                  110,
                  101,
                  114
                ]
              },
              {
                "kind": "arg",
                "path": "args.referrer"
              }
            ]
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "configureReferralPartnerArgs"
            }
          }
        }
      ]
    },
    {
      "name": "createGovernanceProposal",
      "discriminator": [
        102,
        90,
        114,
        133,
        147,
        63,
        113,
        168
      ],
      "accounts": [
        {
          "name": "proposer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "proposal",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  97,
                  114,
                  97,
                  109,
                  101,
                  116,
                  101,
                  114,
                  95,
                  112,
                  114,
                  111,
                  112,
                  111,
                  115,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "proposer"
              },
              {
                "kind": "arg",
                "path": "nonce"
              }
            ]
          }
        },
        {
          "name": "ylpMint"
        },
        {
          "name": "baseHlpYlpVault",
          "docs": [
            "Token-2022 yLP vault by the handler; an existing vault is fully parsed",
            "and validated before proposal state changes."
          ],
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  121,
                  108,
                  112,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "market.base_side.hlp_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "ylpMint"
              }
            ]
          }
        },
        {
          "name": "quoteHlpYlpVault",
          "docs": [
            "hLP yLP vault above."
          ],
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  121,
                  108,
                  112,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.hlp_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "ylpMint"
              }
            ]
          }
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "createGovernanceProposalArgs"
            }
          }
        }
      ]
    },
    {
      "name": "createLeverageDelegation",
      "discriminator": [
        189,
        154,
        156,
        116,
        213,
        249,
        107,
        163
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "leveragePosition",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "leverageDelegation",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  100,
                  101,
                  108,
                  101,
                  103,
                  97,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "createLeverageDelegationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "createParameterProposal",
      "discriminator": [
        124,
        27,
        59,
        125,
        164,
        214,
        56,
        132
      ],
      "accounts": [
        {
          "name": "proposer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "proposal",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  97,
                  114,
                  97,
                  109,
                  101,
                  116,
                  101,
                  114,
                  95,
                  112,
                  114,
                  111,
                  112,
                  111,
                  115,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "proposer"
              },
              {
                "kind": "arg",
                "path": "nonce"
              }
            ]
          }
        },
        {
          "name": "proposalSupport",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  114,
                  111,
                  112,
                  111,
                  115,
                  97,
                  108,
                  95,
                  115,
                  117,
                  112,
                  112,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "proposal"
              },
              {
                "kind": "account",
                "path": "proposer"
              }
            ]
          }
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "proposerYlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "baseHlpYlpVault",
          "docs": [
            "Token-2022 yLP vault by the handler; an existing vault is fully parsed",
            "and validated before proposal state changes."
          ],
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  121,
                  108,
                  112,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "market.base_side.hlp_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "ylpMint"
              }
            ]
          }
        },
        {
          "name": "quoteHlpYlpVault",
          "docs": [
            "hLP yLP vault above."
          ],
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  121,
                  108,
                  112,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.hlp_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "ylpMint"
              }
            ]
          }
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "createParameterProposalArgs"
            }
          }
        }
      ]
    },
    {
      "name": "decreaseLeverage",
      "discriminator": [
        177,
        163,
        187,
        72,
        82,
        174,
        68,
        229
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "positionOwner"
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "debtInterestVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "decreaseLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "delegatedCloseLeverage",
      "discriminator": [
        14,
        218,
        98,
        153,
        164,
        19,
        48,
        139
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "positionOwner",
          "writable": true
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "debtInterestVault",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "delegateFeeRecipient",
          "docs": [
            "Protocol treasury token account for delegated close order fees."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "delegateExecutorAccount",
          "docs": [
            "Executor-owned token account for delegated close incentives."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "leverageDelegation",
          "optional": true
        },
        {
          "name": "delegatedProgram",
          "optional": true
        },
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "delegatedCloseLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "depositCollateral",
      "discriminator": [
        156,
        131,
        142,
        116,
        146,
        247,
        162,
        120
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "collateralVault",
          "writable": true
        },
        {
          "name": "ownerAssetAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "owner"
              },
              {
                "kind": "arg",
                "path": "args.position_id"
              }
            ]
          }
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "depositCollateralArgs"
            }
          }
        }
      ]
    },
    {
      "name": "depositSingleSided",
      "discriminator": [
        5,
        14,
        149,
        170,
        183,
        103,
        225,
        105
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "targetHlpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "ownerTargetAccount",
          "writable": true
        },
        {
          "name": "ownerHlpAccount",
          "writable": true
        },
        {
          "name": "hlpYlpAccount",
          "docs": [
            "authority are all validated before any market mutation. A System-owned",
            "empty PDA is initialized inline by the deposit handler."
          ],
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "depositSingleSidedArgs"
            }
          }
        }
      ]
    },
    {
      "name": "donateCollateral",
      "docs": [
        "Adds the signer's tokens to an existing borrow position without granting",
        "the donor ownership or withdrawal rights. The recorded owner is unchanged."
      ],
      "discriminator": [
        237,
        234,
        205,
        84,
        177,
        106,
        198,
        38
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "collateralVault",
          "writable": true
        },
        {
          "name": "ownerAssetAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "donateCollateralArgs"
            }
          }
        }
      ]
    },
    {
      "name": "emergencyLiquidation",
      "discriminator": [
        24,
        95,
        118,
        136,
        77,
        194,
        44,
        247
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true,
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      109,
                      97,
                      114,
                      107,
                      101,
                      116,
                      95,
                      118,
                      50
                    ]
                  },
                  {
                    "kind": "account",
                    "path": "market.base_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.quote_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.params_hash",
                    "account": "market"
                  }
                ]
              }
            },
            {
              "name": "borrowPosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "leveragePosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "collateralMint"
            },
            {
              "name": "debtMint"
            },
            {
              "name": "collateralVault",
              "writable": true
            },
            {
              "name": "reserveVault",
              "writable": true
            },
            {
              "name": "interestVault",
              "writable": true
            },
            {
              "name": "insuranceVault",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "ownerDebtAccount",
              "writable": true
            },
            {
              "name": "futarchyAuthority",
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      102,
                      117,
                      116,
                      97,
                      114,
                      99,
                      104,
                      121,
                      95,
                      97,
                      117,
                      116,
                      104,
                      111,
                      114,
                      105,
                      116,
                      121
                    ]
                  }
                ]
              }
            },
            {
              "name": "referralPartner",
              "optional": true
            },
            {
              "name": "referralAccrual",
              "writable": true,
              "optional": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "debtTokenProgram"
            }
          ]
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "emergencyLiquidationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "executeParameterProposal",
      "discriminator": [
        46,
        106,
        112,
        113,
        40,
        255,
        154,
        27
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "proposal",
          "writable": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "fortifyMarket",
      "discriminator": [
        76,
        16,
        126,
        53,
        167,
        6,
        213,
        2
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "donor",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "donorAssetAccount",
          "writable": true
        },
        {
          "name": "insuranceVault",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "fortifyMarketArgs"
            }
          }
        }
      ]
    },
    {
      "name": "fundInterest",
      "docs": [
        "Fund accrued public LP interest from available cash, settle both hLP",
        "funding gaps from their new income, and publish remaining holder yield."
      ],
      "discriminator": [
        108,
        148,
        82,
        224,
        231,
        52,
        86,
        59
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "caller",
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "baseInterestVault",
          "writable": true
        },
        {
          "name": "quoteInterestVault",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "fundInterestArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "fundInterestReceipt"
        }
      }
    },
    {
      "name": "growYieldAccount",
      "docs": [
        "Bring a yield account created before `harvest_authority` existed up",
        "to the current size. Permissionless: it only appends zeroed bytes and",
        "the caller pays the rent for them."
      ],
      "discriminator": [
        203,
        157,
        168,
        219,
        59,
        246,
        255,
        134
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "yieldAccount",
          "docs": [
            "read this account, so a typed account here would fail the very case",
            "this instruction exists to repair."
          ],
          "writable": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": []
    },
    {
      "name": "harvest",
      "discriminator": [
        228,
        241,
        31,
        182,
        53,
        169,
        59,
        199
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "docs": [
            "LP holder identity. Its signature is not required when the designated",
            "recipient or harvest authority signs instead."
          ]
        },
        {
          "name": "caller",
          "docs": [
            "The LP holder, designated recipient, or harvest authority. Checked in validation."
          ],
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "lpMint"
        },
        {
          "name": "ownerLpAccount",
          "writable": true
        },
        {
          "name": "reserveVault",
          "writable": true
        },
        {
          "name": "interestVault",
          "writable": true
        },
        {
          "name": "recipientAssetAccount",
          "writable": true
        },
        {
          "name": "yieldAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "harvestArgs"
            }
          }
        }
      ]
    },
    {
      "name": "increaseLeverage",
      "discriminator": [
        61,
        30,
        86,
        173,
        5,
        127,
        12,
        160
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "positionOwner"
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "ownerDebtAccount",
          "docs": [
            "Required only when margin_amount is positive; always owned by the position owner."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "increaseLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "initFutarchyAuthority",
      "discriminator": [
        133,
        110,
        154,
        29,
        240,
        206,
        71,
        100
      ],
      "accounts": [
        {
          "name": "deployer",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "programData",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  254,
                  237,
                  118,
                  109,
                  5,
                  146,
                  245,
                  249,
                  66,
                  135,
                  243,
                  124,
                  36,
                  53,
                  12,
                  19,
                  89,
                  72,
                  84,
                  7,
                  236,
                  95,
                  227,
                  238,
                  53,
                  42,
                  79,
                  224,
                  225,
                  53,
                  141,
                  56
                ]
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                2,
                168,
                246,
                145,
                78,
                136,
                161,
                176,
                226,
                16,
                21,
                62,
                247,
                99,
                174,
                43,
                0,
                194,
                185,
                61,
                22,
                193,
                36,
                210,
                192,
                83,
                122,
                16,
                4,
                128,
                0,
                0
              ]
            }
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initFutarchyAuthorityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "initializeLpTransferHook",
      "discriminator": [
        207,
        57,
        218,
        104,
        179,
        156,
        22,
        196
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market"
        },
        {
          "name": "lpMint"
        },
        {
          "name": "validationAccount",
          "docs": [
            "against `lp_mint` and owned by Dusk after initialization."
          ],
          "writable": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": []
    },
    {
      "name": "initializeMarket",
      "discriminator": [
        35,
        35,
        189,
        193,
        155,
        48,
        170,
        203
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "baseHlpMint",
          "writable": true
        },
        {
          "name": "quoteHlpMint",
          "writable": true
        },
        {
          "name": "ylpTokenMetadata",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  101,
                  116,
                  97,
                  100,
                  97,
                  116,
                  97
                ]
              },
              {
                "kind": "const",
                "value": [
                  11,
                  112,
                  101,
                  177,
                  227,
                  209,
                  124,
                  69,
                  56,
                  157,
                  82,
                  127,
                  107,
                  4,
                  195,
                  205,
                  88,
                  184,
                  108,
                  115,
                  26,
                  160,
                  253,
                  181,
                  73,
                  182,
                  209,
                  188,
                  3,
                  248,
                  41,
                  70
                ]
              },
              {
                "kind": "account",
                "path": "ylpMint"
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                11,
                112,
                101,
                177,
                227,
                209,
                124,
                69,
                56,
                157,
                82,
                127,
                107,
                4,
                195,
                205,
                88,
                184,
                108,
                115,
                26,
                160,
                253,
                181,
                73,
                182,
                209,
                188,
                3,
                248,
                41,
                70
              ]
            }
          }
        },
        {
          "name": "baseHlpTokenMetadata",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  101,
                  116,
                  97,
                  100,
                  97,
                  116,
                  97
                ]
              },
              {
                "kind": "const",
                "value": [
                  11,
                  112,
                  101,
                  177,
                  227,
                  209,
                  124,
                  69,
                  56,
                  157,
                  82,
                  127,
                  107,
                  4,
                  195,
                  205,
                  88,
                  184,
                  108,
                  115,
                  26,
                  160,
                  253,
                  181,
                  73,
                  182,
                  209,
                  188,
                  3,
                  248,
                  41,
                  70
                ]
              },
              {
                "kind": "account",
                "path": "baseHlpMint"
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                11,
                112,
                101,
                177,
                227,
                209,
                124,
                69,
                56,
                157,
                82,
                127,
                107,
                4,
                195,
                205,
                88,
                184,
                108,
                115,
                26,
                160,
                253,
                181,
                73,
                182,
                209,
                188,
                3,
                248,
                41,
                70
              ]
            }
          }
        },
        {
          "name": "quoteHlpTokenMetadata",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  101,
                  116,
                  97,
                  100,
                  97,
                  116,
                  97
                ]
              },
              {
                "kind": "const",
                "value": [
                  11,
                  112,
                  101,
                  177,
                  227,
                  209,
                  124,
                  69,
                  56,
                  157,
                  82,
                  127,
                  107,
                  4,
                  195,
                  205,
                  88,
                  184,
                  108,
                  115,
                  26,
                  160,
                  253,
                  181,
                  73,
                  182,
                  209,
                  188,
                  3,
                  248,
                  41,
                  70
                ]
              },
              {
                "kind": "account",
                "path": "quoteHlpMint"
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                11,
                112,
                101,
                177,
                227,
                209,
                124,
                69,
                56,
                157,
                82,
                127,
                107,
                4,
                195,
                205,
                88,
                184,
                108,
                115,
                26,
                160,
                253,
                181,
                73,
                182,
                209,
                188,
                3,
                248,
                41,
                70
              ]
            }
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "baseMint"
              },
              {
                "kind": "account",
                "path": "quoteMint"
              },
              {
                "kind": "arg",
                "path": "args.params_hash"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "baseReserveVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  114,
                  101,
                  115,
                  101,
                  114,
                  118,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "baseMint"
              }
            ]
          }
        },
        {
          "name": "quoteReserveVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  114,
                  101,
                  115,
                  101,
                  114,
                  118,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "quoteMint"
              }
            ]
          }
        },
        {
          "name": "baseCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "baseMint"
              }
            ]
          }
        },
        {
          "name": "quoteCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "quoteMint"
              }
            ]
          }
        },
        {
          "name": "baseInsuranceVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  105,
                  110,
                  115,
                  117,
                  114,
                  97,
                  110,
                  99,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "baseMint"
              }
            ]
          }
        },
        {
          "name": "quoteInsuranceVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  105,
                  110,
                  115,
                  117,
                  114,
                  97,
                  110,
                  99,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "quoteMint"
              }
            ]
          }
        },
        {
          "name": "baseInterestVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  105,
                  110,
                  116,
                  101,
                  114,
                  101,
                  115,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "baseMint"
              }
            ]
          }
        },
        {
          "name": "quoteInterestVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  105,
                  110,
                  116,
                  101,
                  114,
                  101,
                  115,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "quoteMint"
              }
            ]
          }
        },
        {
          "name": "teamTreasury"
        },
        {
          "name": "teamTreasuryWsolAccount",
          "writable": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "sysvarInstructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenMetadataProgram",
          "address": "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initializeMarketArgs"
            }
          }
        }
      ]
    },
    {
      "name": "initializeReferralAccrual",
      "discriminator": [
        176,
        126,
        1,
        176,
        59,
        177,
        15,
        82
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "referralPartner",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  112,
                  97,
                  114,
                  116,
                  110,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "referral_partner.authority",
                "account": "referralPartner"
              }
            ]
          }
        },
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "assetMint"
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  97,
                  99,
                  99,
                  114,
                  117,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "referralPartner"
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "assetMint"
              }
            ]
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": []
    },
    {
      "name": "initializeYieldAccounts",
      "discriminator": [
        236,
        172,
        68,
        27,
        9,
        165,
        181,
        4
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "lpMint"
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initializeYieldAccountsArgs"
            }
          }
        }
      ]
    },
    {
      "name": "manageGovernanceBalance",
      "discriminator": [
        66,
        246,
        215,
        106,
        67,
        20,
        51,
        70
      ],
      "accounts": [
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "governanceBalance",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  103,
                  111,
                  118,
                  101,
                  114,
                  110,
                  97,
                  110,
                  99,
                  101,
                  95,
                  98,
                  97,
                  108,
                  97,
                  110,
                  99,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "owner"
              }
            ]
          }
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "ownerYlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "action",
          "type": {
            "defined": {
              "name": "governanceBalanceAction"
            }
          }
        }
      ]
    },
    {
      "name": "observeLiquidation",
      "discriminator": [
        142,
        159,
        189,
        212,
        245,
        60,
        54,
        113
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "optional": true
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "optional": true
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtMint"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "debtAsset",
          "type": "u8"
        }
      ],
      "returns": {
        "defined": {
          "name": "liquidationHealth"
        }
      }
    },
    {
      "name": "openLeverage",
      "discriminator": [
        182,
        198,
        96,
        61,
        133,
        28,
        41,
        16
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "payer",
          "docs": [
            "Pays account rent. Ordinary opens pass `owner` again; delegated opens",
            "use the keeper without transferring position ownership to it."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "leveragePosition",
          "docs": [
            "validated before any economic mutation."
          ],
          "writable": true
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "optional": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "openLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "openLiquidityGates",
      "docs": [
        "Permissionless launch adapters use the same fully-backed seeding path",
        "as ordinary yLP deposits. The initializer is the one-shot authority;",
        "after this succeeds, subsequent liquidity is permissionless."
      ],
      "discriminator": [
        84,
        83,
        110,
        45,
        185,
        4,
        186,
        222
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "ownerBaseAccount",
          "writable": true
        },
        {
          "name": "ownerQuoteAccount",
          "writable": true
        },
        {
          "name": "ownerYlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "docs": [
            "any liquidity mutation."
          ],
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "docs": [
            "any liquidity mutation."
          ],
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "addLiquidityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "previewAddLiquidity",
      "discriminator": [
        109,
        110,
        51,
        225,
        17,
        58,
        243,
        255
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewAddLiquidityArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "addLiquidityPreview"
        }
      }
    },
    {
      "name": "previewBorrowCapacity",
      "discriminator": [
        203,
        170,
        28,
        79,
        32,
        180,
        177,
        70
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "collateralAssetMint"
        },
        {
          "name": "debtAssetMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewBorrowCapacityArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "borrowCapacityPreview"
        }
      }
    },
    {
      "name": "previewBorrowPosition",
      "discriminator": [
        240,
        236,
        45,
        30,
        172,
        146,
        45,
        163
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "borrowPosition",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "baseMint",
          "docs": [
            "Liquidation values each side's collateral after its mint's current",
            "transfer fee, so the preview reads both mints."
          ]
        },
        {
          "name": "quoteMint"
        }
      ],
      "args": [],
      "returns": {
        "defined": {
          "name": "borrowPositionPreview"
        }
      }
    },
    {
      "name": "previewBorrowPositionCapacity",
      "discriminator": [
        117,
        63,
        148,
        138,
        201,
        37,
        189,
        1
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "borrowPosition",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "collateralAssetMint"
        },
        {
          "name": "debtAssetMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewBorrowPositionCapacityArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "borrowPositionCapacityPreview"
        }
      }
    },
    {
      "name": "previewEmergencyLiquidation",
      "discriminator": [
        75,
        200,
        66,
        0,
        112,
        230,
        24,
        56
      ],
      "accounts": [
        {
          "name": "preview",
          "accounts": [
            {
              "name": "market",
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      109,
                      97,
                      114,
                      107,
                      101,
                      116,
                      95,
                      118,
                      50
                    ]
                  },
                  {
                    "kind": "account",
                    "path": "market.base_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.quote_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.params_hash",
                    "account": "market"
                  }
                ]
              }
            },
            {
              "name": "borrowPosition",
              "optional": true
            },
            {
              "name": "leveragePosition",
              "optional": true
            },
            {
              "name": "collateralMint"
            },
            {
              "name": "debtMint"
            }
          ]
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewEmergencyLiquidationArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "emergencyLiquidationQuote"
        }
      }
    },
    {
      "name": "previewFlashLiquidation",
      "discriminator": [
        238,
        94,
        122,
        243,
        214,
        175,
        246,
        3
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "borrowPosition",
          "optional": true
        },
        {
          "name": "leveragePosition",
          "optional": true
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewFlashLiquidationArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "flashLiquidationQuote"
        }
      }
    },
    {
      "name": "previewHlpDepositCapacity",
      "discriminator": [
        183,
        4,
        20,
        188,
        148,
        193,
        129,
        195
      ],
      "accounts": [
        {
          "name": "market"
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "targetHlpMint"
        }
      ],
      "args": [],
      "returns": {
        "defined": {
          "name": "hlpDepositCapacityPreview"
        }
      }
    },
    {
      "name": "previewHlpFlash",
      "docs": [
        "Quote the fixed net payment for vault-wide atomic external hLP recovery."
      ],
      "discriminator": [
        26,
        164,
        118,
        84,
        231,
        86,
        157,
        176
      ],
      "accounts": [
        {
          "name": "market"
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "targetMint"
        },
        {
          "name": "borrowedMint"
        }
      ],
      "args": [
        {
          "name": "targetAsset",
          "type": "u8"
        }
      ],
      "returns": {
        "defined": {
          "name": "hlpFlashQuote"
        }
      }
    },
    {
      "name": "previewHlpOrderTrigger",
      "discriminator": [
        98,
        114,
        204,
        124,
        206,
        245,
        4,
        57
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewHlpOrderTriggerArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "hlpOrderTriggerPreview"
        }
      }
    },
    {
      "name": "previewMarket",
      "discriminator": [
        60,
        231,
        175,
        17,
        28,
        221,
        42,
        236
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        }
      ],
      "args": [],
      "returns": {
        "defined": {
          "name": "marketPreview"
        }
      }
    },
    {
      "name": "previewSwap",
      "discriminator": [
        98,
        74,
        197,
        115,
        135,
        154,
        188,
        70
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "assetInMint"
        },
        {
          "name": "assetOutMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewSwapArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "swapPreview"
        }
      }
    },
    {
      "name": "queueParameterProposal",
      "discriminator": [
        194,
        89,
        164,
        68,
        253,
        251,
        21,
        108
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "proposal",
          "writable": true
        },
        {
          "name": "ylpMint"
        },
        {
          "name": "baseHlpYlpVault"
        },
        {
          "name": "quoteHlpYlpVault"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "removeLiquidity",
      "discriminator": [
        80,
        85,
        209,
        72,
        24,
        206,
        177,
        108
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "ownerBaseAccount",
          "writable": true
        },
        {
          "name": "ownerQuoteAccount",
          "writable": true
        },
        {
          "name": "ownerYlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "removeLiquidityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "repay",
      "discriminator": [
        234,
        103,
        67,
        82,
        208,
        234,
        219,
        166
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "docs": [
            "Token payer; need not own the borrow position."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "debtAssetMint"
        },
        {
          "name": "collateralAssetMint"
        },
        {
          "name": "reserveVault",
          "writable": true
        },
        {
          "name": "interestVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "repayArgs"
            }
          }
        }
      ]
    },
    {
      "name": "repayLeverage",
      "docs": [
        "Repays leverage from the signer's tokens without quoting or selling collateral.",
        "The update event's closeout_value is zero (unquoted)."
      ],
      "discriminator": [
        155,
        110,
        230,
        251,
        39,
        169,
        47,
        22
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "positionOwner"
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "debtInterestVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "owner",
          "docs": [
            "Token payer; need not own the leverage position."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "addLeverageMarginArgs"
            }
          }
        }
      ]
    },
    {
      "name": "rotateHlpCohort",
      "discriminator": [
        163,
        66,
        186,
        91,
        40,
        131,
        194,
        235
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "oldHlpMint"
        },
        {
          "name": "newHlpMint",
          "writable": true
        },
        {
          "name": "oldCohort",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  99,
                  111,
                  104,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "oldHlpMint"
              }
            ]
          }
        },
        {
          "name": "newTokenMetadata",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  101,
                  116,
                  97,
                  100,
                  97,
                  116,
                  97
                ]
              },
              {
                "kind": "const",
                "value": [
                  11,
                  112,
                  101,
                  177,
                  227,
                  209,
                  124,
                  69,
                  56,
                  157,
                  82,
                  127,
                  107,
                  4,
                  195,
                  205,
                  88,
                  184,
                  108,
                  115,
                  26,
                  160,
                  253,
                  181,
                  73,
                  182,
                  209,
                  188,
                  3,
                  248,
                  41,
                  70
                ]
              },
              {
                "kind": "account",
                "path": "newHlpMint"
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                11,
                112,
                101,
                177,
                227,
                209,
                124,
                69,
                56,
                157,
                82,
                127,
                107,
                4,
                195,
                205,
                88,
                184,
                108,
                115,
                26,
                160,
                253,
                181,
                73,
                182,
                209,
                188,
                3,
                248,
                41,
                70
              ]
            }
          }
        },
        {
          "name": "sysvarInstructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "tokenMetadataProgram",
          "address": "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "rotateHlpCohortArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setGlobalReduceOnly",
      "discriminator": [
        242,
        151,
        123,
        139,
        239,
        87,
        249,
        98
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true,
          "address": "3YL87sTCrHMB6DYKorE9CCN4dL45kZPahoREcMLDY6QV"
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setGlobalReduceOnlyArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setGovernanceDelegate",
      "discriminator": [
        89,
        7,
        44,
        62,
        31,
        17,
        147,
        223
      ],
      "accounts": [
        {
          "name": "owner",
          "signer": true
        },
        {
          "name": "governanceBalance",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  103,
                  111,
                  118,
                  101,
                  114,
                  110,
                  97,
                  110,
                  99,
                  101,
                  95,
                  98,
                  97,
                  108,
                  97,
                  110,
                  99,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "governance_balance.market",
                "account": "governanceBalance"
              },
              {
                "kind": "account",
                "path": "owner"
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "delegate",
          "type": "pubkey"
        }
      ]
    },
    {
      "name": "setHarvestAuthority",
      "docs": [
        "Set or revoke a harvest caller independently of the yield recipient.",
        "Only the LP owner may update this authority; `None` revokes it."
      ],
      "discriminator": [
        59,
        181,
        149,
        163,
        99,
        148,
        106,
        133
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "lpMint"
        },
        {
          "name": "yieldAccount",
          "writable": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setHarvestAuthorityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setMarketReduceOnly",
      "discriminator": [
        178,
        78,
        219,
        198,
        188,
        185,
        181,
        88
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "authoritySigner",
          "signer": true,
          "address": "3YL87sTCrHMB6DYKorE9CCN4dL45kZPahoREcMLDY6QV"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setMarketReduceOnlyArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setReferralRecipient",
      "discriminator": [
        54,
        117,
        37,
        14,
        90,
        62,
        112,
        37
      ],
      "accounts": [
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "referralPartner",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  112,
                  97,
                  114,
                  116,
                  110,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "authority"
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setReferralRecipientArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setYieldRecipient",
      "discriminator": [
        178,
        211,
        80,
        10,
        138,
        52,
        188,
        22
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "lpMint"
        },
        {
          "name": "yieldAccount",
          "writable": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setYieldRecipientArgs"
            }
          }
        }
      ]
    },
    {
      "name": "settleFlashLiquidation",
      "discriminator": [
        161,
        93,
        89,
        56,
        133,
        124,
        79,
        20
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true,
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      109,
                      97,
                      114,
                      107,
                      101,
                      116,
                      95,
                      118,
                      50
                    ]
                  },
                  {
                    "kind": "account",
                    "path": "market.base_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.quote_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.params_hash",
                    "account": "market"
                  }
                ]
              }
            },
            {
              "name": "borrowPosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "leveragePosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "collateralMint"
            },
            {
              "name": "debtMint"
            },
            {
              "name": "collateralVault",
              "writable": true
            },
            {
              "name": "reserveVault",
              "writable": true
            },
            {
              "name": "interestVault",
              "writable": true
            },
            {
              "name": "insuranceVault",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "ownerDebtAccount",
              "writable": true
            },
            {
              "name": "futarchyAuthority",
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      102,
                      117,
                      116,
                      97,
                      114,
                      99,
                      104,
                      121,
                      95,
                      97,
                      117,
                      116,
                      104,
                      111,
                      114,
                      105,
                      116,
                      121
                    ]
                  }
                ]
              }
            },
            {
              "name": "referralPartner",
              "optional": true
            },
            {
              "name": "referralAccrual",
              "writable": true,
              "optional": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "debtTokenProgram"
            }
          ]
        },
        {
          "name": "session",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  105,
                  113,
                  117,
                  105,
                  100,
                  97,
                  116,
                  105,
                  111,
                  110,
                  45,
                  115,
                  101,
                  115,
                  115,
                  105,
                  111,
                  110
                ]
              },
              {
                "kind": "account",
                "path": "session.position",
                "account": "liquidationSession"
              }
            ]
          }
        },
        {
          "name": "repaymentVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "docs": [
            "Supplying the canonical opposite reserve selects direct Dusk execution",
            "with principal repayment netted inside the AMM settlement."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "settleHlpFlash",
      "docs": [
        "Verify the fixed payment and restore the vault's opposite-token hedge."
      ],
      "discriminator": [
        215,
        124,
        153,
        104,
        195,
        91,
        118,
        209
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true
            },
            {
              "name": "futarchyAuthority"
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "targetMint"
            },
            {
              "name": "borrowedMint"
            },
            {
              "name": "targetReserve",
              "writable": true
            },
            {
              "name": "borrowedReserve",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "insuranceVault",
              "writable": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "borrowedTokenProgram"
            }
          ]
        },
        {
          "name": "session",
          "writable": true
        },
        {
          "name": "repaymentVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  45,
                  102,
                  108,
                  97,
                  115,
                  104,
                  45,
                  112,
                  97,
                  121,
                  109,
                  101,
                  110,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "session"
              }
            ]
          }
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "settleProtocolAuction",
      "discriminator": [
        206,
        204,
        32,
        135,
        8,
        22,
        72,
        80
      ],
      "accounts": [
        {
          "name": "bidder",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "soldMint"
        },
        {
          "name": "acceptedMint"
        },
        {
          "name": "soldVault",
          "writable": true
        },
        {
          "name": "bidderPaymentAccount",
          "writable": true
        },
        {
          "name": "bidderReceiveAccount",
          "writable": true
        },
        {
          "name": "treasuryPaymentAccount",
          "writable": true
        },
        {
          "name": "stakingVaultPaymentAccount",
          "writable": true
        },
        {
          "name": "referenceMarket"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "settleProtocolAuctionArgs"
            }
          }
        }
      ]
    },
    {
      "name": "supportGovernanceProposal",
      "discriminator": [
        184,
        125,
        203,
        203,
        65,
        53,
        51,
        138
      ],
      "accounts": [
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "market"
        },
        {
          "name": "proposal",
          "writable": true
        },
        {
          "name": "ylpMint"
        },
        {
          "name": "baseHlpYlpVault"
        },
        {
          "name": "quoteHlpYlpVault"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "supportGovernanceProposalArgs"
            }
          }
        }
      ]
    },
    {
      "name": "supportParameterProposal",
      "discriminator": [
        151,
        82,
        42,
        209,
        219,
        155,
        3,
        9
      ],
      "accounts": [
        {
          "name": "supporter",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "proposal",
          "writable": true
        },
        {
          "name": "proposalSupport",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  114,
                  111,
                  112,
                  111,
                  115,
                  97,
                  108,
                  95,
                  115,
                  117,
                  112,
                  112,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "proposal"
              },
              {
                "kind": "account",
                "path": "supporter"
              }
            ]
          }
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "supporterYlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "baseHlpYlpVault"
        },
        {
          "name": "quoteHlpYlpVault"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "supportParameterProposalArgs"
            }
          }
        }
      ]
    },
    {
      "name": "swap",
      "discriminator": [
        248,
        198,
        158,
        145,
        225,
        117,
        135,
        200
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "trader",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetInMint"
        },
        {
          "name": "assetOutMint"
        },
        {
          "name": "reserveInVault",
          "writable": true
        },
        {
          "name": "reserveOutVault",
          "writable": true
        },
        {
          "name": "traderAssetInAccount",
          "writable": true
        },
        {
          "name": "traderAssetOutAccount",
          "writable": true
        },
        {
          "name": "instructionsSysvar",
          "docs": [
            "during the configured launch rate-limit window."
          ],
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "swapArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateFutarchyAuthority",
      "discriminator": [
        15,
        196,
        157,
        217,
        113,
        226,
        89,
        25
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateFutarchyAuthorityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateLeverageDelegation",
      "discriminator": [
        185,
        52,
        36,
        97,
        234,
        163,
        29,
        42
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "leveragePosition",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "leverageDelegation",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  100,
                  101,
                  108,
                  101,
                  103,
                  97,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateLeverageDelegationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateProtocolAuctionConfig",
      "discriminator": [
        4,
        202,
        113,
        194,
        208,
        122,
        212,
        73
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateProtocolAuctionConfigArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateProtocolAuctionRecipients",
      "discriminator": [
        210,
        210,
        94,
        83,
        188,
        14,
        38,
        247
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateProtocolAuctionRecipientsArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateProtocolAuctionRoute",
      "discriminator": [
        37,
        160,
        194,
        28,
        53,
        78,
        43,
        119
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateProtocolAuctionRouteArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateProtocolRevenue",
      "discriminator": [
        176,
        139,
        131,
        197,
        40,
        225,
        125,
        200
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateProtocolRevenueArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateRevenueRecipients",
      "discriminator": [
        116,
        179,
        137,
        47,
        118,
        167,
        65,
        217
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateRevenueRecipientsArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawAllCollateral",
      "docs": [
        "Sweeps both collateral balances and closes a debt-free borrow position.",
        "Balances are read during execution so prior dust donations cannot block closure."
      ],
      "discriminator": [
        37,
        185,
        159,
        214,
        37,
        30,
        163,
        146
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "baseCollateralVault",
          "writable": true
        },
        {
          "name": "quoteCollateralVault",
          "writable": true
        },
        {
          "name": "ownerBaseAccount",
          "writable": true
        },
        {
          "name": "ownerQuoteAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawAllCollateralArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawCollateral",
      "discriminator": [
        115,
        135,
        168,
        106,
        139,
        214,
        138,
        150
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "collateralVault",
          "writable": true
        },
        {
          "name": "ownerAssetAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawCollateralArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawGovernanceSupport",
      "discriminator": [
        37,
        252,
        250,
        121,
        81,
        152,
        252,
        36
      ],
      "accounts": [
        {
          "name": "authority",
          "signer": true
        },
        {
          "name": "market"
        },
        {
          "name": "proposal",
          "writable": true
        },
        {
          "name": "proposer",
          "writable": true
        },
        {
          "name": "governanceBalance",
          "writable": true
        },
        {
          "name": "governanceSupport",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  103,
                  111,
                  118,
                  101,
                  114,
                  110,
                  97,
                  110,
                  99,
                  101,
                  95,
                  115,
                  117,
                  112,
                  112,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "proposal"
              },
              {
                "kind": "account",
                "path": "governanceBalance"
              }
            ]
          }
        },
        {
          "name": "rentRefund",
          "writable": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawParameterSupportArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawParameterSupport",
      "discriminator": [
        249,
        15,
        97,
        20,
        2,
        64,
        146,
        172
      ],
      "accounts": [
        {
          "name": "supporter",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "proposal",
          "docs": [
            "than by Anchor: when its last supporter withdraws it shrinks to a",
            "`ParameterProposalTombstone`, which a typed account would overwrite with",
            "the full proposal on exit. `validate` checks its owner, discriminator,",
            "address and digest."
          ],
          "writable": true
        },
        {
          "name": "proposer",
          "docs": [
            "proposal in `validate`. Only receives lamports: the rent above the",
            "tombstone's own when the last supporter withdraws."
          ],
          "writable": true
        },
        {
          "name": "proposalSupport",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  112,
                  114,
                  111,
                  112,
                  111,
                  115,
                  97,
                  108,
                  95,
                  115,
                  117,
                  112,
                  112,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "proposal"
              },
              {
                "kind": "account",
                "path": "supporter"
              }
            ]
          }
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "supporterYlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawParameterSupportArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawRepaidLeverage",
      "docs": [
        "Returns all remaining collateral to its owner after full leverage repayment."
      ],
      "discriminator": [
        7,
        253,
        16,
        195,
        214,
        10,
        116,
        51
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "collateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "ownerCollateralAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawRepaidLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawSingleSided",
      "discriminator": [
        243,
        84,
        228,
        99,
        122,
        147,
        252,
        62
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "ylpMint",
          "writable": true
        },
        {
          "name": "targetHlpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "borrowedInterestVault",
          "writable": true
        },
        {
          "name": "ownerTargetAccount",
          "writable": true
        },
        {
          "name": "ownerHlpAccount",
          "writable": true
        },
        {
          "name": "hlpYlpAccount",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  121,
                  108,
                  112,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "targetHlpMint"
              },
              {
                "kind": "account",
                "path": "ylpMint"
              }
            ]
          }
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawSingleSidedArgs"
            }
          }
        }
      ]
    }
  ],
  "accounts": [
    {
      "name": "borrowPosition",
      "discriminator": [
        243,
        140,
        20,
        139,
        32,
        243,
        114,
        55
      ]
    },
    {
      "name": "futarchyAuthority",
      "discriminator": [
        175,
        247,
        160,
        182,
        140,
        128,
        211,
        226
      ]
    },
    {
      "name": "governanceBalance",
      "discriminator": [
        148,
        93,
        254,
        156,
        245,
        36,
        10,
        36
      ]
    },
    {
      "name": "governanceSupport",
      "discriminator": [
        84,
        179,
        42,
        253,
        18,
        3,
        167,
        120
      ]
    },
    {
      "name": "hlpCohort",
      "discriminator": [
        224,
        89,
        199,
        90,
        126,
        101,
        43,
        215
      ]
    },
    {
      "name": "hlpFlashSession",
      "discriminator": [
        212,
        216,
        161,
        138,
        241,
        116,
        166,
        126
      ]
    },
    {
      "name": "leverageDelegation",
      "discriminator": [
        49,
        60,
        29,
        23,
        243,
        219,
        16,
        214
      ]
    },
    {
      "name": "leveragePosition",
      "discriminator": [
        88,
        78,
        124,
        68,
        228,
        129,
        34,
        251
      ]
    },
    {
      "name": "liquidationSession",
      "discriminator": [
        198,
        19,
        76,
        58,
        102,
        166,
        134,
        164
      ]
    },
    {
      "name": "market",
      "discriminator": [
        219,
        190,
        213,
        55,
        0,
        227,
        198,
        154
      ]
    },
    {
      "name": "parameterProposal",
      "discriminator": [
        179,
        8,
        154,
        49,
        34,
        65,
        232,
        234
      ]
    },
    {
      "name": "proposalSupport",
      "discriminator": [
        207,
        134,
        77,
        36,
        67,
        63,
        132,
        148
      ]
    },
    {
      "name": "referralAccrual",
      "discriminator": [
        35,
        246,
        25,
        66,
        174,
        160,
        48,
        39
      ]
    },
    {
      "name": "referralPartner",
      "discriminator": [
        234,
        54,
        169,
        157,
        142,
        187,
        225,
        214
      ]
    },
    {
      "name": "yieldAccount",
      "discriminator": [
        233,
        241,
        119,
        6,
        2,
        14,
        106,
        156
      ]
    }
  ],
  "events": [
    {
      "name": "borrowInterestAccrued",
      "discriminator": [
        72,
        60,
        125,
        249,
        229,
        92,
        113,
        250
      ]
    },
    {
      "name": "borrowInterestPaid",
      "discriminator": [
        173,
        181,
        219,
        170,
        32,
        88,
        224,
        224
      ]
    },
    {
      "name": "borrowPositionLiquidated",
      "discriminator": [
        107,
        167,
        26,
        25,
        33,
        197,
        106,
        188
      ]
    },
    {
      "name": "debtFreePositionClosed",
      "discriminator": [
        220,
        198,
        224,
        150,
        204,
        65,
        184,
        31
      ]
    },
    {
      "name": "emergencyLiquidationSettled",
      "discriminator": [
        243,
        230,
        130,
        84,
        184,
        113,
        18,
        172
      ]
    },
    {
      "name": "flashLiquidationBegun",
      "discriminator": [
        198,
        250,
        117,
        184,
        74,
        48,
        48,
        151
      ]
    },
    {
      "name": "flashLiquidationSettled",
      "discriminator": [
        207,
        203,
        137,
        99,
        235,
        237,
        207,
        38
      ]
    },
    {
      "name": "governanceBalanceUpdated",
      "discriminator": [
        28,
        49,
        128,
        12,
        144,
        1,
        11,
        240
      ]
    },
    {
      "name": "governanceSupportChanged",
      "discriminator": [
        255,
        99,
        165,
        177,
        189,
        157,
        92,
        171
      ]
    },
    {
      "name": "harvestAuthorityUpdated",
      "discriminator": [
        232,
        18,
        21,
        9,
        229,
        230,
        173,
        86
      ]
    },
    {
      "name": "hlpClosed",
      "discriminator": [
        87,
        126,
        152,
        164,
        162,
        203,
        111,
        235
      ]
    },
    {
      "name": "hlpCohortRotated",
      "discriminator": [
        46,
        134,
        13,
        57,
        117,
        44,
        226,
        81
      ]
    },
    {
      "name": "hlpFlashSettled",
      "discriminator": [
        255,
        193,
        57,
        138,
        48,
        64,
        138,
        37
      ]
    },
    {
      "name": "hlpFlashStarted",
      "discriminator": [
        203,
        97,
        249,
        187,
        226,
        119,
        141,
        71
      ]
    },
    {
      "name": "hlpInterestAllocated",
      "discriminator": [
        12,
        174,
        16,
        115,
        243,
        133,
        131,
        49
      ]
    },
    {
      "name": "hlpOpened",
      "discriminator": [
        188,
        231,
        244,
        52,
        5,
        151,
        236,
        84
      ]
    },
    {
      "name": "hlpRebalanced",
      "discriminator": [
        48,
        237,
        118,
        177,
        48,
        168,
        104,
        6
      ]
    },
    {
      "name": "hlpRetiredReceiptBurned",
      "discriminator": [
        31,
        252,
        3,
        205,
        166,
        215,
        14,
        49
      ]
    },
    {
      "name": "hlpTerminalLiquidated",
      "discriminator": [
        80,
        186,
        237,
        212,
        75,
        183,
        43,
        173
      ]
    },
    {
      "name": "insuranceDonated",
      "discriminator": [
        238,
        155,
        254,
        172,
        251,
        224,
        236,
        18
      ]
    },
    {
      "name": "leverageDelegationUpdated",
      "discriminator": [
        118,
        41,
        235,
        95,
        91,
        24,
        191,
        17
      ]
    },
    {
      "name": "leveragePositionClosed",
      "discriminator": [
        132,
        9,
        124,
        103,
        6,
        252,
        177,
        238
      ]
    },
    {
      "name": "leveragePositionLiquidated",
      "discriminator": [
        59,
        18,
        185,
        247,
        120,
        184,
        16,
        225
      ]
    },
    {
      "name": "leveragePositionOpened",
      "discriminator": [
        198,
        227,
        54,
        99,
        54,
        249,
        54,
        29
      ]
    },
    {
      "name": "leveragePositionUpdated",
      "discriminator": [
        195,
        171,
        245,
        43,
        32,
        163,
        44,
        170
      ]
    },
    {
      "name": "liquidationAuctionCancelled",
      "discriminator": [
        122,
        103,
        174,
        225,
        120,
        149,
        186,
        155
      ]
    },
    {
      "name": "liquidationAuctionStarted",
      "discriminator": [
        137,
        151,
        231,
        92,
        108,
        13,
        215,
        59
      ]
    },
    {
      "name": "liquidationObserved",
      "discriminator": [
        94,
        27,
        52,
        51,
        81,
        236,
        3,
        0
      ]
    },
    {
      "name": "liquidityAdded",
      "discriminator": [
        154,
        26,
        221,
        108,
        238,
        64,
        217,
        161
      ]
    },
    {
      "name": "liquidityRemoved",
      "discriminator": [
        225,
        105,
        216,
        39,
        124,
        116,
        169,
        189
      ]
    },
    {
      "name": "lpTransferred",
      "discriminator": [
        244,
        4,
        93,
        185,
        125,
        159,
        75,
        55
      ]
    },
    {
      "name": "marketCollateralDeposited",
      "discriminator": [
        41,
        53,
        157,
        172,
        249,
        159,
        63,
        60
      ]
    },
    {
      "name": "marketCollateralWithdrawn",
      "discriminator": [
        68,
        208,
        162,
        132,
        39,
        151,
        221,
        245
      ]
    },
    {
      "name": "marketCreated",
      "discriminator": [
        88,
        184,
        130,
        231,
        226,
        84,
        6,
        58
      ]
    },
    {
      "name": "marketDebtUpdated",
      "discriminator": [
        135,
        150,
        109,
        165,
        174,
        35,
        163,
        151
      ]
    },
    {
      "name": "marketHealthUpdated",
      "discriminator": [
        99,
        12,
        230,
        43,
        133,
        194,
        188,
        225
      ]
    },
    {
      "name": "marketReduceOnlyUpdated",
      "discriminator": [
        87,
        12,
        104,
        143,
        113,
        121,
        31,
        94
      ]
    },
    {
      "name": "parameterProposalCreated",
      "discriminator": [
        243,
        111,
        217,
        113,
        215,
        176,
        38,
        118
      ]
    },
    {
      "name": "parameterProposalExecuted",
      "discriminator": [
        77,
        126,
        199,
        255,
        166,
        161,
        110,
        34
      ]
    },
    {
      "name": "parameterProposalQueued",
      "discriminator": [
        166,
        188,
        191,
        35,
        42,
        165,
        21,
        49
      ]
    },
    {
      "name": "parameterProposalSupportWithdrawn",
      "discriminator": [
        204,
        113,
        93,
        73,
        179,
        229,
        233,
        123
      ]
    },
    {
      "name": "parameterProposalSupported",
      "discriminator": [
        120,
        73,
        210,
        182,
        131,
        10,
        140,
        181
      ]
    },
    {
      "name": "protocolAuctionConfigUpdated",
      "discriminator": [
        178,
        169,
        215,
        69,
        170,
        59,
        80,
        160
      ]
    },
    {
      "name": "protocolAuctionRecipientsUpdated",
      "discriminator": [
        174,
        178,
        55,
        120,
        155,
        241,
        5,
        120
      ]
    },
    {
      "name": "protocolAuctionRouteUpdated",
      "discriminator": [
        146,
        136,
        94,
        87,
        36,
        147,
        221,
        192
      ]
    },
    {
      "name": "protocolAuctionSettled",
      "discriminator": [
        11,
        230,
        199,
        245,
        28,
        133,
        107,
        3
      ]
    },
    {
      "name": "protocolAuctionSplitUpdated",
      "discriminator": [
        17,
        255,
        78,
        242,
        127,
        110,
        234,
        249
      ]
    },
    {
      "name": "publicInterestFunded",
      "discriminator": [
        34,
        55,
        82,
        224,
        42,
        7,
        154,
        156
      ]
    },
    {
      "name": "referralBound",
      "discriminator": [
        12,
        28,
        152,
        148,
        55,
        210,
        102,
        190
      ]
    },
    {
      "name": "referralInterestAccrued",
      "discriminator": [
        80,
        233,
        11,
        123,
        118,
        218,
        113,
        154
      ]
    },
    {
      "name": "referralInterestClaimed",
      "discriminator": [
        103,
        79,
        19,
        199,
        132,
        222,
        156,
        190
      ]
    },
    {
      "name": "referralInterestShareCapUpdated",
      "discriminator": [
        103,
        139,
        112,
        245,
        212,
        53,
        91,
        113
      ]
    },
    {
      "name": "referralPartnerConfigured",
      "discriminator": [
        60,
        230,
        246,
        232,
        67,
        30,
        217,
        223
      ]
    },
    {
      "name": "referralRecipientUpdated",
      "discriminator": [
        51,
        4,
        221,
        175,
        134,
        8,
        235,
        222
      ]
    },
    {
      "name": "swapExecuted",
      "discriminator": [
        150,
        166,
        26,
        225,
        28,
        89,
        38,
        79
      ]
    },
    {
      "name": "yieldClaimed",
      "discriminator": [
        177,
        201,
        94,
        68,
        19,
        200,
        227,
        27
      ]
    },
    {
      "name": "yieldRecipientUpdated",
      "discriminator": [
        154,
        113,
        25,
        74,
        11,
        107,
        114,
        170
      ]
    }
  ],
  "errors": [
    {
      "code": 6000,
      "name": "invalidDeployer",
      "msg": "Invalid deployer"
    },
    {
      "code": 6001,
      "name": "argumentMissing",
      "msg": "Argument missing"
    },
    {
      "code": 6002,
      "name": "invalidSwapFeeBps",
      "msg": "Invalid swap fee bps"
    },
    {
      "code": 6003,
      "name": "invalidInterestFeeBps",
      "msg": "Invalid interest fee bps"
    },
    {
      "code": 6004,
      "name": "invalidHalfLife",
      "msg": "Invalid half life"
    },
    {
      "code": 6005,
      "name": "invalidFutarchyAuthority",
      "msg": "Invalid futarchy authority"
    },
    {
      "code": 6006,
      "name": "invalidReduceOnlyAuthority",
      "msg": "Invalid reduce-only authority"
    },
    {
      "code": 6007,
      "name": "invalidProposalMetadata",
      "msg": "Invalid parameter proposal metadata"
    },
    {
      "code": 6008,
      "name": "invalidProposalUri",
      "msg": "Invalid parameter proposal description URI"
    },
    {
      "code": 6009,
      "name": "invalidProposalDigest",
      "msg": "Parameter proposal digest does not match its immutable contents"
    },
    {
      "code": 6010,
      "name": "invalidParameterProposal",
      "msg": "Invalid parameter proposal account"
    },
    {
      "code": 6011,
      "name": "invalidProposalSupport",
      "msg": "Invalid parameter proposal support account"
    },
    {
      "code": 6012,
      "name": "proposalNotCollecting",
      "msg": "Parameter proposal is not collecting support"
    },
    {
      "code": 6013,
      "name": "proposalNotQueued",
      "msg": "Parameter proposal is not queued"
    },
    {
      "code": 6014,
      "name": "proposalSupportFrozen",
      "msg": "Queued proposal support is frozen"
    },
    {
      "code": 6015,
      "name": "proposalSponsorshipTooLow",
      "msg": "Proposal support is below the sponsorship floor"
    },
    {
      "code": 6016,
      "name": "proposalSupportInsufficient",
      "msg": "Proposal does not have a strict majority of eligible yLP"
    },
    {
      "code": 6017,
      "name": "proposalTimelockNotReady",
      "msg": "Parameter proposal timelock is not ready"
    },
    {
      "code": 6018,
      "name": "proposalExecutionWindowExpired",
      "msg": "Parameter proposal execution window has expired"
    },
    {
      "code": 6019,
      "name": "proposalStale",
      "msg": "Parameter proposal was invalidated by a same-family update"
    },
    {
      "code": 6020,
      "name": "parameterUpdateNotMeaningful",
      "msg": "Parameter update would not change the active market parameters"
    },
    {
      "code": 6021,
      "name": "invalidParameterUpdate",
      "msg": "Invalid parameter update"
    },
    {
      "code": 6022,
      "name": "utilizationGuardExceeded",
      "msg": "Parameter execution is blocked while either lending side is at or above 80% utilization"
    },
    {
      "code": 6023,
      "name": "invalidArgument",
      "msg": "Invalid argument"
    },
    {
      "code": 6024,
      "name": "amountZero",
      "msg": "Amount cannot be zero"
    },
    {
      "code": 6025,
      "name": "insufficientAmount0In",
      "msg": "Insufficient amount0 in"
    },
    {
      "code": 6026,
      "name": "insufficientAmount1In",
      "msg": "Insufficient amount1 in"
    },
    {
      "code": 6027,
      "name": "borrowingPowerExceeded",
      "msg": "Borrowing power exceeded"
    },
    {
      "code": 6028,
      "name": "invalidTokenAccount",
      "msg": "Invalid token account"
    },
    {
      "code": 6029,
      "name": "invalidTokenProgram",
      "msg": "Invalid token program"
    },
    {
      "code": 6030,
      "name": "borrowExceedsReserve",
      "msg": "Borrow exceeds reserve"
    },
    {
      "code": 6031,
      "name": "insufficientAmount0",
      "msg": "Insufficient amount0"
    },
    {
      "code": 6032,
      "name": "insufficientAmount1",
      "msg": "Insufficient amount1"
    },
    {
      "code": 6033,
      "name": "insufficientOutputAmount",
      "msg": "Insufficient output amount"
    },
    {
      "code": 6034,
      "name": "slippageExceeded",
      "msg": "Output amount below minimum requested (slippage exceeded)"
    },
    {
      "code": 6035,
      "name": "insufficientLiquidity",
      "msg": "Insufficient liquidity"
    },
    {
      "code": 6036,
      "name": "insufficientCashReserve0",
      "msg": "Insufficient cash reserve0"
    },
    {
      "code": 6037,
      "name": "insufficientCashReserve1",
      "msg": "Insufficient cash reserve1"
    },
    {
      "code": 6038,
      "name": "overflow",
      "msg": "Arithmetic overflow"
    },
    {
      "code": 6039,
      "name": "undercollateralized",
      "msg": "undercollateralized"
    },
    {
      "code": 6040,
      "name": "insufficientBalanceForCollateral",
      "msg": "Insufficient balance for collateral"
    },
    {
      "code": 6041,
      "name": "insufficientAmount",
      "msg": "Insufficient amount"
    },
    {
      "code": 6042,
      "name": "insufficientBalance",
      "msg": "User balance insufficient to cover requested amount"
    },
    {
      "code": 6043,
      "name": "insufficientDebt",
      "msg": "Insufficient debt"
    },
    {
      "code": 6044,
      "name": "userPositionNotInitialized",
      "msg": "User position not initialized"
    },
    {
      "code": 6045,
      "name": "zeroDebtAmount",
      "msg": "Zero debt amount"
    },
    {
      "code": 6046,
      "name": "notUndercollateralized",
      "msg": "Not undercollateralized"
    },
    {
      "code": 6047,
      "name": "brokenInvariant",
      "msg": "Broken invariant"
    },
    {
      "code": 6048,
      "name": "invariantOverflow",
      "msg": "Math overflow during invariant calculation"
    },
    {
      "code": 6049,
      "name": "feeMathOverflow",
      "msg": "Math overflow during fee calculation."
    },
    {
      "code": 6050,
      "name": "outputAmountOverflow",
      "msg": "Math overflow during output amount calculation."
    },
    {
      "code": 6051,
      "name": "reserveOverflow",
      "msg": "Math overflow during reserve calculation."
    },
    {
      "code": 6052,
      "name": "reserveUnderflow",
      "msg": "Math underflow during reserve calculation."
    },
    {
      "code": 6053,
      "name": "cashReserveUnderflow",
      "msg": "Math underflow during cash reserve calculation."
    },
    {
      "code": 6054,
      "name": "denominatorOverflow",
      "msg": "Math overflow during denominator calculation."
    },
    {
      "code": 6055,
      "name": "liquidityMathOverflow",
      "msg": "Math overflow during liquidity calculation"
    },
    {
      "code": 6056,
      "name": "liquiditySqrtOverflow",
      "msg": "Math overflow during liquidity square root calculation"
    },
    {
      "code": 6057,
      "name": "liquidityUnderflow",
      "msg": "Math underflow during liquidity calculation"
    },
    {
      "code": 6058,
      "name": "liquidityConversionOverflow",
      "msg": "Math overflow during liquidity conversion"
    },
    {
      "code": 6059,
      "name": "supplyOverflow",
      "msg": "Math overflow during supply calculation"
    },
    {
      "code": 6060,
      "name": "supplyUnderflow",
      "msg": "Math underflow during supply calculation"
    },
    {
      "code": 6061,
      "name": "debtMathOverflow",
      "msg": "Math overflow during debt calculation"
    },
    {
      "code": 6062,
      "name": "debtShareMathOverflow",
      "msg": "Math overflow during debt share calculation"
    },
    {
      "code": 6063,
      "name": "debtShareDivisionOverflow",
      "msg": "Math overflow during debt share division"
    },
    {
      "code": 6064,
      "name": "debtUtilizationOverflow",
      "msg": "Math overflow during debt utilization calculation"
    },
    {
      "code": 6065,
      "name": "invalidMint",
      "msg": "Invalid mint"
    },
    {
      "code": 6066,
      "name": "invalidMintLen",
      "msg": "Invalid mint length"
    },
    {
      "code": 6067,
      "name": "invalidDistribution",
      "msg": "Invalid distribution - percentages must sum to 100%"
    },
    {
      "code": 6068,
      "name": "invalidAuctionConfig",
      "msg": "Invalid protocol auction config"
    },
    {
      "code": 6069,
      "name": "staleAuctionReference",
      "msg": "Protocol auction reference price is stale"
    },
    {
      "code": 6070,
      "name": "insufficientAuctionPayment",
      "msg": "Protocol auction payment is insufficient"
    },
    {
      "code": 6071,
      "name": "invalidLpMintKey",
      "msg": "Invalid LP mint key"
    },
    {
      "code": 6072,
      "name": "invalidLpName",
      "msg": "Invalid LP name"
    },
    {
      "code": 6073,
      "name": "invalidLpSymbol",
      "msg": "Invalid LP symbol"
    },
    {
      "code": 6074,
      "name": "invalidLpUri",
      "msg": "Invalid LP URI"
    },
    {
      "code": 6075,
      "name": "accountNotEmpty",
      "msg": "Account not empty"
    },
    {
      "code": 6076,
      "name": "invalidMintAuthority",
      "msg": "Invalid mint authority"
    },
    {
      "code": 6077,
      "name": "frozenLpMint",
      "msg": "Frozen LP mint"
    },
    {
      "code": 6078,
      "name": "nonZeroSupply",
      "msg": "Non-zero supply"
    },
    {
      "code": 6079,
      "name": "wrongLpDecimals",
      "msg": "Wrong LP decimals"
    },
    {
      "code": 6080,
      "name": "unsupportedAssetDecimals",
      "msg": "Asset mint decimals exceed Dusk's 9-decimal AMM precision"
    },
    {
      "code": 6081,
      "name": "invalidVaultSameAccount",
      "msg": "Invalid vault - token_in_vault and token_out_vault must be different"
    },
    {
      "code": 6082,
      "name": "invalidVault",
      "msg": "Invalid vault"
    },
    {
      "code": 6083,
      "name": "invalidParamsHash",
      "msg": "Invalid params hash - hash does not match computed parameters"
    },
    {
      "code": 6084,
      "name": "invalidVersion",
      "msg": "Invalid version"
    },
    {
      "code": 6085,
      "name": "invalidTokenOrder",
      "msg": "Invalid token order"
    },
    {
      "code": 6086,
      "name": "invalidRateModel",
      "msg": "Invalid rate model - rate_model does not match market configuration"
    },
    {
      "code": 6087,
      "name": "invalidPositionMarket",
      "msg": "Invalid position market - position does not match market"
    },
    {
      "code": 6088,
      "name": "invalidUtilBounds",
      "msg": "Invalid utilization bounds - must satisfy: MIN <= start < end <= MAX"
    },
    {
      "code": 6089,
      "name": "invalidRateParams",
      "msg": "Invalid rate parameters - check half_life_ms, min_rate_bps, max_rate_bps, initial_rate_bps bounds"
    },
    {
      "code": 6090,
      "name": "reduceOnlyMode",
      "msg": "Operation blocked: reduce-only mode is active"
    },
    {
      "code": 6091,
      "name": "reduceOnlyHasDebt",
      "msg": "Cannot remove collateral in reduce-only mode while debt exists"
    },
    {
      "code": 6092,
      "name": "invalidInstructionsSysvar",
      "msg": "Invalid instructions sysvar"
    },
    {
      "code": 6093,
      "name": "insufficientPostWithdrawDebtCoverage",
      "msg": "Insufficient post-withdraw debt coverage"
    },
    {
      "code": 6094,
      "name": "invalidRecipient",
      "msg": "Invalid recipient - address does not match configured revenue recipient"
    },
    {
      "code": 6095,
      "name": "invalidMarket",
      "msg": "Invalid market"
    },
    {
      "code": 6096,
      "name": "invalidMarketConfig",
      "msg": "Invalid market config"
    },
    {
      "code": 6097,
      "name": "invalidSettlementPrice",
      "msg": "Invalid settlement price"
    },
    {
      "code": 6098,
      "name": "insufficientMarketShareBacking",
      "msg": "Market reserve share backing is insufficient"
    },
    {
      "code": 6099,
      "name": "invalidMarketSide",
      "msg": "Invalid market side"
    },
    {
      "code": 6100,
      "name": "invalidYieldAccount",
      "msg": "Invalid yield account"
    },
    {
      "code": 6101,
      "name": "invalidHlpVault",
      "msg": "Invalid hLP vault"
    },
    {
      "code": 6102,
      "name": "invalidHlpMintSupply",
      "msg": "Live hLP mint supply is inconsistent with stored vault supply"
    },
    {
      "code": 6103,
      "name": "notEnoughAccounts",
      "msg": "Not enough remaining accounts"
    },
    {
      "code": 6104,
      "name": "hlpSettlementUnavailable",
      "msg": "hLP settlement is unavailable"
    },
    {
      "code": 6105,
      "name": "hlpNotLiquidatable",
      "msg": "hLP funding position is not eligible for permissionless liquidation"
    },
    {
      "code": 6106,
      "name": "insufficientBorrowHeadroom",
      "msg": "Borrow headroom is insufficient"
    },
    {
      "code": 6107,
      "name": "insufficientMarketHealth",
      "msg": "Market health is insufficient"
    },
    {
      "code": 6108,
      "name": "invalidBorrowPosition",
      "msg": "Invalid borrow position"
    },
    {
      "code": 6109,
      "name": "positionNotLiquidatable",
      "msg": "Position is not liquidatable"
    },
    {
      "code": 6110,
      "name": "insufficientInsurance",
      "msg": "Insurance coverage is insufficient"
    },
    {
      "code": 6111,
      "name": "insuranceDrawExceeded",
      "msg": "Required insurance draw exceeds caller cap"
    },
    {
      "code": 6112,
      "name": "liquidationSocializationExceeded",
      "msg": "Socialized liquidation loss exceeds caller cap"
    },
    {
      "code": 6113,
      "name": "invalidClaimMint",
      "msg": "Claim mint must not charge transfer fees"
    },
    {
      "code": 6114,
      "name": "unbackedFeeLiability",
      "msg": "Fee liability is not backed by its custody balance"
    },
    {
      "code": 6115,
      "name": "invalidMarketFeeAuthority",
      "msg": "Invalid market fee authority"
    },
    {
      "code": 6116,
      "name": "invalidInitialLiquidityAuthority",
      "msg": "Invalid initial liquidity authority"
    },
    {
      "code": 6117,
      "name": "launchRateLimitSplitTransaction",
      "msg": "Launch rate limiter permits only one top-level market action per transaction"
    },
    {
      "code": 6118,
      "name": "marketReduceOnly",
      "msg": "Market is reduce-only"
    },
    {
      "code": 6119,
      "name": "marketNotStarted",
      "msg": "Market has not started"
    },
    {
      "code": 6120,
      "name": "marketMathOverflow",
      "msg": "Market math overflow"
    },
    {
      "code": 6121,
      "name": "dailyLimitExceeded",
      "msg": "Daily liquidity limit exceeded"
    },
    {
      "code": 6122,
      "name": "instructionNotLive",
      "msg": "Instruction is intentionally not live yet"
    },
    {
      "code": 6123,
      "name": "liquidationRepayTooLarge",
      "msg": "Liquidation repay amount exceeds partial liquidation cap"
    },
    {
      "code": 6124,
      "name": "leverageMultiplierTooHigh",
      "msg": "Leverage multiplier exceeds circuit breaker"
    },
    {
      "code": 6125,
      "name": "leverageInitialMarginTooLow",
      "msg": "Leverage position does not have enough initial margin"
    },
    {
      "code": 6126,
      "name": "leverageUnwindImpactTooHigh",
      "msg": "Leverage unwind impact exceeds limit"
    },
    {
      "code": 6127,
      "name": "leveragePositionNotLiquidatable",
      "msg": "Leverage position is not liquidatable"
    },
    {
      "code": 6128,
      "name": "invalidSigner",
      "msg": "Invalid signer"
    },
    {
      "code": 6129,
      "name": "invalidLeveragePosition",
      "msg": "Invalid leverage position"
    },
    {
      "code": 6130,
      "name": "invalidLeverageDelegation",
      "msg": "Invalid leverage delegation"
    },
    {
      "code": 6131,
      "name": "invalidReferralInterestShareBps",
      "msg": "Referral interest share exceeds the protocol hard cap"
    },
    {
      "code": 6132,
      "name": "invalidReferralPartner",
      "msg": "Invalid referral partner"
    },
    {
      "code": 6133,
      "name": "referralPartnerNotActive",
      "msg": "Referral partner is not active"
    },
    {
      "code": 6134,
      "name": "invalidReferralAccrual",
      "msg": "Invalid referral accrual account"
    },
    {
      "code": 6135,
      "name": "invalidLeverageCollateralMint",
      "msg": "Leverage collateral transfer fee must be immutable with no pending change"
    },
    {
      "code": 6136,
      "name": "freezableAssetMint",
      "msg": "Asset mint has an active freeze authority"
    },
    {
      "code": 6137,
      "name": "parameterUpdatesNotCanonical",
      "msg": "Parameter updates must name one to seven families, each once, in ascending family order"
    },
    {
      "code": 6138,
      "name": "proposalDigestMismatch",
      "msg": "Parameter proposal does not match the digest the supporter reviewed"
    },
    {
      "code": 6139,
      "name": "invalidLiquidationClock",
      "msg": "Liquidation observation clock moved backwards"
    },
    {
      "code": 6140,
      "name": "liquidationSessionActive",
      "msg": "Position has an active liquidation session"
    },
    {
      "code": 6141,
      "name": "invalidLiquidationSession",
      "msg": "Invalid atomic liquidation session or instruction pairing"
    },
    {
      "code": 6142,
      "name": "liquidationDoesNotImproveHealth",
      "msg": "Partial liquidation does not improve health after costs"
    }
  ],
  "types": [
    {
      "name": "addLeverageMarginArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "addLiquidityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "baseDepositAmount",
            "type": "u64"
          },
          {
            "name": "quoteDepositAmount",
            "type": "u64"
          },
          {
            "name": "minYlpAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "addLiquidityPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "requestedBaseAmount",
            "type": "u64"
          },
          {
            "name": "requestedQuoteAmount",
            "type": "u64"
          },
          {
            "name": "maxBaseReserveCredit",
            "type": "u64"
          },
          {
            "name": "maxQuoteReserveCredit",
            "type": "u64"
          },
          {
            "name": "baseTransferAmount",
            "type": "u64"
          },
          {
            "name": "quoteTransferAmount",
            "type": "u64"
          },
          {
            "name": "baseTransferFee",
            "type": "u64"
          },
          {
            "name": "quoteTransferFee",
            "type": "u64"
          },
          {
            "name": "baseReserveCredit",
            "type": "u64"
          },
          {
            "name": "quoteReserveCredit",
            "type": "u64"
          },
          {
            "name": "unusedBaseAmount",
            "type": "u64"
          },
          {
            "name": "unusedQuoteAmount",
            "type": "u64"
          },
          {
            "name": "ylpAmount",
            "type": "u64"
          },
          {
            "name": "ylpSupply",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "ammConfig",
      "docs": [
        "AMM controls. One-times peak amplification with zero widths selects the",
        "full-range CPMM branch of the same concentrated implementation."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "peakAmplificationNad",
            "type": "u64"
          },
          {
            "name": "coreHalfWidthBps",
            "type": "u16"
          },
          {
            "name": "fadeWidthBps",
            "type": "u16"
          },
          {
            "name": "centerEmaHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "volatilityHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "adjustmentThresholdNad",
            "type": "u64"
          },
          {
            "name": "adjustmentStepNad",
            "type": "u64"
          },
          {
            "name": "minAdjustmentIntervalSlots",
            "type": "u64"
          },
          {
            "name": "volatilityShockCapNad",
            "type": "u64"
          },
          {
            "name": "volatilityCapNad",
            "type": "u64"
          },
          {
            "name": "divergenceFeeCoefficientNad",
            "type": "u64"
          },
          {
            "name": "volatilityFeeCoefficientNad",
            "type": "u64"
          },
          {
            "name": "swapFeeCollectMode",
            "docs": [
              "Asset in which swap, toxicity, volatility, and retained-recenter fees",
              "are denominated. Lending and hLP funding interest remain in the",
              "borrowed asset and are not affected by this setting."
            ],
            "type": "u8"
          },
          {
            "name": "compoundingFeeBps",
            "docs": [
              "Share of the LP-owned swap fee which becomes ordinary reserve",
              "principal instead of a claimable fee liability. Zero disables native",
              "compounding; `BPS_DENOMINATOR` compounds the complete LP share."
            ],
            "type": "u16"
          },
          {
            "name": "launchFeeStartBps",
            "docs": [
              "Optional launch-only base fee. The premium above `swap_fee_bps`",
              "decays from `start_time` and is zero after the configured duration."
            ],
            "type": "u16"
          },
          {
            "name": "launchFeeDurationSeconds",
            "type": "u64"
          },
          {
            "name": "launchFeeDecayMode",
            "type": "u8"
          },
          {
            "name": "launchMarketPriceStepBps",
            "docs": [
              "When all three values are zero, the launch fee follows the time",
              "schedule above. A fully nonzero tuple selects a price-milestone",
              "scheduler whose reference price is bound by the first liquidity seed."
            ],
            "type": "u16"
          },
          {
            "name": "launchMarketNumberOfPeriods",
            "type": "u16"
          },
          {
            "name": "launchMarketReductionFactorBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitAsset",
            "docs": [
              "Optional launch buy-size limiter. The configured asset is the asset",
              "being bought, not the input asset. Each full/partial reference amount",
              "after the first adds `launch_rate_limit_increment_bps`, capped by",
              "`launch_rate_limit_max_fee_bps`."
            ],
            "type": "u8"
          },
          {
            "name": "launchRateLimitReferenceNad",
            "type": "u64"
          },
          {
            "name": "launchRateLimitIncrementBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitMaxFeeBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitDurationSeconds",
            "type": "u64"
          },
          {
            "name": "reserved",
            "type": {
              "array": [
                "u8",
                0
              ]
            }
          }
        ]
      }
    },
    {
      "name": "ammState",
      "docs": [
        "Embedded mutable state for the concentrated curve, internal signals, and",
        "protected recenter liquidity."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "initialized",
            "type": "bool"
          },
          {
            "name": "concentratedCurveCache",
            "docs": [
              "Concentrated CPMM-tail/band geometry. CPMM is represented by zero",
              "concentrated liquidity in this same cache."
            ],
            "type": {
              "defined": {
                "name": "concentratedCurveCache"
              }
            }
          },
          {
            "name": "centerPriceNad",
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "type": "u64"
          },
          {
            "name": "lastTradePriceNad",
            "type": "u64"
          },
          {
            "name": "lastObservationSlot",
            "type": "u64"
          },
          {
            "name": "lastAdjustmentSlot",
            "type": "u64"
          },
          {
            "name": "launchReferencePriceNad",
            "docs": [
              "Immutable launch price reference bound by the first fully-backed",
              "liquidity seed. Zero is allowed only before that seed."
            ],
            "type": "u64"
          },
          {
            "name": "launchFeeProgressOffset",
            "docs": [
              "Fee-schedule progress already completed by a bootstrap adapter before",
              "the market graduates into GAMM."
            ],
            "type": "u16"
          },
          {
            "name": "volatilityAccumulatorNad",
            "type": "u64"
          },
          {
            "name": "curveDepthPerShareNad",
            "type": "u128"
          },
          {
            "name": "protectedFloorPerShareNad",
            "docs": [
              "yLP principal floor protected from funded recenter/ramp impairment."
            ],
            "type": "u128"
          },
          {
            "name": "retentionRequiredNad",
            "docs": [
              "Fresh protected-profit target that arms retained surcharge routing.",
              "This is a principal-budget target, never a cap on trader fees."
            ],
            "type": "u128"
          },
          {
            "name": "retentionStopNad",
            "docs": [
              "Hysteresis threshold below which retention remains armed."
            ],
            "type": "u128"
          },
          {
            "name": "retentionHardCapNad",
            "docs": [
              "Maximum protected principal one controller target may request/spend.",
              "It does not clip divergence or volatility surcharge amounts."
            ],
            "type": "u128"
          },
          {
            "name": "retainDynamicSurcharge",
            "docs": [
              "When true, dynamic surcharge is locked in the non-quoteable protected",
              "recenter bucket; when false, the identical trader charge is routed to",
              "claimable yLP fee accounting."
            ],
            "type": "bool"
          },
          {
            "name": "retentionTargetSaturated",
            "docs": [
              "The requested protection target exceeded its principal-budget cap."
            ],
            "type": "bool"
          },
          {
            "name": "retentionTargetStale",
            "docs": [
              "The protected bucket changed after the last exact forward-target solve.",
              "While stale, retention stays on until a decision point refreshes the",
              "target or executes a funded recenter."
            ],
            "type": "bool"
          },
          {
            "name": "deferredControllerTarget",
            "docs": [
              "Exact unfunded controller target retried by later real operations."
            ],
            "type": {
              "defined": {
                "name": "deferredControllerTarget"
              }
            }
          },
          {
            "name": "frozenHlpMask",
            "docs": [
              "A distressed hLP cannot be reconstructed as positive one-sided equity.",
              "Each bit freezes only that vault's share/debt hedge during swaps."
            ],
            "type": "u8"
          },
          {
            "name": "frozenBaseVaultBaseOffsetNad",
            "docs": [
              "Fixed virtual-coordinate adjustment captured when the vault freezes.",
              "It preserves the pre-freeze executable price without treating the",
              "vault's negative equity as spendable token inventory."
            ],
            "type": "i128"
          },
          {
            "name": "frozenBaseVaultQuoteOffsetNad",
            "type": "i128"
          },
          {
            "name": "frozenQuoteVaultBaseOffsetNad",
            "type": "i128"
          },
          {
            "name": "frozenQuoteVaultQuoteOffsetNad",
            "type": "i128"
          },
          {
            "name": "reserved",
            "type": {
              "array": [
                "u8",
                0
              ]
            }
          }
        ]
      }
    },
    {
      "name": "beginFlashLiquidationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "maxRepayment",
            "type": "u64"
          },
          {
            "name": "maxPayment",
            "type": "u64"
          },
          {
            "name": "minCollateralCredit",
            "type": "u64"
          },
          {
            "name": "full",
            "type": "bool"
          },
          {
            "name": "settleIndex",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "beginHlpFlashArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "maxPayment",
            "type": "u64"
          },
          {
            "name": "allowFull",
            "type": "bool"
          },
          {
            "name": "maxInsuranceDraw",
            "type": "u64"
          },
          {
            "name": "maxSocializedLoss",
            "type": "u64"
          },
          {
            "name": "maxCollateralDebit",
            "type": "u64"
          },
          {
            "name": "minCollateralCredit",
            "type": "u64"
          },
          {
            "name": "settleIndex",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "borrowArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "borrowAmount",
            "type": "u64"
          },
          {
            "name": "minDebtAmountOut",
            "type": "u64"
          },
          {
            "name": "minLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "referrer",
            "type": {
              "option": "pubkey"
            }
          }
        ]
      }
    },
    {
      "name": "borrowCapacityPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "collateralAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "debtAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "collateralValueNad",
            "type": "u128"
          },
          {
            "name": "maxDebtByHealth",
            "type": "u64"
          },
          {
            "name": "maxDebtByCash",
            "type": "u64"
          },
          {
            "name": "maxDebtByDailyLimit",
            "type": "u64"
          },
          {
            "name": "maxDebt",
            "type": "u64"
          },
          {
            "name": "maxBorrowAmount",
            "type": "u64"
          },
          {
            "name": "borrowMarketHealthFloorBps",
            "type": "u16"
          },
          {
            "name": "globalHealthContributionCapBps",
            "type": "u16"
          },
          {
            "name": "projectedBorrowAmount",
            "type": "u64"
          },
          {
            "name": "projectedDebtAmount",
            "type": "u64"
          },
          {
            "name": "projectedHealthBps",
            "type": "u64"
          },
          {
            "name": "projectedGlobalMarketHealthBps",
            "type": "u64"
          },
          {
            "name": "projectedGlobalHealthContribution",
            "type": "u64"
          },
          {
            "name": "projectedEffectiveExistingDebtNad",
            "type": "u128"
          },
          {
            "name": "maxCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationDebtPerCollateralPriceNad",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "borrowInterestAccrued",
      "docs": [
        "Interest recognized by one committed borrow-index checkpoint. Amounts are",
        "raw atoms of `asset_mint`, separately floored in each debt-share bucket.",
        "This is accrued interest, not a payment or a protocol-revenue allocation."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "assetSide",
            "type": "u8"
          },
          {
            "name": "fromSlot",
            "type": "u64"
          },
          {
            "name": "toSlot",
            "type": "u64"
          },
          {
            "name": "borrowIndexBeforeNad",
            "type": "u128"
          },
          {
            "name": "borrowIndexAfterNad",
            "type": "u128"
          },
          {
            "name": "creditInterest",
            "type": "u128"
          },
          {
            "name": "marginInterest",
            "type": "u128"
          },
          {
            "name": "hlpInterest",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "borrowInterestPaid",
      "docs": [
        "Canonical interest-payment record. Lifecycle and referral events may",
        "repeat these amounts for context and must not be summed a second time."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "assetSide",
            "type": "u8"
          },
          {
            "name": "source",
            "type": {
              "defined": {
                "name": "debtSource"
              }
            }
          },
          {
            "name": "position",
            "docs": [
              "None for aggregate hLP funding debt; `asset_side` identifies its vault."
            ],
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "interestPaid",
            "docs": [
              "Gross interest collected, including any terminal hLP caller bounty."
            ],
            "type": "u64"
          },
          {
            "name": "interestVaultCredit",
            "docs": [
              "Net tokens credited to the interest vault after transfer fees/bounty."
            ],
            "type": "u64"
          },
          {
            "name": "protocolInterestRevenue",
            "docs": [
              "Protocol allocation from vault credit, before the referral allocation."
            ],
            "type": "u64"
          },
          {
            "name": "referralAmount",
            "type": "u64"
          },
          {
            "name": "callerBounty",
            "docs": [
              "Gross terminal hLP caller bounty; zero for ordinary payments."
            ],
            "type": "u64"
          },
          {
            "name": "slot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "borrowPosition",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "baseCollateral",
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "baseReferralPartner",
            "type": "pubkey"
          },
          {
            "name": "quoteReferralPartner",
            "type": "pubkey"
          },
          {
            "name": "baseReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "quoteReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "fixedBaseShares",
            "type": "u128"
          },
          {
            "name": "fixedQuoteShares",
            "type": "u128"
          },
          {
            "name": "fixedBasePrincipal",
            "docs": [
              "Original base borrowed by this position that has not been repaid or written off."
            ],
            "type": "u64"
          },
          {
            "name": "fixedQuotePrincipal",
            "docs": [
              "Original quote borrowed by this position that has not been repaid or written off."
            ],
            "type": "u64"
          },
          {
            "name": "activeLiquidationSession",
            "type": "pubkey"
          },
          {
            "name": "baseDistress",
            "type": {
              "defined": {
                "name": "liquidationDistress"
              }
            }
          },
          {
            "name": "quoteDistress",
            "type": {
              "defined": {
                "name": "liquidationDistress"
              }
            }
          },
          {
            "name": "auctionDebtAsset",
            "type": "u8"
          },
          {
            "name": "auctionStartTime",
            "type": "i64"
          },
          {
            "name": "auctionStartPriceNad",
            "type": "u64"
          },
          {
            "name": "auctionFloorPriceNad",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "borrowPositionCapacityKind",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "borrow"
          },
          {
            "name": "withdraw"
          }
        ]
      }
    },
    {
      "name": "borrowPositionCapacityPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "collateralAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "debtAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "currentCollateralAmount",
            "type": "u64"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "existingDebtAmount",
            "type": "u128"
          },
          {
            "name": "maxBorrowAmount",
            "type": {
              "option": "u64"
            }
          },
          {
            "name": "maxWithdrawAmount",
            "type": {
              "option": "u64"
            }
          },
          {
            "name": "projectedBorrowAmount",
            "type": "u64"
          },
          {
            "name": "projectedDebtAmount",
            "type": "u128"
          },
          {
            "name": "collateralValueNad",
            "type": "u128"
          },
          {
            "name": "maxCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationDebtPerCollateralPriceNad",
            "type": "u64"
          },
          {
            "name": "borrowAllowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "borrowPositionLiquidated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "borrowPosition",
            "type": "pubkey"
          },
          {
            "name": "borrower",
            "type": "pubkey"
          },
          {
            "name": "liquidator",
            "type": "pubkey"
          },
          {
            "name": "debtAssetSide",
            "docs": [
              "`0` for base debt and `1` for quote debt. The collateral is the other side."
            ],
            "type": "u8"
          },
          {
            "name": "repaidAmount",
            "type": "u64"
          },
          {
            "name": "collateralSeized",
            "type": "u64"
          },
          {
            "name": "collateralToLiquidator",
            "docs": [
              "Gross collateral debited for the liquidator's transfer. Token-2022 may",
              "reduce the liquidator's net account credit."
            ],
            "type": "u64"
          },
          {
            "name": "collateralCredit",
            "docs": [
              "Net collateral credited to the liquidator after any transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "insuranceDrawn",
            "type": "u64"
          },
          {
            "name": "socializedLoss",
            "type": "u64"
          },
          {
            "name": "remainingDebt",
            "type": "u128"
          },
          {
            "name": "baseCollateral",
            "docs": [
              "The position's state after the liquidation."
            ],
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "fixedBaseShares",
            "type": "u128"
          },
          {
            "name": "fixedQuoteShares",
            "type": "u128"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "auctionDebtAsset",
            "docs": [
              "`255` once the auction is cleared."
            ],
            "type": "u8"
          },
          {
            "name": "closed",
            "docs": [
              "The liquidation emptied the position and closed its account."
            ],
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "borrowPositionPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "baseCollateral",
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "fixedBaseDebt",
            "type": "u128"
          },
          {
            "name": "fixedQuoteDebt",
            "type": "u128"
          },
          {
            "name": "baseDebt",
            "type": {
              "defined": {
                "name": "positionDebtSidePreview"
              }
            }
          },
          {
            "name": "quoteDebt",
            "type": {
              "defined": {
                "name": "positionDebtSidePreview"
              }
            }
          }
        ]
      }
    },
    {
      "name": "burnRetiredHlpReceiptArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "closeInsolventHlpArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "maxInsuranceDraw",
            "type": "u64"
          },
          {
            "name": "maxSocializedLoss",
            "type": "u64"
          },
          {
            "name": "minCallerBountyOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "closeLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "minAmountOut",
            "type": "u64"
          },
          {
            "name": "closeBps",
            "docs": [
              "Percentage of current collateral and debt to close, in basis points."
            ],
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "closeLeverageDelegationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "position",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "concentratedCurveCache",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "mathRevision",
            "type": "u8"
          },
          {
            "name": "peakAmplificationNad",
            "type": "u64"
          },
          {
            "name": "coreHalfWidthBps",
            "type": "u16"
          },
          {
            "name": "fadeWidthBps",
            "type": "u16"
          },
          {
            "name": "tailLiquidity",
            "type": "u128"
          },
          {
            "name": "concentratedLiquidity",
            "type": "u128"
          },
          {
            "name": "coreLowerSqrtPriceNad",
            "type": "u128"
          },
          {
            "name": "coreUpperSqrtPriceNad",
            "type": "u128"
          },
          {
            "name": "outerLowerSqrtPriceNad",
            "type": "u128"
          },
          {
            "name": "outerUpperSqrtPriceNad",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "configureReferralPartnerArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referrer",
            "type": "pubkey"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "active",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "createGovernanceProposalArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "updates",
            "type": {
              "vec": {
                "defined": {
                  "name": "marketParameterUpdate"
                }
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "proposalMetadataV1"
              }
            }
          },
          {
            "name": "contributions",
            "docs": [
              "One positive amount per remaining [balance, support] pair. Balance",
              "addresses must be strictly ascending; all owners authorize the signer."
            ],
            "type": {
              "vec": "u64"
            }
          }
        ]
      }
    },
    {
      "name": "createLeverageDelegationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "delegatedProgram",
            "type": "pubkey"
          },
          {
            "name": "approvedActions",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "createParameterProposalArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "updates",
            "docs": [
              "One to seven updates, at most one per family, in ascending family",
              "order. One sponsorship and one vote cover all of them."
            ],
            "type": {
              "vec": {
                "defined": {
                  "name": "marketParameterUpdate"
                }
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "proposalMetadataV1"
              }
            }
          },
          {
            "name": "initialSupport",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "dailyBorrowBucket",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "borrowedBucket",
            "docs": [
              "Gross principal lent out through the public borrow path. Internal hLP",
              "funding and isolated leverage do not consume this capacity. This is a",
              "24-hour leaky/token bucket, not an exact trailing-window sum: it permits",
              "a full burst after idle and then refills at the configured daily rate."
            ],
            "type": "u64"
          },
          {
            "name": "lastDecaySlot",
            "type": "u64"
          },
          {
            "name": "decayRemainderMs",
            "docs": [
              "Numerator remainder from `limit * elapsed_ms / MS_PER_DAY`. For a fixed",
              "absolute limit, carrying it makes refill independent of how often the",
              "bucket is checkpointed. The bps-derived absolute limit can still move",
              "when conservative market depth changes."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "debt",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "fixedBaseShares",
            "type": "u128"
          },
          {
            "name": "fixedQuoteShares",
            "type": "u128"
          },
          {
            "name": "baseBorrowIndexNad",
            "type": "u128"
          },
          {
            "name": "quoteBorrowIndexNad",
            "type": "u128"
          },
          {
            "name": "baseBorrowIndexRemainder",
            "docs": [
              "Fractional index growth carried across checkpoints. Denominator is",
              "`NAD * MS_PER_YEAR`, so frequent checkpoints cannot discard interest."
            ],
            "type": "u128"
          },
          {
            "name": "quoteBorrowIndexRemainder",
            "type": "u128"
          },
          {
            "name": "baseRateAtTargetNad",
            "type": "u128"
          },
          {
            "name": "quoteRateAtTargetNad",
            "type": "u128"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLastAccrualSlot",
            "type": "u64"
          },
          {
            "name": "quoteLastAccrualSlot",
            "type": "u64"
          },
          {
            "name": "fixedBasePrincipal",
            "docs": [
              "Aggregate outstanding *principal* (borrowed token amount, excluding",
              "accrued interest) backing fixed margin debt on each side. Accrued",
              "interest is `fixed_*_debt - fixed_*_principal`; tracked so interest can",
              "be routed to the interest vault (non-compounding) instead of",
              "compounding into reserves. Principal is a raw token-atom balance and is",
              "therefore bounded by the corresponding `u64` reserve custody domain."
            ],
            "type": "u64"
          },
          {
            "name": "fixedQuotePrincipal",
            "type": "u64"
          },
          {
            "name": "isolatedBaseShares",
            "docs": [
              "Aggregate isolated leverage debt. This debt contributes to utilization",
              "and interest, but is intentionally not utilized as normal margin debt.",
              "Shares remain `u128`; raw principal remains in the token account's",
              "`u64` amount domain."
            ],
            "type": "u128"
          },
          {
            "name": "isolatedQuoteShares",
            "type": "u128"
          },
          {
            "name": "isolatedBasePrincipal",
            "type": "u64"
          },
          {
            "name": "isolatedQuotePrincipal",
            "type": "u64"
          },
          {
            "name": "leverageBaseCollateral",
            "docs": [
              "Gross collateral atoms in debt-bearing leverage positions. Counts all",
              "owners and namespaces; custody donations cannot create exposure credit."
            ],
            "type": "u64"
          },
          {
            "name": "leverageQuoteCollateral",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "debtFreePositionClosed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "leverage",
            "type": "bool"
          },
          {
            "name": "baseReceived",
            "type": "u64"
          },
          {
            "name": "quoteReceived",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "debtSource",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "credit"
          },
          {
            "name": "margin"
          },
          {
            "name": "hlp"
          }
        ]
      }
    },
    {
      "name": "decreaseLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "minRepayOut",
            "type": "u64"
          },
          {
            "name": "maxSurplusOut",
            "docs": [
              "Maximum gross debt-token remainder returned after repayment. Zero",
              "prevents wallet payouts; a bounded value permits final 1x rounding."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "deferredControllerTarget",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "kind",
            "docs": [
              "0 = none, 2 = center move."
            ],
            "type": "u8"
          },
          {
            "name": "centerPriceNad",
            "type": "u64"
          },
          {
            "name": "requiredNad",
            "type": "u128"
          },
          {
            "name": "evaluatedBaseReserveNad",
            "type": "u128"
          },
          {
            "name": "evaluatedQuoteReserveNad",
            "type": "u128"
          },
          {
            "name": "createdSlot",
            "type": "u64"
          },
          {
            "name": "saturated",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "delegatedCloseLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "minAmountOut",
            "type": "u64"
          },
          {
            "name": "closeBps",
            "docs": [
              "Proportion of the current position to close. `10_000` preserves the",
              "existing full-close behavior."
            ],
            "type": "u16"
          },
          {
            "name": "delegated",
            "type": {
              "defined": {
                "name": "delegatedCpiArgs"
              }
            }
          }
        ]
      }
    },
    {
      "name": "delegatedCpiArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "beforeIxData",
            "type": "bytes"
          },
          {
            "name": "afterIxData",
            "type": "bytes"
          },
          {
            "name": "beforeAccountsLen",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "depositCollateralArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "depositAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "depositSingleSidedArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "depositAmount",
            "type": "u64"
          },
          {
            "name": "minHlpAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "donateCollateralArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "depositAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "emergencyLiquidationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "full",
            "type": "bool"
          },
          {
            "name": "minRewardCredit",
            "type": "u64"
          },
          {
            "name": "minSwapOutput",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "emergencyLiquidationQuote",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referencePriceNad",
            "docs": [
              "Symmetric collateral-price EMA (debt per collateral, NAD), not live spot."
            ],
            "type": "u64"
          },
          {
            "name": "referenceDepthNad",
            "docs": [
              "Smoothed total active curve depth used only for settlement sizing."
            ],
            "type": "u128"
          },
          {
            "name": "full",
            "type": "bool"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "collateralCredit",
            "type": "u64"
          },
          {
            "name": "swapOutput",
            "type": "u64"
          },
          {
            "name": "repayment",
            "type": "u64"
          },
          {
            "name": "sharesToBurn",
            "type": "u128"
          },
          {
            "name": "rewardCredit",
            "type": "u64"
          },
          {
            "name": "rewardDebit",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": {
              "defined": {
                "name": "liquidationFeeAllocation"
              }
            }
          },
          {
            "name": "insuranceFeeDebit",
            "type": "u64"
          },
          {
            "name": "revenueFeeDebit",
            "type": "u64"
          },
          {
            "name": "ownerDebit",
            "type": "u64"
          },
          {
            "name": "ownerCredit",
            "type": "u64"
          },
          {
            "name": "insuranceDebit",
            "type": "u64"
          },
          {
            "name": "loss",
            "type": {
              "defined": {
                "name": "liquidationLossAllocation"
              }
            }
          },
          {
            "name": "healthBefore",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "healthAfter",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "rates",
            "type": {
              "defined": {
                "name": "liquidationRates"
              }
            }
          }
        ]
      }
    },
    {
      "name": "emergencyLiquidationSettled",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "caller",
            "type": "pubkey"
          },
          {
            "name": "leverage",
            "type": "bool"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "emergencyLiquidationQuote"
              }
            }
          },
          {
            "name": "remainingCollateral",
            "type": "u64"
          },
          {
            "name": "remainingDebt",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "feeProfile",
      "docs": [
        "Complete mutable fee surface. The fields remain embedded in their existing",
        "`MarketConfig`/`AmmConfig` locations so this view can be used by typed",
        "governance without duplicating fee state."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "baseFeeBps",
            "type": "u16"
          },
          {
            "name": "divergenceFeeShareCapBps",
            "type": "u16"
          },
          {
            "name": "volatilityFeeShareCapBps",
            "type": "u16"
          },
          {
            "name": "divergenceFeeCoefficientNad",
            "type": "u64"
          },
          {
            "name": "volatilityFeeCoefficientNad",
            "type": "u64"
          },
          {
            "name": "volatilityHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "volatilityShockCapNad",
            "type": "u64"
          },
          {
            "name": "volatilityAccumulatorCapNad",
            "type": "u64"
          },
          {
            "name": "swapFeeCollectMode",
            "type": "u8"
          },
          {
            "name": "compoundingFeeBps",
            "type": "u16"
          },
          {
            "name": "launchFeeStartBps",
            "type": "u16"
          },
          {
            "name": "launchFeeDurationSeconds",
            "type": "u64"
          },
          {
            "name": "launchFeeDecayMode",
            "type": "u8"
          },
          {
            "name": "launchMarketPriceStepBps",
            "type": "u16"
          },
          {
            "name": "launchMarketNumberOfPeriods",
            "type": "u16"
          },
          {
            "name": "launchMarketReductionFactorBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitAsset",
            "type": "u8"
          },
          {
            "name": "launchRateLimitReferenceNad",
            "type": "u64"
          },
          {
            "name": "launchRateLimitIncrementBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitMaxFeeBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitDurationSeconds",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "fees",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "publicInterestAdvance",
            "type": {
              "defined": {
                "name": "publicInterestAdvance"
              }
            }
          },
          {
            "name": "swapFeeGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "interestGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "swapFeeGrowthRemainderScaled",
            "docs": [
              "Scaled fee entitlement not yet representable by the integer growth",
              "index. The corresponding whole-token backing already sits in",
              "`swap_fee_liability`; it must never be redistributed as unallocated",
              "revenue."
            ],
            "type": "u64"
          },
          {
            "name": "interestGrowthRemainderScaled",
            "docs": [
              "Interest counterpart of `swap_fee_growth_remainder_scaled`."
            ],
            "type": "u64"
          },
          {
            "name": "hlpFundingInterestGrowthRemainderScaled",
            "docs": [
              "Source-scoped Q64 carry for interest paid by hLP funding debt. Funding",
              "uses a non-hLP denominator, while public interest uses total yLP",
              "supply; sharing one carry across those denominators would eventually",
              "leak rounding entitlement between the two populations."
            ],
            "type": "u64"
          },
          {
            "name": "swapFeeCustodyBalance",
            "docs": [
              "Claimable swap fees physically held in the reserve vault but excluded",
              "from executable cash and live reserves."
            ],
            "type": "u64"
          },
          {
            "name": "interestVaultBalance",
            "type": "u64"
          },
          {
            "name": "swapFeeLiability",
            "type": "u64"
          },
          {
            "name": "interestLiability",
            "type": "u64"
          },
          {
            "name": "unallocatedSwapFeeLiability",
            "type": "u64"
          },
          {
            "name": "unallocatedInterestLiability",
            "type": "u64"
          },
          {
            "name": "swapProtocolFeeLiability",
            "type": "u64"
          },
          {
            "name": "swapBuybackFeeLiability",
            "type": "u64"
          },
          {
            "name": "interestProtocolFeeLiability",
            "type": "u64"
          },
          {
            "name": "interestBuybackFeeLiability",
            "type": "u64"
          },
          {
            "name": "referralInterestLiability",
            "type": "u64"
          },
          {
            "name": "feeAuctionReferenceMarket",
            "docs": [
              "Governance-approved reference market for fee-lane auctions. A default",
              "key permits only the sold market itself when it directly pairs the sold",
              "and accepted mints."
            ],
            "type": "pubkey"
          },
          {
            "name": "buybackAuctionReferenceMarket",
            "docs": [
              "Governance-approved reference market for buyback-lane auctions. A",
              "default key has the same direct-market-only meaning as above."
            ],
            "type": "pubkey"
          },
          {
            "name": "feeSwapAuctionEpoch",
            "type": {
              "defined": {
                "name": "protocolAuctionEpoch"
              }
            }
          },
          {
            "name": "feeInterestAuctionEpoch",
            "type": {
              "defined": {
                "name": "protocolAuctionEpoch"
              }
            }
          },
          {
            "name": "buybackSwapAuctionEpoch",
            "type": {
              "defined": {
                "name": "protocolAuctionEpoch"
              }
            }
          },
          {
            "name": "buybackInterestAuctionEpoch",
            "type": {
              "defined": {
                "name": "protocolAuctionEpoch"
              }
            }
          }
        ]
      }
    },
    {
      "name": "flashLiquidationBegun",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "session",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "flashLiquidationQuote"
              }
            }
          }
        ]
      }
    },
    {
      "name": "flashLiquidationQuote",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "full",
            "type": "bool"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "collateralCredit",
            "type": "u64"
          },
          {
            "name": "payment",
            "docs": [
              "Bound net spendable payment before distribution, including repayment,",
              "liquidation fee and any full-purchase proceeds belonging to the owner."
            ],
            "type": "u64"
          },
          {
            "name": "repayment",
            "type": "u64"
          },
          {
            "name": "ownerSurplus",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": {
              "defined": {
                "name": "liquidationFeeAllocation"
              }
            }
          },
          {
            "name": "debtSharesToBurn",
            "type": "u128"
          },
          {
            "name": "healthBefore",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "healthAfter",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "rates",
            "type": {
              "defined": {
                "name": "liquidationRates"
              }
            }
          }
        ]
      }
    },
    {
      "name": "flashLiquidationSettled",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "leverage",
            "type": "bool"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "debtRepaid",
            "type": "u64"
          },
          {
            "name": "ownerSurplus",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": {
              "defined": {
                "name": "liquidationFeeAllocation"
              }
            }
          },
          {
            "name": "loss",
            "type": {
              "defined": {
                "name": "liquidationLossAllocation"
              }
            }
          },
          {
            "name": "remainingCollateral",
            "type": "u64"
          },
          {
            "name": "remainingDebt",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "fortifyMarketArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "asset",
            "type": "u8"
          },
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "fundInterestArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "maxBaseGross",
            "docs": [
              "Gross public interest to fund, including the frozen protocol allocation."
            ],
            "type": "u64"
          },
          {
            "name": "maxQuoteGross",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "fundInterestReceipt",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "grossFunded",
            "type": {
              "array": [
                "u64",
                2
              ]
            }
          },
          {
            "name": "lpCustodyCredit",
            "type": {
              "array": [
                "u64",
                2
              ]
            }
          },
          {
            "name": "hlpYieldPublished",
            "docs": [
              "[hLP target side][income side], after covering the funding gap."
            ],
            "type": {
              "array": [
                {
                  "array": [
                    "u64",
                    2
                  ]
                },
                2
              ]
            }
          },
          {
            "name": "hlpCapitalGross",
            "type": {
              "array": [
                {
                  "array": [
                    "u64",
                    2
                  ]
                },
                2
              ]
            }
          },
          {
            "name": "hlpCapitalCredit",
            "type": {
              "array": [
                {
                  "array": [
                    "u64",
                    2
                  ]
                },
                2
              ]
            }
          }
        ]
      }
    },
    {
      "name": "futarchyAuthority",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "type": "u8"
          },
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipients",
            "type": {
              "defined": {
                "name": "revenueRecipients"
              }
            }
          },
          {
            "name": "revenueShare",
            "type": {
              "defined": {
                "name": "revenueShare"
              }
            }
          },
          {
            "name": "maxReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "revenueDistribution",
            "type": {
              "defined": {
                "name": "revenueDistribution"
              }
            }
          },
          {
            "name": "protocolAuctionSplit",
            "type": {
              "defined": {
                "name": "protocolAuctionSplit"
              }
            }
          },
          {
            "name": "feeAuction",
            "type": {
              "defined": {
                "name": "protocolAuctionConfig"
              }
            }
          },
          {
            "name": "buybackAuction",
            "type": {
              "defined": {
                "name": "protocolAuctionConfig"
              }
            }
          },
          {
            "name": "globalReduceOnly",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "governanceBalance",
      "docs": [
        "Owner-held virtual yLP. Both idle and committed shares accrue yield here."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "delegate",
            "docs": [
              "The default key revokes delegation. The owner always retains control."
            ],
            "type": "pubkey"
          },
          {
            "name": "totalAmount",
            "type": "u64"
          },
          {
            "name": "committedAmount",
            "type": "u64"
          },
          {
            "name": "baseYield",
            "type": {
              "defined": {
                "name": "virtualYieldLedger"
              }
            }
          },
          {
            "name": "quoteYield",
            "type": {
              "defined": {
                "name": "virtualYieldLedger"
              }
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "governanceBalanceAction",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "deposit",
            "fields": [
              {
                "name": "amount",
                "type": "u64"
              }
            ]
          },
          {
            "name": "withdraw",
            "fields": [
              {
                "name": "amount",
                "type": "u64"
              }
            ]
          },
          {
            "name": "claimYield"
          }
        ]
      }
    },
    {
      "name": "governanceBalanceUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "governanceBalance",
            "type": "pubkey"
          },
          {
            "name": "delegate",
            "type": "pubkey"
          },
          {
            "name": "action",
            "docs": [
              "0 deposit, 1 withdraw, 2 delegate change, 3 yield checkpoint/claim."
            ],
            "type": "u8"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "totalAmount",
            "type": "u64"
          },
          {
            "name": "committedAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "governanceSupport",
      "docs": [
        "One owner's reusable balance allocated to one proposal. Yield stays on the",
        "balance, so allocation/release cannot duplicate or transfer yield claims."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "governanceBalance",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "rentRefund",
            "type": "pubkey"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "governanceSupportChanged",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "governanceBalance",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "withdrawn",
            "type": "bool"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "ownerSupport",
            "type": "u64"
          },
          {
            "name": "totalLocked",
            "type": "u64"
          },
          {
            "name": "status",
            "type": "u8"
          },
          {
            "name": "proposalTombstoned",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "harvestArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "tokenKind",
            "type": {
              "defined": {
                "name": "yieldTokenKind"
              }
            }
          }
        ]
      }
    },
    {
      "name": "harvestAuthorityUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": "u8"
          },
          {
            "name": "harvestAuthority",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "hlpClosed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "assetSide",
            "docs": [
              "`0` for base hLP and `1` for quote hLP."
            ],
            "type": "u8"
          },
          {
            "name": "hlpAmount",
            "type": "u64"
          },
          {
            "name": "ylpAmount",
            "type": "u64"
          },
          {
            "name": "amountOut",
            "docs": [
              "Amount credited to the owner after any output transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "debtRepaid",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "ylpSupply",
            "type": "u64"
          },
          {
            "name": "hlpSupply",
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "type": "u64"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpCohort",
      "docs": [
        "The mint-specific lifetime of one hLP receipt cohort. While current, the",
        "market vault owns the live accounting. After terminal recovery, this account",
        "holds the final yield indexes and supply so old receipts can be transferred,",
        "harvested and burned without acquiring backing from a new deposit cohort."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "retired",
            "type": "bool"
          },
          {
            "name": "finalVault",
            "type": {
              "defined": {
                "name": "hlpVault"
              }
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "hlpCohortRotated",
      "docs": [
        "A terminal hLP cohort retains its funded yield rights while a new mint",
        "becomes the receipt for future single-sided deposits on the same market."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "retiredMint",
            "type": "pubkey"
          },
          {
            "name": "newMint",
            "type": "pubkey"
          },
          {
            "name": "retiredSupply",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpDepositCapacityPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "targetAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "hlpMint",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "epoch",
            "type": "u64"
          },
          {
            "name": "status",
            "type": {
              "defined": {
                "name": "hlpDepositStatus"
              }
            }
          },
          {
            "name": "fundingLimitGross",
            "docs": [
              "Exact funding ceiling, NOT a promise that all smaller amounts execute.",
              "Actual deposits still enforce rounding, settlement, custody and slippage.",
              "Gross wallet debit, including the current epoch's transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "fundingLimitNet",
            "docs": [
              "Greatest net target reserve credit supported by opposite-asset funding."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpDepositStatus",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "ready"
          },
          {
            "name": "notStarted"
          },
          {
            "name": "reduceOnly"
          },
          {
            "name": "noLiquidity"
          },
          {
            "name": "rebalanceRequired"
          },
          {
            "name": "cashConstrained"
          },
          {
            "name": "unhedgeable"
          },
          {
            "name": "noFundingCapacity"
          },
          {
            "name": "noNetDeposit"
          },
          {
            "name": "frozen"
          }
        ]
      }
    },
    {
      "name": "hlpFlashQuote",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "collateralCredit",
            "type": "u64"
          },
          {
            "name": "borrowedClaim",
            "docs": [
              "Borrowed-token yLP claim frozen when the quote is created. A full",
              "terminal session uses this value even if an interleaved Dusk swap moves",
              "the live pro-rata yLP reserve ratio before settlement."
            ],
            "type": "u64"
          },
          {
            "name": "payment",
            "docs": [
              "Spendable atoms required in the session's payment vault; includes the",
              "transfer fee from that vault to the market reserve."
            ],
            "type": "u64"
          },
          {
            "name": "reserveCredit",
            "type": "u64"
          },
          {
            "name": "discountBps",
            "type": "u16"
          },
          {
            "name": "full",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "hlpFlashSession",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "hlpFlashQuote"
              }
            }
          },
          {
            "name": "maxInsuranceDraw",
            "type": "u64"
          },
          {
            "name": "maxSocializedLoss",
            "type": "u64"
          },
          {
            "name": "paymentBalanceBefore",
            "type": "u64"
          },
          {
            "name": "hlpSupply",
            "type": "u64"
          },
          {
            "name": "beginIndex",
            "type": "u16"
          },
          {
            "name": "settleIndex",
            "type": "u16"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "hlpFlashSettled",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "hlpFlashQuote"
              }
            }
          },
          {
            "name": "baseHlpYlpMinted",
            "docs": [
              "Internal yLP changes made by this flash recovery. They are not user",
              "liquidity deposits or exits and are included here to avoid a second",
              "event CPI on the compute-constrained atomic settlement path."
            ],
            "type": "u64"
          },
          {
            "name": "baseHlpYlpBurned",
            "type": "u64"
          },
          {
            "name": "quoteHlpYlpMinted",
            "type": "u64"
          },
          {
            "name": "quoteHlpYlpBurned",
            "type": "u64"
          },
          {
            "name": "fundingInterestPaid",
            "type": {
              "array": [
                "u64",
                2
              ]
            }
          },
          {
            "name": "loss",
            "type": {
              "defined": {
                "name": "liquidationLossAllocation"
              }
            }
          },
          {
            "name": "insuranceDebit",
            "type": "u64"
          },
          {
            "name": "surplusCredit",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpFlashStarted",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "hlpFlashQuote"
              }
            }
          }
        ]
      }
    },
    {
      "name": "hlpInterestAllocated",
      "docs": [
        "Fresh public repayment follows the same funding-before-yield policy as a",
        "cash advance. The standard hLP prefix is followed by both mints/reserves."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "published",
            "docs": [
              "[hLP target side][income asset]. Historical holder growth is unchanged."
            ],
            "type": {
              "array": [
                {
                  "array": [
                    "u64",
                    2
                  ]
                },
                2
              ]
            }
          },
          {
            "name": "capitalDebit",
            "type": {
              "array": [
                {
                  "array": [
                    "u64",
                    2
                  ]
                },
                2
              ]
            }
          },
          {
            "name": "capitalCredit",
            "type": {
              "array": [
                {
                  "array": [
                    "u64",
                    2
                  ]
                },
                2
              ]
            }
          }
        ]
      }
    },
    {
      "name": "hlpOpened",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "assetSide",
            "docs": [
              "`0` for base hLP and `1` for quote hLP."
            ],
            "type": "u8"
          },
          {
            "name": "depositAmount",
            "docs": [
              "Net reserve-vault credit after any input transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "borrowedAmount",
            "type": "u64"
          },
          {
            "name": "ylpAmount",
            "type": "u64"
          },
          {
            "name": "hlpAmount",
            "type": "u64"
          },
          {
            "name": "ylpSupply",
            "type": "u64"
          },
          {
            "name": "hlpSupply",
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "type": "u64"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpOrderTriggerPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "principalNavPerTokenNad",
            "type": "u64"
          },
          {
            "name": "fundingAprEmaNad",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "hlpRebalanced",
      "docs": [
        "Internal vault-owned yLP changes from one completed hLP hedge transition.",
        "Ordinary yLP deposits and exits continue to use `LiquidityAdded` and",
        "`LiquidityRemoved`. This event includes both vaults because one operation",
        "can burn shares in one vault and mint them in the other. Debt changes are",
        "indexed-debt changes; funding interest is also reported by the canonical",
        "`BorrowInterestPaid` event and must not be counted twice as revenue."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "baseHlpYlpMinted",
            "type": "u64"
          },
          {
            "name": "baseHlpYlpBurned",
            "type": "u64"
          },
          {
            "name": "quoteHlpYlpMinted",
            "type": "u64"
          },
          {
            "name": "quoteHlpYlpBurned",
            "type": "u64"
          },
          {
            "name": "baseHlpYlpSharesAfter",
            "type": "u64"
          },
          {
            "name": "quoteHlpYlpSharesAfter",
            "type": "u64"
          },
          {
            "name": "ylpSupplyAfter",
            "type": "u64"
          },
          {
            "name": "baseHlpDebtIncrease",
            "docs": [
              "Quote-token debt of the base-target hLP."
            ],
            "type": "u64"
          },
          {
            "name": "baseHlpDebtDecrease",
            "type": "u64"
          },
          {
            "name": "baseHlpDebtAfter",
            "type": "u64"
          },
          {
            "name": "quoteHlpDebtIncrease",
            "docs": [
              "Base-token debt of the quote-target hLP."
            ],
            "type": "u64"
          },
          {
            "name": "quoteHlpDebtDecrease",
            "type": "u64"
          },
          {
            "name": "quoteHlpDebtAfter",
            "type": "u64"
          },
          {
            "name": "baseHlpFundingInterestPaid",
            "docs": [
              "Gross quote tokens paid from reserve cash to the interest vault."
            ],
            "type": "u64"
          },
          {
            "name": "quoteHlpFundingInterestPaid",
            "docs": [
              "Gross base tokens paid from reserve cash to the interest vault."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpRetiredReceiptBurned",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "remainingSupply",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpTerminalLiquidated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "caller",
            "type": "pubkey"
          },
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "debtClosed",
            "type": "u64"
          },
          {
            "name": "ylpBurned",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "docs": [
              "Borrowed-asset funding interest credited to yLP after caller bounty and",
              "transfer fees."
            ],
            "type": "u64"
          },
          {
            "name": "callerBounty",
            "docs": [
              "Borrowed-asset amount credited to the caller after transfer fees."
            ],
            "type": "u64"
          },
          {
            "name": "insuranceDrawn",
            "type": "u64"
          },
          {
            "name": "socializedLoss",
            "docs": [
              "Principal loss after insurance. Unpaid interest is reported separately."
            ],
            "type": "u64"
          },
          {
            "name": "interestCanceled",
            "type": "u64"
          },
          {
            "name": "remainingHlpSupply",
            "docs": [
              "Existing holder tokens remain burnable for zero principal while their",
              "already-checkpointed fee claims remain independently claimable."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpVault",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "flashCollateralDebit",
            "docs": [
              "Collateral committed to one atomic flash recovery. Receipt supply is",
              "fixed until settlement; retail operations on other positions may run."
            ],
            "type": "u64"
          },
          {
            "name": "ylpVault",
            "type": "pubkey"
          },
          {
            "name": "ylpShares",
            "type": "u64"
          },
          {
            "name": "baseHlpLiveReserve",
            "docs": [
              "hLP-owned live reserve depth that is not backed by reserve cash or",
              "normal cash-backed debt. This is the explicit synthetic live component",
              "in `r_virtual = r_cash + r_cash_backed_debt + r_hlp_live`."
            ],
            "type": "u64"
          },
          {
            "name": "quoteHlpLiveReserve",
            "type": "u64"
          },
          {
            "name": "debtShares",
            "docs": [
              "Funding debt used by the hLP vault. It accrues interest and counts",
              "toward utilization, but is not same-side cash-backed reserve debt."
            ],
            "type": "u128"
          },
          {
            "name": "debtPrincipal",
            "docs": [
              "Raw borrowed token atoms; products and indexed shares stay `u128`."
            ],
            "type": "u64"
          },
          {
            "name": "hlpSupply",
            "type": "u64"
          },
          {
            "name": "residualExposure",
            "type": "i128"
          },
          {
            "name": "baseSwapFeeGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "baseInterestGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "quoteSwapFeeGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "quoteInterestGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "baseSwapFeeCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "baseInterestCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "quoteSwapFeeCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "quoteInterestCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "baseSwapFeeRemainderQ64",
            "docs": [
              "Aggregate sub-atom yLP entitlement carried across hLP checkpoints.",
              "These are distinct from each holder YieldAccount remainder: this layer",
              "converts vault-owned yLP growth into hLP growth without double-flooring."
            ],
            "type": "u64"
          },
          {
            "name": "baseInterestRemainderQ64",
            "type": "u64"
          },
          {
            "name": "quoteSwapFeeRemainderQ64",
            "type": "u64"
          },
          {
            "name": "quoteInterestRemainderQ64",
            "type": "u64"
          },
          {
            "name": "baseSwapFeeGrowthRemainderScaled",
            "docs": [
              "Sub-index distribution carry for the second, yLP-to-hLP allocation",
              "layer. Whole-token backing represented here has already left the",
              "corresponding `unallocated_*` bucket."
            ],
            "type": "u64"
          },
          {
            "name": "baseInterestGrowthRemainderScaled",
            "type": "u64"
          },
          {
            "name": "quoteSwapFeeGrowthRemainderScaled",
            "type": "u64"
          },
          {
            "name": "quoteInterestGrowthRemainderScaled",
            "type": "u64"
          },
          {
            "name": "unallocatedBaseSwapFeeAmount",
            "type": "u64"
          },
          {
            "name": "unallocatedBaseInterestAmount",
            "type": "u64"
          },
          {
            "name": "unallocatedQuoteSwapFeeAmount",
            "type": "u64"
          },
          {
            "name": "unallocatedQuoteInterestAmount",
            "type": "u64"
          },
          {
            "name": "lastNavNad",
            "type": "u128"
          },
          {
            "name": "cachedSettlementPriceNad",
            "docs": [
              "Base quoted in quote NAD units for either target asset; zero means unset."
            ],
            "type": "u128"
          },
          {
            "name": "fundingAprEmaNad",
            "docs": [
              "Smoothed APR of the opposite asset borrowed by this target-asset hLP.",
              "The fixed twelve-hour half-life gives Stop Rate orders stable semantics."
            ],
            "type": "u128"
          },
          {
            "name": "fundingAprEmaLastSlot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "increaseLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "debtAmount",
            "type": "u64"
          },
          {
            "name": "marginAmount",
            "docs": [
              "Gross debt-token funding from the owner. Zero increases size using borrowing only."
            ],
            "type": "u64"
          },
          {
            "name": "minCollateralOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "initFutarchyAuthorityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "swapBps",
            "docs": [
              "None uses DEFAULT_PROTOCOL_REVENUE_SHARE_BPS; Some(0) explicitly disables the share."
            ],
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "interestBps",
            "docs": [
              "None uses DEFAULT_PROTOCOL_REVENUE_SHARE_BPS; Some(0) explicitly disables the share."
            ],
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "maxReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "futarchyTreasury",
            "type": "pubkey"
          },
          {
            "name": "futarchyTreasuryBps",
            "type": "u16"
          },
          {
            "name": "buybacksVault",
            "type": "pubkey"
          },
          {
            "name": "buybacksVaultBps",
            "type": "u16"
          },
          {
            "name": "teamTreasury",
            "type": "pubkey"
          },
          {
            "name": "teamTreasuryBps",
            "type": "u16"
          },
          {
            "name": "stakingVault",
            "type": "pubkey"
          },
          {
            "name": "feeAuctionAcceptedMint",
            "type": "pubkey"
          },
          {
            "name": "buybackAuctionAcceptedMint",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "initializeLpMetadataArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "name",
            "type": "string"
          },
          {
            "name": "symbol",
            "type": "string"
          },
          {
            "name": "uri",
            "type": "string"
          }
        ]
      }
    },
    {
      "name": "initializeMarketArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "config",
            "type": {
              "defined": {
                "name": "marketConfig"
              }
            }
          },
          {
            "name": "paramsHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "bootstrapPriceNad",
            "docs": [
              "Optional final bootstrap price imported by a permissionless launch",
              "adapter. Zero binds the reference to the first fully-backed seed."
            ],
            "type": "u64"
          },
          {
            "name": "launchFeeProgressOffset",
            "docs": [
              "Number of price-fee periods already completed before graduation."
            ],
            "type": "u16"
          },
          {
            "name": "ylpMetadata",
            "docs": [
              "Metadata for the three LP mints, created atomically with the market."
            ],
            "type": {
              "defined": {
                "name": "initializeLpMetadataArgs"
              }
            }
          },
          {
            "name": "baseHlpMetadata",
            "type": {
              "defined": {
                "name": "initializeLpMetadataArgs"
              }
            }
          },
          {
            "name": "quoteHlpMetadata",
            "type": {
              "defined": {
                "name": "initializeLpMetadataArgs"
              }
            }
          }
        ]
      }
    },
    {
      "name": "initializeYieldAccountsArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": {
              "defined": {
                "name": "yieldTokenKind"
              }
            }
          }
        ]
      }
    },
    {
      "name": "insurance",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "baseVault",
            "type": "pubkey"
          },
          {
            "name": "quoteVault",
            "type": "pubkey"
          },
          {
            "name": "baseAvailable",
            "type": "u64"
          },
          {
            "name": "quoteAvailable",
            "type": "u64"
          },
          {
            "name": "baseDrawWindow",
            "type": {
              "defined": {
                "name": "insuranceDrawWindow"
              }
            }
          },
          {
            "name": "quoteDrawWindow",
            "type": {
              "defined": {
                "name": "insuranceDrawWindow"
              }
            }
          },
          {
            "name": "principalCoverageBps",
            "docs": [
              "Maximum share of a borrower/leverage principal shortfall covered by",
              "insurance. hLP funding claims use their own eligible-loss definition."
            ],
            "type": "u16"
          },
          {
            "name": "perDayDrawBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "insuranceDonated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "donor",
            "type": "pubkey"
          },
          {
            "name": "asset",
            "docs": [
              "`0` for Base and `1` for Quote."
            ],
            "type": "u8"
          },
          {
            "name": "requestedAmount",
            "docs": [
              "Gross amount requested from the donor's token account."
            ],
            "type": "u64"
          },
          {
            "name": "creditedAmount",
            "docs": [
              "Net amount received after any Token-2022 transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "availableAfter",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "insuranceDrawWindow",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "initialized",
            "docs": [
              "`start_slot` may legitimately be zero in a test or newly started bank;",
              "keep initialization separate rather than using a sentinel slot."
            ],
            "type": "bool"
          },
          {
            "name": "startSlot",
            "docs": [
              "Start of the nominal 24-hour window, measured in consensus slots."
            ],
            "type": "u64"
          },
          {
            "name": "openingAvailable",
            "docs": [
              "Available insurance at the start of the window, before any draws."
            ],
            "type": "u64"
          },
          {
            "name": "credited",
            "docs": [
              "Net token credits received after the window opened."
            ],
            "type": "u64"
          },
          {
            "name": "drawn",
            "docs": [
              "Gross token amount debited by insurance draws in this window."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "irmConfig",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetUtilizationBps",
            "type": "u16"
          },
          {
            "name": "curveSteepnessNad",
            "type": "u64"
          },
          {
            "name": "adjustmentSpeedPerYear",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "leverageDelegation",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "delegatedProgram",
            "type": "pubkey"
          },
          {
            "name": "approvedActions",
            "type": "u32"
          },
          {
            "name": "openCurveRevision",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "leverageDelegationUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "delegation",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "delegatedProgram",
            "type": "pubkey"
          },
          {
            "name": "approvedActions",
            "type": "u32"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leverageMarginTerms",
      "docs": [
        "Entry terms are snapshotted in collateral units. Price, LP activity and",
        "another trader's position cannot passively rebase an existing position."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referenceCollateral",
            "type": "u64"
          },
          {
            "name": "maintenanceBoundariesBps",
            "type": {
              "array": [
                "u16",
                2
              ]
            }
          },
          {
            "name": "maintenanceRatesBps",
            "type": {
              "array": [
                "u16",
                3
              ]
            }
          },
          {
            "name": "entryBufferBps",
            "type": "u16"
          },
          {
            "name": "admissionEquityCollateralNad",
            "docs": [
              "Collateral atoms times NAD, not a fixed debt-token or dollar amount.",
              "Retained on equity extraction; released proportionally on size reduction."
            ],
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "leveragePosition",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "namespaceAuthority",
            "docs": [
              "Funding signer that established this position. Ordinary opens use the",
              "owner; sponsored entry orders use their owner-created order PDA."
            ],
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "referralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "marginTerms",
            "type": {
              "defined": {
                "name": "leverageMarginTerms"
              }
            }
          },
          {
            "name": "marginAmount",
            "docs": [
              "Entry equity valued in debt-token atoms."
            ],
            "type": "u64"
          },
          {
            "name": "openNotional",
            "type": "u64"
          },
          {
            "name": "debtPrincipal",
            "type": "u128"
          },
          {
            "name": "debtShares",
            "type": "u128"
          },
          {
            "name": "multiplierBps",
            "type": "u64"
          },
          {
            "name": "openedAt",
            "type": "i64"
          },
          {
            "name": "openedSlot",
            "type": "u64"
          },
          {
            "name": "openCurveRevision",
            "docs": [
              "Market curve revision committed by this opening. A recreated PDA gets",
              "a new revision even if it reopens in the same slot."
            ],
            "type": "u64"
          },
          {
            "name": "activeLiquidationSession",
            "type": "pubkey"
          },
          {
            "name": "distress",
            "type": {
              "defined": {
                "name": "liquidationDistress"
              }
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "leveragePositionClosed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralAssetMint",
            "type": "pubkey"
          },
          {
            "name": "debtRepaid",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "collateralSold",
            "type": "u64"
          },
          {
            "name": "closeoutValue",
            "type": "u64"
          },
          {
            "name": "residual",
            "type": "u64"
          },
          {
            "name": "swap",
            "type": {
              "defined": {
                "name": "leverageSwapReceipt"
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leveragePositionLiquidated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "liquidator",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralAssetMint",
            "type": "pubkey"
          },
          {
            "name": "debtRepaid",
            "type": "u64"
          },
          {
            "name": "insuranceDrawn",
            "type": "u64"
          },
          {
            "name": "socializedLoss",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "principalWrittenOff",
            "type": "u64"
          },
          {
            "name": "collateralSold",
            "type": "u64"
          },
          {
            "name": "closeoutValue",
            "type": "u64"
          },
          {
            "name": "liquidatorAmount",
            "type": "u64"
          },
          {
            "name": "ownerResidual",
            "type": "u64"
          },
          {
            "name": "swap",
            "type": {
              "defined": {
                "name": "leverageSwapReceipt"
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leveragePositionOpened",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralAssetMint",
            "type": "pubkey"
          },
          {
            "name": "marginAmount",
            "type": "u64"
          },
          {
            "name": "borrowedAmount",
            "type": "u64"
          },
          {
            "name": "debtAmount",
            "type": "u64"
          },
          {
            "name": "debtShares",
            "type": "u128"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "marginTerms",
            "type": {
              "defined": {
                "name": "leverageMarginTerms"
              }
            }
          },
          {
            "name": "closeoutValue",
            "type": "u64"
          },
          {
            "name": "equity",
            "type": "u64"
          },
          {
            "name": "multiplierBps",
            "type": "u64"
          },
          {
            "name": "swap",
            "type": {
              "defined": {
                "name": "leverageSwapReceipt"
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leveragePositionUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralAssetMint",
            "type": "pubkey"
          },
          {
            "name": "ownerDebit",
            "docs": [
              "Gross debt-token payment from the wallet, including any transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "borrowedAmount",
            "type": "u64"
          },
          {
            "name": "debtDelta",
            "type": "i64"
          },
          {
            "name": "collateralDelta",
            "type": "i64"
          },
          {
            "name": "debtAmount",
            "type": "u64"
          },
          {
            "name": "debtShares",
            "type": "u128"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "marginTerms",
            "type": {
              "defined": {
                "name": "leverageMarginTerms"
              }
            }
          },
          {
            "name": "closeoutValue",
            "docs": [
              "Executable closeout quote, or zero when unquoted by repayment or an",
              "operation leaving debt-free collateral. Zero is not a collateral valuation."
            ],
            "type": "u64"
          },
          {
            "name": "ownerCredit",
            "docs": [
              "Net tokens paid to the owner by this update, if any."
            ],
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "docs": [
              "Interest actually repaid by this action, in debt-token atoms."
            ],
            "type": "u64"
          },
          {
            "name": "swap",
            "type": {
              "option": {
                "defined": {
                  "name": "leverageSwapReceipt"
                }
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leverageSwapReceipt",
      "docs": [
        "Supporting AMM receipt embedded in a leverage action. `SwapExecuted` is",
        "the authoritative swap/fee record; do not count this receipt again.",
        "`None` on `LeveragePositionUpdated` means the action was margin-only."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "assetInSide",
            "type": "u8"
          },
          {
            "name": "feeAssetSide",
            "type": "u8"
          },
          {
            "name": "amountIn",
            "type": "u64"
          },
          {
            "name": "amountOut",
            "type": "u64"
          },
          {
            "name": "grossAmountOut",
            "type": "u64"
          },
          {
            "name": "amountInAfterFee",
            "type": "u64"
          },
          {
            "name": "baseFee",
            "type": "u64"
          },
          {
            "name": "divergenceFee",
            "type": "u64"
          },
          {
            "name": "volatilityFee",
            "type": "u64"
          },
          {
            "name": "retainedFee",
            "type": "u64"
          },
          {
            "name": "compoundedFee",
            "type": "u64"
          },
          {
            "name": "claimableFeeCredit",
            "docs": [
              "Actual reserve-vault credit after any Token-2022 transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "docs": [
              "Final executable reserves after retention and inline hLP correction."
            ],
            "type": "u64"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "liquidationAuctionCancelled",
      "docs": [
        "A fill or backstop found the position healthy again and cleared its",
        "auction without liquidating anything."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetSide",
            "docs": [
              "Debt side of the cancelled auction: `0` for base and `1` for quote."
            ],
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "liquidationAuctionStarted",
      "docs": [
        "A liquidation auction opened on a borrow position."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "auctionDebtAsset",
            "docs": [
              "`0` for base debt and `1` for quote debt."
            ],
            "type": "u8"
          },
          {
            "name": "auctionStartTime",
            "type": "i64"
          },
          {
            "name": "auctionStartPriceNad",
            "type": "u64"
          },
          {
            "name": "auctionFloorPriceNad",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "liquidationDistress",
      "docs": [
        "A committed observation is separate from an atomic flash transaction: a",
        "reverted route must not erase the incentive clock. Each debt leg owns its",
        "episode. Recovery ends it; a useful partial while still unhealthy does not."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "active",
            "type": "bool"
          },
          {
            "name": "startedAt",
            "type": "i64"
          },
          {
            "name": "observedSlot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "liquidationFeeAllocation",
      "docs": [
        "Whole spendable atoms. Transfer-fee gross-ups are separate from the net fee",
        "obligation. The collected fee is never counted again as debt repayment."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "total",
            "type": "u64"
          },
          {
            "name": "protocol",
            "type": "u64"
          },
          {
            "name": "insurance",
            "type": "u64"
          },
          {
            "name": "lp",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "liquidationHealth",
      "docs": [
        "Linear symmetric-EMA collateral value and actual indexed debt, both in debt",
        "token atoms. Execution prices never determine reference eligibility."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "collateralValue",
            "type": "u64"
          },
          {
            "name": "debt",
            "type": "u64"
          },
          {
            "name": "maintenanceBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "liquidationLossAllocation",
      "docs": [
        "A completed debt leg. `sale_recovery` is net of the caller reward and actual",
        "transfer costs. Insurance never pays unpaid borrower/leverage interest."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "principalRepaid",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "insuranceCredit",
            "type": "u64"
          },
          {
            "name": "principalWrittenOff",
            "type": "u64"
          },
          {
            "name": "interestCanceled",
            "type": "u64"
          },
          {
            "name": "surplus",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "liquidationObserved",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "health",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "distress",
            "type": {
              "defined": {
                "name": "liquidationDistress"
              }
            }
          }
        ]
      }
    },
    {
      "name": "liquidationRates",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "buyerDiscountBps",
            "type": "u16"
          },
          {
            "name": "emergencyRewardBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "liquidationSession",
      "docs": [
        "Exists only from begin through the exact paired settle in one transaction.",
        "Original debt and collateral allocations remain on the locked position."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "collateralMint",
            "type": "pubkey"
          },
          {
            "name": "debtMint",
            "type": "pubkey"
          },
          {
            "name": "collateralVault",
            "type": "pubkey"
          },
          {
            "name": "buyerCollateralAccount",
            "type": "pubkey"
          },
          {
            "name": "repaymentVault",
            "type": "pubkey"
          },
          {
            "name": "buyerRefundAccount",
            "type": "pubkey"
          },
          {
            "name": "ownerDebtAccount",
            "type": "pubkey"
          },
          {
            "name": "originalCollateral",
            "type": "u64"
          },
          {
            "name": "originalDebtShares",
            "type": "u128"
          },
          {
            "name": "originalPrincipal",
            "type": "u128"
          },
          {
            "name": "borrowIndex",
            "type": "u128"
          },
          {
            "name": "paymentBalanceBefore",
            "type": "u64"
          },
          {
            "name": "insuranceBalanceAtQuote",
            "type": "u64"
          },
          {
            "name": "insuranceTargetAtQuote",
            "type": "u64"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "flashLiquidationQuote"
              }
            }
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "leverage",
            "type": "bool"
          },
          {
            "name": "beginIndex",
            "type": "u16"
          },
          {
            "name": "settleIndex",
            "type": "u16"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "liquidityAdded",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "baseReserveCredit",
            "type": "u64"
          },
          {
            "name": "quoteReserveCredit",
            "type": "u64"
          },
          {
            "name": "ylpAmount",
            "type": "u64"
          },
          {
            "name": "ylpSupply",
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "type": "u64"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "liquidityRemoved",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "ylpAmount",
            "type": "u64"
          },
          {
            "name": "baseReserveDebit",
            "docs": [
              "Gross amounts debited from the reserve vaults."
            ],
            "type": "u64"
          },
          {
            "name": "quoteReserveDebit",
            "type": "u64"
          },
          {
            "name": "baseOwnerCredit",
            "docs": [
              "Net amounts credited to the owner after any Token-2022 transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "quoteOwnerCredit",
            "type": "u64"
          },
          {
            "name": "ylpSupply",
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "type": "u64"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "lpTransferred",
      "docs": [
        "One LP transfer checkpointed by the Dusk Token-2022 transfer hook. Only mints",
        "whose extra-account list includes the event authority and Dusk program",
        "publish it; mints initialized before that layout transfer without it."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "docs": [
              "`0` for yLP and `1` for hLP."
            ],
            "type": "u8"
          },
          {
            "name": "sourceOwner",
            "type": "pubkey"
          },
          {
            "name": "destinationOwner",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "market",
      "docs": [
        "Token amounts stored in reserves, positions, and shares are raw atoms.",
        "Internal curve quantities, risk depths, hLP NAV/exposure, and normalized",
        "debt/collateral values use `max(9, base_side.asset_decimals,",
        "quote_side.asset_decimals)` decimal places, including quantity fields with",
        "the historical `_nad` suffix. Prices, rates, and per-share ratios always",
        "retain nine-decimal NAD scaling. The quantity scale is immutable per market."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "type": "u8"
          },
          {
            "name": "ylpMint",
            "type": "pubkey"
          },
          {
            "name": "baseSide",
            "type": {
              "defined": {
                "name": "marketSide"
              }
            }
          },
          {
            "name": "quoteSide",
            "type": {
              "defined": {
                "name": "marketSide"
              }
            }
          },
          {
            "name": "config",
            "type": {
              "defined": {
                "name": "marketConfig"
              }
            }
          },
          {
            "name": "amm",
            "type": {
              "defined": {
                "name": "ammState"
              }
            }
          },
          {
            "name": "debt",
            "type": {
              "defined": {
                "name": "debt"
              }
            }
          },
          {
            "name": "baseHlpVault",
            "type": {
              "defined": {
                "name": "hlpVault"
              }
            }
          },
          {
            "name": "quoteHlpVault",
            "type": {
              "defined": {
                "name": "hlpVault"
              }
            }
          },
          {
            "name": "risk",
            "type": {
              "defined": {
                "name": "risk"
              }
            }
          },
          {
            "name": "insurance",
            "type": {
              "defined": {
                "name": "insurance"
              }
            }
          },
          {
            "name": "paramsHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "initialLiquidityAuthority",
            "docs": [
              "One-shot signer allowed to provide the first fully-backed Base/Quote",
              "seed. It is cleared permanently once yLP supply becomes nonzero."
            ],
            "type": "pubkey"
          },
          {
            "name": "governanceLockedYlp",
            "docs": [
              "External yLP burned into direct support or reusable governance balances. This is added back",
              "when computing direct-yLP eligibility; internal reserve-share supply is",
              "intentionally unchanged by governance locking."
            ],
            "type": "u64"
          },
          {
            "name": "parameterRevisions",
            "docs": [
              "Independent monotone revisions for fee, concentration, IRM, EMA,",
              "daily-borrow-limit, and center-controller parameter families."
            ],
            "type": {
              "array": [
                "u64",
                7
              ]
            }
          },
          {
            "name": "lastMarginalObservationNad",
            "docs": [
              "Latest trader-visible marginal price committed by a curve mutation."
            ],
            "type": "u64"
          },
          {
            "name": "curveRevision",
            "docs": [
              "Monotone revision for executable-curve mutations."
            ],
            "type": "u64"
          },
          {
            "name": "riskRevision",
            "docs": [
              "Curve revision represented by the materialized lending-risk snapshot."
            ],
            "type": "u64"
          },
          {
            "name": "lastUpdateSlot",
            "type": "u64"
          },
          {
            "name": "reduceOnly",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "marketAsset",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "base"
          },
          {
            "name": "quote"
          }
        ]
      }
    },
    {
      "name": "marketCollateralDeposited",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralCredit",
            "type": "u64"
          },
          {
            "name": "baseCollateral",
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          },
          {
            "name": "position",
            "docs": [
              "Borrow position written by this deposit; the first deposit creates it."
            ],
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "auctionDebtAsset",
            "docs": [
              "Post-deposit auction side, `255` when none is active. A deposit that",
              "restores health cancels an active auction."
            ],
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "marketCollateralWithdrawn",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "assetCredit",
            "type": "u64"
          },
          {
            "name": "baseCollateral",
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "closed",
            "docs": [
              "The withdrawal emptied the position and closed its account."
            ],
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "marketConfig",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "swapFeeBps",
            "type": "u16"
          },
          {
            "name": "divergenceFeeShareCapBps",
            "type": "u16"
          },
          {
            "name": "volatilityFeeShareCapBps",
            "type": "u16"
          },
          {
            "name": "targetHlpLeverageBps",
            "type": "u16"
          },
          {
            "name": "settlementDivergenceBps",
            "type": "u16"
          },
          {
            "name": "emaHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "directionalEmaHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "curveDepthEmaHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "maxDailyBorrowBps",
            "type": "u16"
          },
          {
            "name": "globalHealthContributionCapBps",
            "type": "u16"
          },
          {
            "name": "borrowMarketHealthFloorBps",
            "type": "u16"
          },
          {
            "name": "amm",
            "type": {
              "defined": {
                "name": "ammConfig"
              }
            }
          },
          {
            "name": "irm",
            "type": {
              "defined": {
                "name": "irmConfig"
              }
            }
          },
          {
            "name": "startTime",
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "marketCreated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "baseMint",
            "type": "pubkey"
          },
          {
            "name": "quoteMint",
            "type": "pubkey"
          },
          {
            "name": "ylpMint",
            "type": "pubkey"
          },
          {
            "name": "baseCollateralVault",
            "type": "pubkey"
          },
          {
            "name": "quoteCollateralVault",
            "type": "pubkey"
          },
          {
            "name": "baseInsuranceVault",
            "type": "pubkey"
          },
          {
            "name": "quoteInsuranceVault",
            "type": "pubkey"
          },
          {
            "name": "baseHlpMint",
            "type": "pubkey"
          },
          {
            "name": "quoteHlpMint",
            "type": "pubkey"
          },
          {
            "name": "targetHlpLeverageBps",
            "type": "u16"
          },
          {
            "name": "swapFeeBps",
            "type": "u16"
          },
          {
            "name": "config",
            "type": {
              "defined": {
                "name": "marketConfig"
              }
            }
          },
          {
            "name": "paramsHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "initialLiquidityAuthority",
            "type": "pubkey"
          },
          {
            "name": "launchReferencePriceNad",
            "type": "u64"
          },
          {
            "name": "launchFeeProgressOffset",
            "type": "u16"
          },
          {
            "name": "version",
            "type": "u8"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          },
          {
            "name": "baseDecimals",
            "docs": [
              "Asset mint decimals, which scale every price and amount of the market."
            ],
            "type": "u8"
          },
          {
            "name": "quoteDecimals",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "marketDebtUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "debtDelta",
            "type": "i64"
          },
          {
            "name": "cashDebit",
            "docs": [
              "Gross source-account debit and net destination-account credit."
            ],
            "type": "u64"
          },
          {
            "name": "cashCredit",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "fixedBaseDebt",
            "docs": [
              "Market-wide fixed debt after the update, not this position's debt."
            ],
            "type": "u128"
          },
          {
            "name": "fixedQuoteDebt",
            "type": "u128"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "baseDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "quoteDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          },
          {
            "name": "fixedBaseShares",
            "docs": [
              "The position's fixed debt shares after the update."
            ],
            "type": "u128"
          },
          {
            "name": "fixedQuoteShares",
            "type": "u128"
          },
          {
            "name": "auctionDebtAsset",
            "docs": [
              "Post-update auction side, `255` when none is active. A repayment that",
              "restores health cancels an active auction."
            ],
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "marketEventMetadata",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "signer",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "marketHealth",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "effectiveBaseDebtNad",
            "type": "u128"
          },
          {
            "name": "effectiveQuoteDebtNad",
            "type": "u128"
          },
          {
            "name": "baseDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "quoteDebtHealthBps",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "marketHealthUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "effectiveBaseDebtNad",
            "type": "u128"
          },
          {
            "name": "effectiveQuoteDebtNad",
            "type": "u128"
          },
          {
            "name": "baseDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "quoteDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "marketParameterUpdate",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "fee",
            "fields": [
              {
                "defined": {
                  "name": "feeProfile"
                }
              }
            ]
          },
          {
            "name": "concentration",
            "fields": [
              {
                "name": "peakAmplificationNad",
                "type": "u64"
              },
              {
                "name": "coreHalfWidthBps",
                "type": "u16"
              },
              {
                "name": "fadeWidthBps",
                "type": "u16"
              }
            ]
          },
          {
            "name": "irm",
            "fields": [
              {
                "defined": {
                  "name": "irmConfig"
                }
              }
            ]
          },
          {
            "name": "emaHalfLives",
            "fields": [
              {
                "name": "priceMs",
                "type": "u64"
              },
              {
                "name": "directionalPriceMs",
                "type": "u64"
              },
              {
                "name": "curveDepthMs",
                "type": "u64"
              },
              {
                "name": "centerPriceMs",
                "type": "u64"
              }
            ]
          },
          {
            "name": "dailyBorrowLimit",
            "fields": [
              {
                "name": "maxDailyBorrowBps",
                "type": "u16"
              }
            ]
          },
          {
            "name": "centerController",
            "fields": [
              {
                "name": "adjustmentThresholdNad",
                "type": "u64"
              },
              {
                "name": "adjustmentStepNad",
                "type": "u64"
              },
              {
                "name": "minAdjustmentIntervalSlots",
                "type": "u64"
              }
            ]
          },
          {
            "name": "insuranceDrawCaps",
            "fields": [
              {
                "name": "principalCoverageBps",
                "type": "u16"
              },
              {
                "name": "perDayBps",
                "type": "u16"
              }
            ]
          }
        ]
      }
    },
    {
      "name": "marketPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "base",
            "type": {
              "defined": {
                "name": "previewSide"
              }
            }
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "previewSide"
              }
            }
          },
          {
            "name": "liquidityNad",
            "type": "u128"
          },
          {
            "name": "health",
            "type": {
              "defined": {
                "name": "marketHealth"
              }
            }
          },
          {
            "name": "amm",
            "type": {
              "defined": {
                "name": "previewAmm"
              }
            }
          }
        ]
      }
    },
    {
      "name": "marketReduceOnlyUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "reduceOnly",
            "type": "bool"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "marketSide",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "assetDecimals",
            "type": "u8"
          },
          {
            "name": "hlpMint",
            "type": "pubkey"
          },
          {
            "name": "reserveVault",
            "type": "pubkey"
          },
          {
            "name": "collateralVault",
            "type": "pubkey"
          },
          {
            "name": "interestVault",
            "type": "pubkey"
          },
          {
            "name": "reserves",
            "type": {
              "defined": {
                "name": "reserves"
              }
            }
          },
          {
            "name": "shares",
            "type": {
              "defined": {
                "name": "reserveShares"
              }
            }
          },
          {
            "name": "fees",
            "type": {
              "defined": {
                "name": "fees"
              }
            }
          },
          {
            "name": "dailyBorrowBucket",
            "type": {
              "defined": {
                "name": "dailyBorrowBucket"
              }
            }
          }
        ]
      }
    },
    {
      "name": "marketSideSnapshot",
      "docs": [
        "One side of the market after a swap. Prices quote this side's asset in",
        "the opposite asset and equal `preview_market` for the same state and slot."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "spotPriceNad",
            "docs": [
              "Marginal price at this post-swap state. A later controller step or",
              "market update can change it before another trade is quoted."
            ],
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "docs": [
              "Symmetric risk EMA of the spot price."
            ],
            "type": "u64"
          },
          {
            "name": "swapFeeGrowthIndexQ64",
            "docs": [
              "Per-yLP-share swap-fee growth, scaled by 2^64."
            ],
            "type": "u128"
          },
          {
            "name": "interestGrowthIndexQ64",
            "docs": [
              "Per-yLP-share interest growth, scaled by 2^64."
            ],
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "openLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "marginAmount",
            "type": "u64"
          },
          {
            "name": "multiplierBps",
            "type": "u64"
          },
          {
            "name": "minCollateralOut",
            "type": "u64"
          },
          {
            "name": "referrer",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "positionOwner",
            "docs": [
              "Optional beneficiary for sponsored/delegated opens. The funding signer",
              "still supplies the margin, while the resulting position belongs to this",
              "key. `None` preserves the ordinary self-funded path."
            ],
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "limitPriceNad",
            "docs": [
              "All-in average execution limit in Quote-per-Base NAD. Zero disables the",
              "limit. Long Base requires price <= limit; long Quote requires >= limit."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "parameterProposal",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "proposer",
            "type": "pubkey"
          },
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "updates",
            "docs": [
              "The families this proposal changes, one update each, in ascending",
              "family order. They execute together or not at all."
            ],
            "type": {
              "vec": {
                "defined": {
                  "name": "marketParameterUpdate"
                }
              }
            }
          },
          {
            "name": "familyRevisions",
            "docs": [
              "The revision of each updated family when the proposal was created; an",
              "executed change to any of them makes this proposal stale. Families the",
              "proposal does not update read zero."
            ],
            "type": {
              "array": [
                "u64",
                7
              ]
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "proposalMetadataV1"
              }
            }
          },
          {
            "name": "digest",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "status",
            "type": {
              "defined": {
                "name": "parameterProposalStatus"
              }
            }
          },
          {
            "name": "sponsorshipFloor",
            "docs": [
              "Frozen minimum support needed to keep this proposal alive after its",
              "initial 1% sponsorship burn-lock."
            ],
            "type": "u64"
          },
          {
            "name": "totalLocked",
            "type": "u64"
          },
          {
            "name": "queuedSupport",
            "docs": [
              "Immutable queue-time numerator and direct-yLP denominator."
            ],
            "type": "u64"
          },
          {
            "name": "queuedEligibleYlp",
            "type": "u64"
          },
          {
            "name": "createdAt",
            "type": "i64"
          },
          {
            "name": "queuedAt",
            "type": "i64"
          },
          {
            "name": "executeAfter",
            "type": "i64"
          },
          {
            "name": "executionDeadline",
            "type": "i64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "parameterProposalCreated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "proposer",
            "type": "pubkey"
          },
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "familyRevisions",
            "docs": [
              "Each updated family's revision at creation; untouched families read",
              "zero. The family of every update is its variant."
            ],
            "type": {
              "array": [
                "u64",
                7
              ]
            }
          },
          {
            "name": "digest",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "sponsorshipFloor",
            "type": "u64"
          },
          {
            "name": "initialSupport",
            "type": "u64"
          },
          {
            "name": "status",
            "type": "u8"
          },
          {
            "name": "updates",
            "docs": [
              "The proposed updates and metadata exactly as stored on the proposal."
            ],
            "type": {
              "vec": {
                "defined": {
                  "name": "marketParameterUpdate"
                }
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "proposalMetadataV1"
              }
            }
          }
        ]
      }
    },
    {
      "name": "parameterProposalExecuted",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "families",
            "docs": [
              "Family codes of every update applied, ascending."
            ],
            "type": "bytes"
          },
          {
            "name": "newFamilyRevisions",
            "docs": [
              "The market's revision of every family after execution."
            ],
            "type": {
              "array": [
                "u64",
                7
              ]
            }
          },
          {
            "name": "executedAt",
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "parameterProposalQueued",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "totalLocked",
            "type": "u64"
          },
          {
            "name": "eligibleSupply",
            "type": "u64"
          },
          {
            "name": "queuedAt",
            "type": "i64"
          },
          {
            "name": "executeAfter",
            "type": "i64"
          },
          {
            "name": "executionDeadline",
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "parameterProposalStatus",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "collecting"
          },
          {
            "name": "queued"
          },
          {
            "name": "executed"
          },
          {
            "name": "cancelled"
          },
          {
            "name": "expired"
          },
          {
            "name": "stale"
          }
        ]
      }
    },
    {
      "name": "parameterProposalSupportWithdrawn",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "supporter",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "totalLocked",
            "type": "u64"
          },
          {
            "name": "status",
            "type": "u8"
          },
          {
            "name": "proposalTombstoned",
            "docs": [
              "The last supporter left, so the proposal account became a",
              "`ParameterProposalTombstone` and the rest of its rent returned to the",
              "proposer."
            ],
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "parameterProposalSupported",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "supporter",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "supporterLocked",
            "type": "u64"
          },
          {
            "name": "totalLocked",
            "type": "u64"
          },
          {
            "name": "status",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "positionDebtSidePreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "collateralAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "fixedDebt",
            "type": "u128"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "globalHealthContribution",
            "type": "u64"
          },
          {
            "name": "collateralValueNad",
            "type": "u128"
          },
          {
            "name": "healthBps",
            "type": "u64"
          },
          {
            "name": "maxCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationReferencePriceNad",
            "type": "u64"
          },
          {
            "name": "liquidationHealthBps",
            "type": "u64"
          },
          {
            "name": "isLiquidatable",
            "type": "bool"
          },
          {
            "name": "liquidationHealth",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "liquidationRates",
            "type": {
              "option": {
                "defined": {
                  "name": "liquidationRates"
                }
              }
            }
          },
          {
            "name": "liquidationDistress",
            "type": {
              "defined": {
                "name": "liquidationDistress"
              }
            }
          }
        ]
      }
    },
    {
      "name": "previewAddLiquidityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "baseDepositAmount",
            "type": "u64"
          },
          {
            "name": "quoteDepositAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "previewAmm",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "initialized",
            "type": "bool"
          },
          {
            "name": "executableBaseReserve",
            "type": "u64"
          },
          {
            "name": "executableQuoteReserve",
            "type": "u64"
          },
          {
            "name": "centerPriceNad",
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "type": "u64"
          },
          {
            "name": "lastTradePriceNad",
            "type": "u64"
          },
          {
            "name": "lastObservationSlot",
            "type": "u64"
          },
          {
            "name": "lastAdjustmentSlot",
            "type": "u64"
          },
          {
            "name": "volatilityAccumulatorNad",
            "type": "u64"
          },
          {
            "name": "decayedVolatilityNad",
            "type": "u64"
          },
          {
            "name": "curveDepthNad",
            "type": "u128"
          },
          {
            "name": "curveDepthPerShareNad",
            "type": "u128"
          },
          {
            "name": "protectedFloorPerShareNad",
            "type": "u128"
          },
          {
            "name": "protectedProfitPerShareNad",
            "type": "u128"
          },
          {
            "name": "retentionRequiredNad",
            "type": "u128"
          },
          {
            "name": "retentionStopNad",
            "type": "u128"
          },
          {
            "name": "retentionHardCapNad",
            "type": "u128"
          },
          {
            "name": "retentionActive",
            "type": "bool"
          },
          {
            "name": "retentionTargetSaturated",
            "type": "bool"
          },
          {
            "name": "retentionTargetStale",
            "type": "bool"
          },
          {
            "name": "protectedRecenterBaseReserve",
            "type": "u64"
          },
          {
            "name": "protectedRecenterQuoteReserve",
            "type": "u64"
          },
          {
            "name": "peakAmplificationNad",
            "type": "u64"
          },
          {
            "name": "coreHalfWidthBps",
            "type": "u16"
          },
          {
            "name": "fadeWidthBps",
            "type": "u16"
          },
          {
            "name": "lowerRangePriceNad",
            "type": "u64"
          },
          {
            "name": "upperRangePriceNad",
            "type": "u64"
          },
          {
            "name": "concentratedCurveBranch",
            "type": "u8"
          },
          {
            "name": "ordinaryBaseReserveNad",
            "type": "u128"
          },
          {
            "name": "ordinaryQuoteReserveNad",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "previewBorrowCapacityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "collateralAmount",
            "docs": [
              "Net deposit credit in the collateral vault. Capacity also accounts",
              "for the current fee when that collateral later exits the vault."
            ],
            "type": "u64"
          },
          {
            "name": "projectedBorrowAmount",
            "type": {
              "option": "u64"
            }
          }
        ]
      }
    },
    {
      "name": "previewBorrowPositionCapacityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "capacityKind",
            "type": {
              "defined": {
                "name": "borrowPositionCapacityKind"
              }
            }
          },
          {
            "name": "collateralChange",
            "docs": [
              "Net collateral credit (positive) or vault debit (negative), in raw mint units."
            ],
            "type": "i128"
          },
          {
            "name": "projectedBorrowAmount",
            "docs": [
              "Additional debt to draw. None quotes the maximum additional draw."
            ],
            "type": {
              "option": "u64"
            }
          }
        ]
      }
    },
    {
      "name": "previewEmergencyLiquidationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "full",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "previewFlashLiquidationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "maxRepayment",
            "type": "u64"
          },
          {
            "name": "full",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "previewHlpOrderTriggerArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "hlpAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "previewSide",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "liveReserve",
            "type": "u64"
          },
          {
            "name": "cashReserve",
            "type": "u64"
          },
          {
            "name": "baseHlpBackingInventory",
            "type": "u64"
          },
          {
            "name": "quoteHlpBackingInventory",
            "type": "u64"
          },
          {
            "name": "ylpSupply",
            "type": "u64"
          },
          {
            "name": "ylpExchangeRateNad",
            "type": "u128"
          },
          {
            "name": "spotPriceNad",
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "type": "u64"
          },
          {
            "name": "directionalPriceEmaNad",
            "type": "u64"
          },
          {
            "name": "conservativeDepthNad",
            "type": "u128"
          },
          {
            "name": "borrowIndexNad",
            "type": "u128"
          },
          {
            "name": "rateAtTargetNad",
            "type": "u128"
          },
          {
            "name": "borrowAprNad",
            "type": "u128"
          },
          {
            "name": "utilizationBps",
            "type": "u64"
          },
          {
            "name": "fixedDebt",
            "type": "u128"
          },
          {
            "name": "isolatedDebt",
            "type": "u128"
          },
          {
            "name": "hlpFundingDebt",
            "type": "u128"
          },
          {
            "name": "totalDebt",
            "type": "u128"
          },
          {
            "name": "dailyBorrowLimit",
            "type": "u64"
          },
          {
            "name": "dailyBorrowRemaining",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "previewSwapArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "exactAssetIn",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "proposalMetadataV1",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "type": "u8"
          },
          {
            "name": "title",
            "type": "string"
          },
          {
            "name": "descriptionUri",
            "type": "string"
          },
          {
            "name": "descriptionSha256",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "descriptionLen",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "proposalSupport",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "supporter",
            "type": "pubkey"
          },
          {
            "name": "lockedAmount",
            "type": "u64"
          },
          {
            "name": "baseYield",
            "type": {
              "defined": {
                "name": "virtualYieldLedger"
              }
            }
          },
          {
            "name": "quoteYield",
            "type": {
              "defined": {
                "name": "virtualYieldLedger"
              }
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionConfig",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "acceptedMint",
            "type": "pubkey"
          },
          {
            "name": "recipients",
            "type": {
              "defined": {
                "name": "protocolAuctionRecipients"
              }
            }
          },
          {
            "name": "params",
            "type": {
              "defined": {
                "name": "protocolAuctionParams"
              }
            }
          }
        ]
      }
    },
    {
      "name": "protocolAuctionConfigUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "lane",
            "type": "u8"
          },
          {
            "name": "acceptedMint",
            "type": "pubkey"
          },
          {
            "name": "startMultiplierBps",
            "type": "u16"
          },
          {
            "name": "floorMultiplierBps",
            "type": "u16"
          },
          {
            "name": "durationSlots",
            "type": "u64"
          },
          {
            "name": "maxReferenceAgeSlots",
            "type": "u64"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionEpoch",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "startSlot",
            "type": "u64"
          },
          {
            "name": "trackedInventory",
            "docs": [
              "Liability remaining immediately after the preceding fill. A larger",
              "current liability proves that new inventory arrived and starts a new",
              "epoch instead of inheriting an old floor price."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionLane",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "fee"
          },
          {
            "name": "buyback"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "startMultiplierBps",
            "type": "u16"
          },
          {
            "name": "floorMultiplierBps",
            "type": "u16"
          },
          {
            "name": "durationSlots",
            "type": "u64"
          },
          {
            "name": "maxReferenceAgeSlots",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionRecipients",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "treasury",
            "type": "pubkey"
          },
          {
            "name": "stakingVault",
            "type": "pubkey"
          },
          {
            "name": "treasuryBps",
            "type": "u16"
          },
          {
            "name": "stakingVaultBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionRecipientsUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "lane",
            "type": "u8"
          },
          {
            "name": "treasury",
            "type": "pubkey"
          },
          {
            "name": "stakingVault",
            "type": "pubkey"
          },
          {
            "name": "treasuryBps",
            "type": "u16"
          },
          {
            "name": "stakingVaultBps",
            "type": "u16"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionRouteUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "lane",
            "type": "u8"
          },
          {
            "name": "side",
            "type": "u8"
          },
          {
            "name": "soldMint",
            "type": "pubkey"
          },
          {
            "name": "acceptedMint",
            "type": "pubkey"
          },
          {
            "name": "referenceMarket",
            "docs": [
              "`Pubkey::default()` restores the direct-market-only policy."
            ],
            "type": "pubkey"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionSettled",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "referenceMarket",
            "type": "pubkey"
          },
          {
            "name": "lane",
            "type": "u8"
          },
          {
            "name": "source",
            "type": "u8"
          },
          {
            "name": "side",
            "type": "u8"
          },
          {
            "name": "bidder",
            "type": "pubkey"
          },
          {
            "name": "soldMint",
            "type": "pubkey"
          },
          {
            "name": "acceptedMint",
            "type": "pubkey"
          },
          {
            "name": "soldAmount",
            "type": "u64"
          },
          {
            "name": "paymentAmount",
            "type": "u64"
          },
          {
            "name": "treasuryAmount",
            "type": "u64"
          },
          {
            "name": "stakingVaultAmount",
            "type": "u64"
          },
          {
            "name": "referencePriceNad",
            "type": "u64"
          },
          {
            "name": "auctionPriceNad",
            "type": "u64"
          },
          {
            "name": "remainingFeeLiability",
            "type": "u64"
          },
          {
            "name": "remainingBuybackLiability",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "protocolAuctionSplit",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "feeAuctionBps",
            "type": "u16"
          },
          {
            "name": "buybackAuctionBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionSplitUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "feeAuctionBps",
            "type": "u16"
          },
          {
            "name": "buybackAuctionBps",
            "type": "u16"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "protocolRevenueSource",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "swap"
          },
          {
            "name": "interest"
          }
        ]
      }
    },
    {
      "name": "publicInterestAdvance",
      "docs": [
        "Reserve-cash funding of public borrower interest. The protocol portion is",
        "held in the reserve vault until repayment, so cancellation can return it",
        "to executable cash without a transfer or a second transfer fee."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "outstandingGross",
            "type": "u64"
          },
          {
            "name": "protocolEscrow",
            "type": "u64"
          },
          {
            "name": "repaymentCreditPending",
            "docs": [
              "Native repayment has already restored this cash; its token handler",
              "must exclude it from the new interest-vault transfer."
            ],
            "type": "u64"
          },
          {
            "name": "protocolReleasePending",
            "docs": [
              "Frozen protocol allocation released by repayment, still held in the",
              "reserve vault until the same instruction completes token settlement."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "publicInterestFunded",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "caller",
            "type": "pubkey"
          },
          {
            "name": "receipt",
            "type": {
              "defined": {
                "name": "fundInterestReceipt"
              }
            }
          }
        ]
      }
    },
    {
      "name": "referralAccrual",
      "docs": [
        "Claimable referral revenue for one partner, market, and debt asset."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "referralBound",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "referrer",
            "type": "pubkey"
          },
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "referralInterestAccrued",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "referrer",
            "type": "pubkey"
          },
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "referralAccrual",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "interestVaultCredit",
            "type": "u64"
          },
          {
            "name": "protocolInterestRevenue",
            "type": "u64"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "accruedAmount",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "referralInterestClaimed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "referralAccrual",
            "type": "pubkey"
          },
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "vaultDebit",
            "type": "u64"
          },
          {
            "name": "recipientCredit",
            "type": "u64"
          },
          {
            "name": "remainingAccrual",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "referralInterestShareCapUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "maxReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "referralPartner",
      "docs": [
        "A permissioned, protocol-wide referral registry entry."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "active",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "referralPartnerConfigured",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "active",
            "type": "bool"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "referralRecipientUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "removeLiquidityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "ylpAmount",
            "type": "u64"
          },
          {
            "name": "minBaseAmountOut",
            "type": "u64"
          },
          {
            "name": "minQuoteAmountOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "repayArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "repayAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "reserveShares",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "ylpSupply",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "reserves",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "flashReceivable",
            "docs": [
              "Same-transaction collateral receivable. Included in backing, excluded",
              "from cash available to swaps, loans and withdrawals."
            ],
            "type": "u64"
          },
          {
            "name": "liveReserve",
            "type": "u64"
          },
          {
            "name": "cashReserve",
            "type": "u64"
          },
          {
            "name": "baseHlpBackingInventory",
            "docs": [
              "Physical reserve-vault atoms removed from executable AMM inventory by",
              "base-hLP deleveraging. They are conservation-only bookkeeping, excluded",
              "from hLP NAV and exit output, and return to executable cash pro rata as",
              "base hLP exits."
            ],
            "type": "u64"
          },
          {
            "name": "quoteHlpBackingInventory",
            "docs": [
              "Quote-hLP counterpart of `base_hlp_backing_inventory`; never a second",
              "hLP NAV or withdrawal claim."
            ],
            "type": "u64"
          },
          {
            "name": "protectedRecenterReserve",
            "docs": [
              "Physical reserve-vault atoms retained from toxicity surcharge for a",
              "future protected recenter. They are custody-backed but excluded from",
              "executable cash/live reserves, yLP NAV, and every withdrawal claim."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "revenueDistribution",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "futarchyTreasuryBps",
            "type": "u16"
          },
          {
            "name": "buybacksVaultBps",
            "type": "u16"
          },
          {
            "name": "teamTreasuryBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "revenueRecipients",
      "docs": [
        "Revenue recipient wallet addresses. Recipient token accounts are derived or",
        "validated against these owners when protocol fees are claimed."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "futarchyTreasury",
            "type": "pubkey"
          },
          {
            "name": "buybacksVault",
            "type": "pubkey"
          },
          {
            "name": "teamTreasury",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "revenueShare",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "swapBps",
            "type": "u16"
          },
          {
            "name": "interestBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "risk",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "basePriceEmaNad",
            "type": "u64"
          },
          {
            "name": "quotePriceEmaNad",
            "type": "u64"
          },
          {
            "name": "directionalBasePriceEmaNad",
            "type": "u64"
          },
          {
            "name": "directionalQuotePriceEmaNad",
            "type": "u64"
          },
          {
            "name": "cachedSpotBasePriceNad",
            "type": "u64"
          },
          {
            "name": "cachedSpotQuotePriceNad",
            "type": "u64"
          },
          {
            "name": "observedCurveDepthNad",
            "docs": [
              "Last observed total active curve depth in market amount units (see Market)."
            ],
            "type": "u128"
          },
          {
            "name": "curveDepthEmaNad",
            "docs": [
              "EMA of total active curve depth in market amount units (see Market)."
            ],
            "type": "u128"
          },
          {
            "name": "lastSnapshotSlot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "rotateHlpCohortArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "initializeLpMetadataArgs"
              }
            }
          }
        ]
      }
    },
    {
      "name": "setGlobalReduceOnlyArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "reduceOnly",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "setHarvestAuthorityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "tokenKind",
            "type": {
              "defined": {
                "name": "yieldTokenKind"
              }
            }
          },
          {
            "name": "harvestAuthority",
            "docs": [
              "`None` revokes the independent caller; the recipient is unchanged."
            ],
            "type": {
              "option": "pubkey"
            }
          }
        ]
      }
    },
    {
      "name": "setMarketReduceOnlyArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "reduceOnly",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "setReferralRecipientArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "recipient",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "setYieldRecipientArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "tokenKind",
            "type": {
              "defined": {
                "name": "yieldTokenKind"
              }
            }
          },
          {
            "name": "recipient",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "settleProtocolAuctionArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lane",
            "type": {
              "defined": {
                "name": "protocolAuctionLane"
              }
            }
          },
          {
            "name": "source",
            "type": {
              "defined": {
                "name": "protocolRevenueSource"
              }
            }
          },
          {
            "name": "soldAmount",
            "type": "u64"
          },
          {
            "name": "maxPaymentAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "supportGovernanceProposalArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "digest",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "contributions",
            "docs": [
              "Same canonical remaining-account pairs as creation."
            ],
            "type": {
              "vec": "u64"
            }
          }
        ]
      }
    },
    {
      "name": "supportParameterProposalArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "digest",
            "docs": [
              "Digest of the proposal the supporter reviewed. A proposal never",
              "changes and its address never holds another one (it ends as a",
              "tombstone), so this is defence in depth: a support names exactly the",
              "updates and metadata its sender saw."
            ],
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          }
        ]
      }
    },
    {
      "name": "swapArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "exactAssetIn",
            "type": "u64"
          },
          {
            "name": "minAssetOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "swapExecuted",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "trader",
            "docs": [
              "Beneficial owner of the trade, including delegated leverage actions."
            ],
            "type": "pubkey"
          },
          {
            "name": "actor",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "origin",
            "type": {
              "defined": {
                "name": "swapOrigin"
              }
            }
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "assetInSide",
            "docs": [
              "`0` for base input and `1` for quote input."
            ],
            "type": "u8"
          },
          {
            "name": "amountIn",
            "docs": [
              "AMM input before trading fees, after any input transfer fee. Includes",
              "internally borrowed principal; this is not the owner's wallet debit."
            ],
            "type": "u64"
          },
          {
            "name": "amountOut",
            "docs": [
              "AMM output after trading fees, before any output transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "grossAmountOut",
            "docs": [
              "Curve output before an output-denominated fee and transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "feeAssetSide",
            "docs": [
              "`0` for Base and `1` for Quote."
            ],
            "type": "u8"
          },
          {
            "name": "amountInAfterFee",
            "docs": [
              "Input applied to the invariant after all swap fees."
            ],
            "type": "u64"
          },
          {
            "name": "baseFee",
            "type": "u64"
          },
          {
            "name": "divergenceFee",
            "type": "u64"
          },
          {
            "name": "volatilityFee",
            "type": "u64"
          },
          {
            "name": "retainedFee",
            "docs": [
              "Dynamic surcharge retained outside executable/yLP inventory until an",
              "admitted center move deploys it."
            ],
            "type": "u64"
          },
          {
            "name": "compoundedFee",
            "docs": [
              "LP-owned fee compounded into reserve principal."
            ],
            "type": "u64"
          },
          {
            "name": "hlpRecoveryTargetAsset",
            "docs": [
              "Extra output funded by deleveraging the stressed hLP."
            ],
            "type": "u8"
          },
          {
            "name": "hlpRecoveryFundingGap",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryMatchedInput",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryBonusOutput",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryDiscountBps",
            "type": "u16"
          },
          {
            "name": "hlpRecoveryCritical",
            "type": "bool"
          },
          {
            "name": "baseLiveReserve",
            "docs": [
              "Final executable reserves after retention and inline hLP correction."
            ],
            "type": "u64"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u64"
          },
          {
            "name": "ylpSupply",
            "docs": [
              "Internal yLP share supply after the swap."
            ],
            "type": "u64"
          },
          {
            "name": "startPriceNad",
            "docs": [
              "Base price used to quote this execution, after any deferred controller step."
            ],
            "type": "u64"
          },
          {
            "name": "base",
            "docs": [
              "Each side's price, price EMA, and yLP growth indexes after the swap."
            ],
            "type": {
              "defined": {
                "name": "marketSideSnapshot"
              }
            }
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "marketSideSnapshot"
              }
            }
          }
        ]
      }
    },
    {
      "name": "swapOrigin",
      "docs": [
        "Instruction that caused an actual AMM execution. Fee attribution follows",
        "this origin; borrowing interest is reported separately by debt source."
      ],
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "spot"
          },
          {
            "name": "leverageOpen"
          },
          {
            "name": "leverageIncrease"
          },
          {
            "name": "leverageDecrease"
          },
          {
            "name": "leverageClose"
          },
          {
            "name": "leverageLiquidation"
          },
          {
            "name": "creditLiquidation"
          }
        ]
      }
    },
    {
      "name": "swapPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "assetIn",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "assetOut",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "exactAssetIn",
            "type": "u64"
          },
          {
            "name": "transferFee",
            "type": "u64"
          },
          {
            "name": "reserveCredit",
            "docs": [
              "Actual credit received by the reserve vault from the user transfer."
            ],
            "type": "u64"
          },
          {
            "name": "feeAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "amountOut",
            "docs": [
              "Output reserve vault debit after Dusk trading fees, before the output mint transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "grossAmountOut",
            "docs": [
              "Curve output before Dusk trading fees."
            ],
            "type": "u64"
          },
          {
            "name": "reserveInLiveReserve",
            "type": "u64"
          },
          {
            "name": "reserveOutLiveReserve",
            "type": "u64"
          },
          {
            "name": "baseFeeDebit",
            "type": "u64"
          },
          {
            "name": "divergenceSurchargeDebit",
            "type": "u64"
          },
          {
            "name": "volatilitySurchargeDebit",
            "type": "u64"
          },
          {
            "name": "dynamicSurchargeDebit",
            "type": "u64"
          },
          {
            "name": "totalFeeDebit",
            "type": "u64"
          },
          {
            "name": "retainedSurcharge",
            "type": "u64"
          },
          {
            "name": "distributedSurchargeDebit",
            "type": "u64"
          },
          {
            "name": "claimableFeeDebit",
            "type": "u64"
          },
          {
            "name": "compoundedFeeDebit",
            "docs": [
              "LP-owned fee converted into reserve principal at the configured rate."
            ],
            "type": "u64"
          },
          {
            "name": "compoundingFeeBps",
            "type": "u16"
          },
          {
            "name": "amountInForQuote",
            "type": "u64"
          },
          {
            "name": "reserveInputCredit",
            "type": "u64"
          },
          {
            "name": "baseFeeCredit",
            "type": "u64"
          },
          {
            "name": "distributedSurchargeCredit",
            "type": "u64"
          },
          {
            "name": "claimableFeeCredit",
            "type": "u64"
          },
          {
            "name": "baseFeeRateNad",
            "type": "u64"
          },
          {
            "name": "divergenceFeeRateNad",
            "type": "u64"
          },
          {
            "name": "volatilityFeeRateNad",
            "type": "u64"
          },
          {
            "name": "totalFeeRateNad",
            "type": "u64"
          },
          {
            "name": "startPriceNad",
            "type": "u64"
          },
          {
            "name": "tradeEndPriceNad",
            "docs": [
              "Invariant-preserving executable trade endpoint."
            ],
            "type": "u64"
          },
          {
            "name": "reserveEndPriceNad",
            "docs": [
              "Final executable marginal price. A protected retained surcharge is",
              "non-quoteable, so it does not change this value."
            ],
            "type": "u64"
          },
          {
            "name": "centerPriceNad",
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "type": "u64"
          },
          {
            "name": "decayedVolatilityNad",
            "type": "u64"
          },
          {
            "name": "postSuccessVolatilityNad",
            "type": "u64"
          },
          {
            "name": "retentionActive",
            "type": "bool"
          },
          {
            "name": "retentionTargetSaturated",
            "type": "bool"
          },
          {
            "name": "protectedRecenterBaseReserve",
            "type": "u64"
          },
          {
            "name": "protectedRecenterQuoteReserve",
            "type": "u64"
          },
          {
            "name": "protectedProfitPerShareNad",
            "type": "u128"
          },
          {
            "name": "projectedProtectedProfitPerShareNad",
            "type": "u128"
          },
          {
            "name": "retentionRequiredNad",
            "type": "u128"
          },
          {
            "name": "retentionStopNad",
            "type": "u128"
          },
          {
            "name": "retentionHardCapNad",
            "type": "u128"
          },
          {
            "name": "lowerRangePriceNad",
            "docs": [
              "Concentrated range metadata. Zeroes denote the legacy curve during the",
              "temporary caller migration."
            ],
            "type": "u64"
          },
          {
            "name": "upperRangePriceNad",
            "type": "u64"
          },
          {
            "name": "concentratedCurveBranch",
            "docs": [
              "0=lower tail, 1=lower shoulder, 2=inner band,",
              "3=upper shoulder, 4=upper tail."
            ],
            "type": "u8"
          },
          {
            "name": "ordinaryBaseReserveNad",
            "type": "u128"
          },
          {
            "name": "ordinaryQuoteReserveNad",
            "type": "u128"
          },
          {
            "name": "finalSpotPriceNad",
            "type": "u64"
          },
          {
            "name": "baseHlpQuoteDebtDelta",
            "type": "i128"
          },
          {
            "name": "quoteHlpBaseDebtDelta",
            "type": "i128"
          },
          {
            "name": "hlpRecoveryTargetAsset",
            "docs": [
              "Funding recovery funded exclusively by the stressed hLP."
            ],
            "type": "u8"
          },
          {
            "name": "hlpRecoveryFundingGap",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryMatchedInput",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryBonusOutput",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryDiscountBps",
            "type": "u16"
          },
          {
            "name": "hlpRecoveryCritical",
            "type": "bool"
          },
          {
            "name": "outputTransferFee",
            "docs": [
              "Token-2022 fee withheld when the output vault transfers `amount_out`."
            ],
            "type": "u64"
          },
          {
            "name": "netAmountOut",
            "docs": [
              "Spendable output credited to the recipient; the value checked by `min_asset_out`."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "updateFutarchyAuthorityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "newAuthority",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "updateLeverageDelegationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "delegatedProgram",
            "type": "pubkey"
          },
          {
            "name": "approvedActions",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "updateProtocolAuctionConfigArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lane",
            "type": {
              "defined": {
                "name": "protocolAuctionLane"
              }
            }
          },
          {
            "name": "acceptedMint",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "params",
            "type": {
              "option": {
                "defined": {
                  "name": "protocolAuctionParams"
                }
              }
            }
          }
        ]
      }
    },
    {
      "name": "updateProtocolAuctionRecipientsArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lane",
            "type": {
              "defined": {
                "name": "protocolAuctionLane"
              }
            }
          },
          {
            "name": "treasury",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "stakingVault",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "treasuryBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "stakingVaultBps",
            "type": {
              "option": "u16"
            }
          }
        ]
      }
    },
    {
      "name": "updateProtocolAuctionRouteArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lane",
            "type": {
              "defined": {
                "name": "protocolAuctionLane"
              }
            }
          },
          {
            "name": "soldMint",
            "type": "pubkey"
          },
          {
            "name": "referenceMarket",
            "docs": [
              "A governance-approved market key. The default key removes the approval",
              "and permits settlement only from the sold market's own direct pair."
            ],
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "updateProtocolRevenueArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "swapBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "interestBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "maxReferralInterestShareBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "revenueDistribution",
            "type": {
              "option": {
                "defined": {
                  "name": "revenueDistribution"
                }
              }
            }
          },
          {
            "name": "protocolAuctionSplit",
            "type": {
              "option": {
                "defined": {
                  "name": "protocolAuctionSplit"
                }
              }
            }
          }
        ]
      }
    },
    {
      "name": "updateRevenueRecipientsArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "futarchyTreasury",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "buybacksVault",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "teamTreasury",
            "type": {
              "option": "pubkey"
            }
          }
        ]
      }
    },
    {
      "name": "virtualYieldLedger",
      "docs": [
        "A yield ledger for yLP burned into one support position. Its checkpoints",
        "isolate each proposal lock while the user's ordinary YieldAccounts continue",
        "to follow only the live balance in their Token-2022 ATA."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "swapFeeCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "interestCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "accruedSwapFeeAmount",
            "type": "u64"
          },
          {
            "name": "accruedInterestAmount",
            "type": "u64"
          },
          {
            "name": "swapFeeRemainderQ64",
            "type": "u64"
          },
          {
            "name": "interestRemainderQ64",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "withdrawAllCollateralArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "minBaseOut",
            "type": "u64"
          },
          {
            "name": "minQuoteOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "withdrawCollateralArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "withdrawAmount",
            "type": "u64"
          },
          {
            "name": "minAssetAmountOut",
            "type": "u64"
          },
          {
            "name": "minLiquidationCfBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "withdrawParameterSupportArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "amount",
            "docs": [
              "None releases all support; Some releases only this amount."
            ],
            "type": {
              "option": "u64"
            }
          }
        ]
      }
    },
    {
      "name": "withdrawRepaidLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "minCollateralOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "withdrawSingleSidedArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "hlpAmount",
            "type": "u64"
          },
          {
            "name": "minTargetAmountOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "yieldAccount",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "docs": [
              "LP mint whose balance earns this account's revenue stream. This keeps",
              "base-hLP, quote-hLP, and yLP entitlements in disjoint PDA namespaces."
            ],
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": "u8"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "swapFeeCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "interestCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "accruedSwapFeeAmount",
            "type": "u64"
          },
          {
            "name": "accruedInterestAmount",
            "type": "u64"
          },
          {
            "name": "swapFeeRemainderQ64",
            "docs": [
              "Sub-token fixed-point entitlement carried across checkpoints. Keeping",
              "this remainder prevents transfer/checkpoint frequency from destroying",
              "holder yield through repeated flooring."
            ],
            "type": "u64"
          },
          {
            "name": "interestRemainderQ64",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "harvestAuthority",
            "docs": [
              "Optional caller allowed to harvest to the recipient without controlling",
              "the LP or changing either yield permission. Only the owner may set it."
            ],
            "type": {
              "option": "pubkey"
            }
          }
        ]
      }
    },
    {
      "name": "yieldClaimed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": "u8"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "swapFeeAmount",
            "type": "u64"
          },
          {
            "name": "interestAmount",
            "type": "u64"
          },
          {
            "name": "recipientCredit",
            "docs": [
              "Total amount credited to the recipient after transfer fees."
            ],
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "yieldRecipientUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": "u8"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "yieldTokenKind",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "ylp"
          },
          {
            "name": "hlp"
          }
        ]
      }
    }
  ],
  "constants": [
    {
      "name": "borrowPositionSeedPrefix",
      "type": "bytes",
      "value": "[98, 111, 114, 114, 111, 119, 95, 112, 111, 115, 105, 116, 105, 111, 110, 95, 118, 50]"
    },
    {
      "name": "bpsDenominator",
      "type": "u16",
      "value": "10000"
    },
    {
      "name": "defaultProtocolRevenueShareBps",
      "docs": [
        "Initial DAO share of base swap fees and paid interest, and the protocol",
        "share of liquidation fees. Governance can override swap and interest shares."
      ],
      "type": "u16",
      "value": "2000"
    },
    {
      "name": "futarchyAuthoritySeedPrefix",
      "type": "bytes",
      "value": "[102, 117, 116, 97, 114, 99, 104, 121, 95, 97, 117, 116, 104, 111, 114, 105, 116, 121]"
    },
    {
      "name": "hlpTerminalCallerBps",
      "docs": [
        "Caller reward for closing a terminal hLP vault, paid from recovered funding",
        "interest so it cannot increase the bad-debt waterfall."
      ],
      "type": "u16",
      "value": "50"
    },
    {
      "name": "hlpYlpVaultSeedPrefix",
      "type": "bytes",
      "value": "[104, 108, 112, 95, 121, 108, 112, 95, 118, 97, 117, 108, 116]"
    },
    {
      "name": "insuranceSeedPrefix",
      "type": "bytes",
      "value": "[105, 110, 115, 117, 114, 97, 110, 99, 101]"
    },
    {
      "name": "leverageCollateralVaultSeedPrefix",
      "type": "bytes",
      "value": "[108, 101, 118, 101, 114, 97, 103, 101, 95, 99, 111, 108, 108, 97, 116, 101, 114, 97, 108]"
    },
    {
      "name": "leverageDelegationSeedPrefix",
      "type": "bytes",
      "value": "[108, 101, 118, 101, 114, 97, 103, 101, 95, 100, 101, 108, 101, 103, 97, 116, 105, 111, 110, 95, 118, 50]"
    },
    {
      "name": "leverageMaxMultiplierBps",
      "type": "u64",
      "value": "200000"
    },
    {
      "name": "leveragePositionSeedPrefix",
      "type": "bytes",
      "value": "[108, 101, 118, 101, 114, 97, 103, 101, 95, 112, 111, 115, 105, 116, 105, 111, 110, 95, 118, 50]"
    },
    {
      "name": "liquidationAuctionDurationSeconds",
      "docs": [
        "External bids have this fixed window before the permissionless internal",
        "unwind becomes executable."
      ],
      "type": "i64",
      "value": "300"
    },
    {
      "name": "liquidationBackstopCallerBps",
      "docs": [
        "V1-style keeper reward paid from collateral consumed by the permissionless",
        "lending-auction floor. This is deliberately independent from the dynamic",
        "incentive used by externally funded auction bids."
      ],
      "type": "u16",
      "value": "50"
    },
    {
      "name": "liquidationCloseFactorBps",
      "type": "u16",
      "value": "5000"
    },
    {
      "name": "liquidationIncentiveBps",
      "type": "u16",
      "value": "100"
    },
    {
      "name": "liquidationInsuranceFundingBps",
      "type": "u16",
      "value": "200"
    },
    {
      "name": "liquidationMaxIncentiveBps",
      "type": "u16",
      "value": "500"
    },
    {
      "name": "liquidationPenaltyBps",
      "type": "u16",
      "value": "300"
    },
    {
      "name": "ltvBufferBps",
      "type": "u16",
      "value": "500"
    },
    {
      "name": "marketCollateralVaultSeedPrefix",
      "type": "bytes",
      "value": "[109, 97, 114, 107, 101, 116, 95, 99, 111, 108, 108, 97, 116, 101, 114, 97, 108]"
    },
    {
      "name": "marketCreationFeeLamports",
      "type": "u64",
      "value": "200000000"
    },
    {
      "name": "marketInterestVaultSeedPrefix",
      "type": "bytes",
      "value": "[109, 97, 114, 107, 101, 116, 95, 105, 110, 116, 101, 114, 101, 115, 116]"
    },
    {
      "name": "marketLayoutVersion",
      "docs": [
        "Serialized `Market` account layout discriminator.",
        "",
        "Layout 6 keeps an explicit insurance-window initialization flag while",
        "economic checkpoints use slots. Earlier development layouts must not",
        "decode as this structure."
      ],
      "type": "u8",
      "value": "6"
    },
    {
      "name": "marketReserveVaultSeedPrefix",
      "type": "bytes",
      "value": "[109, 97, 114, 107, 101, 116, 95, 114, 101, 115, 101, 114, 118, 101]"
    },
    {
      "name": "marketV2SeedPrefix",
      "type": "bytes",
      "value": "[109, 97, 114, 107, 101, 116, 95, 118, 50]"
    },
    {
      "name": "maxCollateralFactorBps",
      "type": "u16",
      "value": "8500"
    },
    {
      "name": "maxInsuranceDrawPerDayBps",
      "type": "u16",
      "value": "5000"
    },
    {
      "name": "maxInsurancePrincipalCoverageBps",
      "docs": [
        "Absolute protocol ceilings for insurance-vault loss concentration. Market",
        "governance may lower either limit, including to zero, but may never raise",
        "them above these values."
      ],
      "type": "u16",
      "value": "7500"
    },
    {
      "name": "maxParameterFeeBps",
      "docs": [
        "Absolute cap shared by the three configurable swap-fee components.",
        "Their configured component caps must also sum to no more than this value."
      ],
      "type": "u16",
      "value": "5000"
    },
    {
      "name": "maxReferralInterestShareBps",
      "type": "u16",
      "value": "10000"
    },
    {
      "name": "metadataSeedPrefix",
      "type": "bytes",
      "value": "[109, 101, 116, 97, 100, 97, 116, 97]"
    },
    {
      "name": "nad",
      "docs": [
        "NAD: Nine-decimal fixed point unit (1e9 scaling), similar to WAD (1e18) by Maker."
      ],
      "type": "u64",
      "value": "1000000000"
    },
    {
      "name": "nadDecimals",
      "type": "u8",
      "value": "9"
    },
    {
      "name": "parameterExecutionMaxUtilizationBps",
      "type": "u64",
      "value": "8000"
    },
    {
      "name": "parameterProposalExecutionWindowSeconds",
      "type": "i64",
      "value": "604800"
    },
    {
      "name": "parameterProposalSeedPrefix",
      "type": "bytes",
      "value": "[112, 97, 114, 97, 109, 101, 116, 101, 114, 95, 112, 114, 111, 112, 111, 115, 97, 108]"
    },
    {
      "name": "parameterProposalSponsorBps",
      "docs": [
        "Direct-yLP parameter governance thresholds and wall-clock lifecycle."
      ],
      "type": "u16",
      "value": "100"
    },
    {
      "name": "parameterProposalSupportBps",
      "type": "u16",
      "value": "5000"
    },
    {
      "name": "parameterProposalTimelockSeconds",
      "type": "i64",
      "value": "604800"
    },
    {
      "name": "proposalSupportSeedPrefix",
      "type": "bytes",
      "value": "[112, 114, 111, 112, 111, 115, 97, 108, 95, 115, 117, 112, 112, 111, 114, 116]"
    },
    {
      "name": "referralAccrualSeedPrefix",
      "type": "bytes",
      "value": "[114, 101, 102, 101, 114, 114, 97, 108, 95, 97, 99, 99, 114, 117, 97, 108]"
    },
    {
      "name": "referralPartnerSeedPrefix",
      "type": "bytes",
      "value": "[114, 101, 102, 101, 114, 114, 97, 108, 95, 112, 97, 114, 116, 110, 101, 114]"
    },
    {
      "name": "targetMsPerSlot",
      "docs": [
        "Economic timers use a deterministic nominal slot cadence instead of the",
        "leader-influenced `Clock.unix_timestamp`. Solana's 200 ms slot rollout is",
        "separate from Alpenglow's finality change. Revisit this protocol constant",
        "if the cluster's scheduled slot duration changes again."
      ],
      "type": "u64",
      "value": "200"
    },
    {
      "name": "yieldAccountSeedPrefix",
      "type": "bytes",
      "value": "[121, 105, 101, 108, 100]"
    }
  ]
};
