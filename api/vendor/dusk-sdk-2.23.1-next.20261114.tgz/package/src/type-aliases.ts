import type { IdlTypes } from "@coral-xyz/anchor";
import type { Dusk } from "./types_v2.js";

// Restrict Anchor's recursive type decoding to the definitions reachable from
// account and event roots. The full IDL includes instruction-only types and
// exceeds TypeScript's instantiation depth after the protocol layout grows.
type TypeNamed<N extends Dusk["types"][number]["name"]> = Extract<
  Dusk["types"][number],
  { name: N }
>;
type DuskAccountTypes = [
  TypeNamed<"operatorRevenueAccount">,
  TypeNamed<"interestRevenueBook">,
  TypeNamed<"operatorProposal">,
  TypeNamed<"operatorState">,
  TypeNamed<"concentrationRamp">,
  TypeNamed<"concentratedCurveParameters">,
  TypeNamed<"riskRateUpdate">,
  TypeNamed<"oraclePolicy">,
  TypeNamed<"oracleObservation">,
  TypeNamed<"oracleState">,
  TypeNamed<"runtimePricing">,
  TypeNamed<"hlpFlashQuote">,
  TypeNamed<"hlpFlashSession">,
  TypeNamed<"liquidationSession">,
  TypeNamed<"liquidationHealth">,
  TypeNamed<"liquidationRates">,
  TypeNamed<"liquidationFeeAllocation">,
  TypeNamed<"flashLiquidationQuote">,
  TypeNamed<"ammConfig">,
  TypeNamed<"ammState">,
  TypeNamed<"borrowPosition">,
  TypeNamed<"closeApprovalQuote">,
  TypeNamed<"concentratedCurveCache">,
  TypeNamed<"dailyBorrowBucket">,
  TypeNamed<"debt">,
  TypeNamed<"deferredControllerTarget">,
  TypeNamed<"feeProfile">,
  TypeNamed<"fees">,
  TypeNamed<"publicInterestAdvance">,
  TypeNamed<"futarchyAuthority">,
  TypeNamed<"hlpCohort">,
  TypeNamed<"hlpVault">,
  TypeNamed<"riskRateConfig">,
  TypeNamed<"trancheCapital">,
  TypeNamed<"trancheIncome">,
  TypeNamed<"tranchePolicy">,
  TypeNamed<"trancheRevenueCarry">,
  TypeNamed<"juniorExitConfig">,
  TypeNamed<"marketIncomeBooks">,
  TypeNamed<"incomeReceivableBook">,
  TypeNamed<"incomeReceivableClaim">,
  TypeNamed<"incomeExposureEnd">,
  TypeNamed<"incomeEpoch">,
  TypeNamed<"juniorCohort">,
  TypeNamed<"juniorExitAccount">,
  TypeNamed<"juniorExitTicket">,
  TypeNamed<"receivableGrowth">,
  TypeNamed<"leverageDelegation">,
  TypeNamed<"leverageMarginTerms">,
  TypeNamed<"leveragePosition">,
  TypeNamed<"market">,
  TypeNamed<"marketConfig">,
  TypeNamed<"marketParameterUpdate">,
  TypeNamed<"marketSide">,
  TypeNamed<"proposalMetadataV1">,
  TypeNamed<"protocolAuctionConfig">,
  TypeNamed<"protocolAuctionState">,
  TypeNamed<"protocolAuctionRecipients">,
  TypeNamed<"protocolAuctionSplit">,
  TypeNamed<"referralAccrual">,
  TypeNamed<"referralPartner">,
  TypeNamed<"reserveShares">,
  TypeNamed<"reserves">,
  TypeNamed<"revenueDistribution">,
  TypeNamed<"revenueRecipients">,
  TypeNamed<"revenueShare">,
  TypeNamed<"risk">,
  TypeNamed<"yieldAccount">,
];
type DuskEventTypes = [
  TypeNamed<"operatorRevenueClaimed">,
  TypeNamed<"protocolInterestMarkupCheckpointed">,
  TypeNamed<"operatorChanged">,
  TypeNamed<"managerChanged">,
  TypeNamed<"operatorChangeAnnounced">,
  TypeNamed<"operatorChangeResolved">,
  TypeNamed<"juniorCohortInitialized">,
  TypeNamed<"juniorSeedCompounded">,
  TypeNamed<"juniorSeedFunded">,
  TypeNamed<"retiredJuniorBurned">,
  TypeNamed<"trancheConverted">,
  TypeNamed<"oraclePolicy">,
  TypeNamed<"liquidationHealth">,
  TypeNamed<"liquidationRates">,
  TypeNamed<"liquidationFeeAllocation">,
  TypeNamed<"liquidationLossAllocation">,
  TypeNamed<"flashLiquidationQuote">,
  TypeNamed<"liquidationPositionState">,
  TypeNamed<"emergencyLiquidationQuote">,
  TypeNamed<"flashLiquidationBegun">,
  TypeNamed<"flashLiquidationSettled">,
  TypeNamed<"emergencyLiquidationSettled">,
  TypeNamed<"ammConfig">,
  TypeNamed<"fundInterestReceipt">,
  TypeNamed<"publicInterestFunded">,
  TypeNamed<"hlpInterestAllocated">,
  TypeNamed<"hlpFlashQuote">,
  TypeNamed<"hlpFlashStarted">,
  TypeNamed<"hlpFlashSettled">,
  TypeNamed<"borrowInterestAccrued">,
  TypeNamed<"borrowInterestPaid">,
  TypeNamed<"borrowPositionLiquidated">,
  TypeNamed<"debtFreePositionClosed">,
  TypeNamed<"debtSource">,
  TypeNamed<"feeProfile">,
  TypeNamed<"harvestAuthorityUpdated">,
  TypeNamed<"hlpClosed">,
  TypeNamed<"hlpCohortRotated">,
  TypeNamed<"hlpOpened">,
  TypeNamed<"hlpRebalanced">,
  TypeNamed<"hlpRetiredReceiptBurned">,
  TypeNamed<"hlpTerminalLiquidated">,
  TypeNamed<"riskRateConfig">,
  TypeNamed<"riskRateUpdate">,
  TypeNamed<"leverageDelegationUpdated">,
  TypeNamed<"leverageMarginTerms">,
  TypeNamed<"leveragePositionClosed">,
  TypeNamed<"leveragePositionLiquidated">,
  TypeNamed<"leveragePositionOpened">,
  TypeNamed<"leveragePositionUpdated">,
  TypeNamed<"leverageSwapReceipt">,
  TypeNamed<"liquidationAuctionCancelled">,
  TypeNamed<"liquidationAuctionStarted">,
  TypeNamed<"liquidityAdded">,
  TypeNamed<"liquidityRemoved">,
  TypeNamed<"lpTransferred">,
  TypeNamed<"marketCollateralDeposited">,
  TypeNamed<"marketCollateralWithdrawn">,
  TypeNamed<"marketConfig">,
  TypeNamed<"marketCreated">,
  TypeNamed<"marketDebtUpdated">,
  TypeNamed<"marketEventMetadata">,
  TypeNamed<"marketHealthUpdated">,
  TypeNamed<"marketParameterUpdate">,
  TypeNamed<"marketReduceOnlyUpdated">,
  TypeNamed<"marketSideSnapshot">,
  TypeNamed<"proposalMetadataV1">,
  TypeNamed<"protocolAuctionConfigUpdated">,
  TypeNamed<"protocolAuctionRecipientsUpdated">,
  TypeNamed<"protocolAuctionConfigured">,
  TypeNamed<"protocolAuctionSettled">,
  TypeNamed<"protocolAuctionSplitUpdated">,
  TypeNamed<"referralBound">,
  TypeNamed<"referralInterestAccrued">,
  TypeNamed<"referralInterestClaimed">,
  TypeNamed<"referralInterestShareCapUpdated">,
  TypeNamed<"referralPartnerConfigured">,
  TypeNamed<"referralRecipientUpdated">,
  TypeNamed<"swapExecuted">,
  TypeNamed<"swapOrigin">,
  TypeNamed<"yieldClaimed">,
  TypeNamed<"yieldRecipientUpdated">,
];
type DuskAccountIdl = {
  address: Dusk["address"];
  metadata: Dusk["metadata"];
  instructions: [];
  accounts: Dusk["accounts"];
  events: [];
  types: DuskAccountTypes;
};
type DuskEventIdl = {
  address: Dusk["address"];
  metadata: Dusk["metadata"];
  instructions: [];
  accounts: [];
  events: Dusk["events"];
  types: DuskEventTypes;
};
type DuskFlashAmmIdl = {
  address: Dusk["address"];
  metadata: Dusk["metadata"];
  instructions: [];
  accounts: [];
  events: [];
  types: [
  TypeNamed<"flashAmmLiquidationQuote">,
    TypeNamed<"flashLiquidationQuote">,
    TypeNamed<"liquidationFeeAllocation">,
    TypeNamed<"liquidationHealth">,
    TypeNamed<"liquidationRates">,
  ];
};

export type Market = IdlTypes<DuskAccountIdl>["market"];
export type HlpFlashQuote = IdlTypes<DuskAccountIdl>["hlpFlashQuote"];
export type FundInterestReceipt = IdlTypes<DuskEventIdl>["fundInterestReceipt"];
export type FlashLiquidationQuote = IdlTypes<DuskEventIdl>["flashLiquidationQuote"];
export type FlashAmmLiquidationQuote = IdlTypes<DuskFlashAmmIdl>["flashAmmLiquidationQuote"];
export type EmergencyLiquidationQuote = IdlTypes<DuskEventIdl>["emergencyLiquidationQuote"];
export type BorrowPosition = IdlTypes<DuskAccountIdl>["borrowPosition"];
export type LeveragePosition = IdlTypes<DuskAccountIdl>["leveragePosition"];
export type LeverageDelegation = IdlTypes<DuskAccountIdl>["leverageDelegation"];
export type YieldAccount = IdlTypes<DuskAccountIdl>["yieldAccount"];
export type JuniorCohort = IdlTypes<DuskAccountIdl>["juniorCohort"];
export type JuniorExitAccount = IdlTypes<DuskAccountIdl>["juniorExitAccount"];
export type IncomeEpoch = IdlTypes<DuskAccountIdl>["incomeEpoch"];
export type FutarchyAuthority = IdlTypes<DuskAccountIdl>["futarchyAuthority"];
export type ReferralPartner = IdlTypes<DuskAccountIdl>["referralPartner"];
export type ReferralAccrual = IdlTypes<DuskAccountIdl>["referralAccrual"];



export type HlpClosed = IdlTypes<DuskEventIdl>["hlpClosed"];
export type HlpCohort = IdlTypes<DuskAccountIdl>["hlpCohort"];
export type HlpCohortRotated = IdlTypes<DuskEventIdl>["hlpCohortRotated"];
export type HlpOpened = IdlTypes<DuskEventIdl>["hlpOpened"];
export type HlpRebalanced = IdlTypes<DuskEventIdl>["hlpRebalanced"];
export type HlpRetiredReceiptBurned = IdlTypes<DuskEventIdl>["hlpRetiredReceiptBurned"];
export type LiquidationAuctionCancelled = IdlTypes<DuskEventIdl>["liquidationAuctionCancelled"];
export type LiquidationAuctionStarted = IdlTypes<DuskEventIdl>["liquidationAuctionStarted"];
export type LiquidityAdded = IdlTypes<DuskEventIdl>["liquidityAdded"];
export type LiquidityRemoved = IdlTypes<DuskEventIdl>["liquidityRemoved"];
export type LpTransferred = IdlTypes<DuskEventIdl>["lpTransferred"];
export type MarketCollateralDeposited = IdlTypes<DuskEventIdl>["marketCollateralDeposited"];
export type MarketCollateralWithdrawn = IdlTypes<DuskEventIdl>["marketCollateralWithdrawn"];
export type MarketCreated = IdlTypes<DuskEventIdl>["marketCreated"];
export type MarketDebtUpdated = IdlTypes<DuskEventIdl>["marketDebtUpdated"];
export type MarketHealthUpdated = IdlTypes<DuskEventIdl>["marketHealthUpdated"];
export type MarketReduceOnlyUpdated = IdlTypes<DuskEventIdl>["marketReduceOnlyUpdated"];





export type BorrowPositionLiquidated = IdlTypes<DuskEventIdl>["borrowPositionLiquidated"];
export type BorrowInterestAccrued = IdlTypes<DuskEventIdl>["borrowInterestAccrued"];
export type BorrowInterestPaid = IdlTypes<DuskEventIdl>["borrowInterestPaid"];
export type DebtSource = BorrowInterestPaid["source"];
export type LeveragePositionOpened = IdlTypes<DuskEventIdl>["leveragePositionOpened"];
export type LeveragePositionUpdated = IdlTypes<DuskEventIdl>["leveragePositionUpdated"];
export type LeveragePositionClosed = IdlTypes<DuskEventIdl>["leveragePositionClosed"];
export type LeveragePositionLiquidated = IdlTypes<DuskEventIdl>["leveragePositionLiquidated"];
export type ProtocolAuctionState = IdlTypes<DuskAccountIdl>["protocolAuctionState"];
export type ProtocolAuctionConfigured = IdlTypes<DuskEventIdl>["protocolAuctionConfigured"];
export type ProtocolAuctionSettled = IdlTypes<DuskEventIdl>["protocolAuctionSettled"];
export type ReferralBound = IdlTypes<DuskEventIdl>["referralBound"];
export type ReferralPartnerConfigured = IdlTypes<DuskEventIdl>["referralPartnerConfigured"];
export type ReferralInterestAccrued = IdlTypes<DuskEventIdl>["referralInterestAccrued"];
export type ReferralInterestClaimed = IdlTypes<DuskEventIdl>["referralInterestClaimed"];
export type ReferralInterestShareCapUpdated = IdlTypes<DuskEventIdl>["referralInterestShareCapUpdated"];
export type ReferralRecipientUpdated = IdlTypes<DuskEventIdl>["referralRecipientUpdated"];
export type SwapExecuted = IdlTypes<DuskEventIdl>["swapExecuted"];
export type SwapOrigin = SwapExecuted["origin"];
export type MarketSideSnapshot = SwapExecuted["base"];
export type YieldClaimed = IdlTypes<DuskEventIdl>["yieldClaimed"];
export type YieldRecipientUpdated = IdlTypes<DuskEventIdl>["yieldRecipientUpdated"];

export type LiquidationHealth = IdlTypes<DuskAccountIdl>["liquidationHealth"];
export type LiquidationSession = IdlTypes<DuskAccountIdl>["liquidationSession"];
export type FlashLiquidationBegun = IdlTypes<DuskEventIdl>["flashLiquidationBegun"];
export type FlashLiquidationSettled = IdlTypes<DuskEventIdl>["flashLiquidationSettled"];
export type EmergencyLiquidationSettled = IdlTypes<DuskEventIdl>["emergencyLiquidationSettled"];






export type HlpFlashSession = IdlTypes<DuskAccountIdl>["hlpFlashSession"];
export type HlpFlashStarted = IdlTypes<DuskEventIdl>["hlpFlashStarted"];
export type HlpFlashSettled = IdlTypes<DuskEventIdl>["hlpFlashSettled"];
export type HlpInterestAllocated = IdlTypes<DuskEventIdl>["hlpInterestAllocated"];
export type PublicInterestFunded = IdlTypes<DuskEventIdl>["publicInterestFunded"];

export type JuniorSeedCompounded = IdlTypes<DuskEventIdl>["juniorSeedCompounded"];
export type JuniorCohortInitialized = IdlTypes<DuskEventIdl>["juniorCohortInitialized"];
export type JuniorSeedFunded = IdlTypes<DuskEventIdl>["juniorSeedFunded"];
export type RetiredJuniorBurned = IdlTypes<DuskEventIdl>["retiredJuniorBurned"];
export type TrancheConverted = IdlTypes<DuskEventIdl>["trancheConverted"];








export type OperatorProposal = IdlTypes<DuskAccountIdl>["operatorProposal"];
export type OperatorState = IdlTypes<DuskAccountIdl>["operatorState"];
export type ManagerChanged = IdlTypes<DuskEventIdl>["managerChanged"];
export type OperatorChanged = IdlTypes<DuskEventIdl>["operatorChanged"];
export type OperatorChangeAnnounced = IdlTypes<DuskEventIdl>["operatorChangeAnnounced"];
export type OperatorChangeResolved = IdlTypes<DuskEventIdl>["operatorChangeResolved"];

export type OperatorRevenueAccount=IdlTypes<DuskAccountIdl>["operatorRevenueAccount"];
