import { DuskTranches } from "./tranche-client.js";
import type { AnchorProvider, Program } from "@coral-xyz/anchor";
import type { Connection } from "@solana/web3.js";

import { type AddressLike } from "./address.js";
import { DuskGet } from "./get.js";
import { DuskIndexerClient, type FetchLike } from "./indexer.js";
import { createDuskProgram } from "./program.js";
import type { Dusk as DuskIdl } from "./types_v2.js";
import { DuskOperator } from "./operator-client.js";
import { DuskWrite } from "./write.js";
import { DuskHlpLiquidations } from "./hlp-liquidation-client.js";
import { DuskYield } from "./yield-client.js";
import { DuskLiquidations } from "./liquidation-client.js";
import {
  createLeverageDelegateProgram,
  DuskLeverageOrders,
} from "./delegate.js";

export interface DuskOptions {
  program?: Program<DuskIdl>;
  provider?: AnchorProvider;
  connection?: Connection;
  programId?: AddressLike;
  feePayer?: AddressLike;
  indexerBaseUrl?: string;
  fetch?: FetchLike;
  leverageDelegateProgramId?: AddressLike;
}

export class Dusk {
  readonly program: Program<DuskIdl>;
  readonly get: DuskGet;
  readonly write: DuskWrite;
  readonly operator: DuskOperator;
  readonly liquidations: DuskLiquidations;
  readonly yield: DuskYield;
  readonly tranches: DuskTranches;
  readonly hlpLiquidations: DuskHlpLiquidations;
  readonly fetch: DuskIndexerClient;
  /**
   * Orders in the leverage-delegate program: typed conditional-exit builders
   * and a checked generic path for every delegate instruction.
   */
  readonly orders: DuskLeverageOrders;

  constructor(options: DuskOptions = {}) {
    this.program =
      options.program ??
      createDuskProgram({
        provider: options.provider,
        connection: options.connection,
        programId: options.programId,
      });

    this.get = new DuskGet(this.program, options.feePayer);
    this.write = new DuskWrite(this.program);
    this.operator = new DuskOperator(this.program);
    this.liquidations = new DuskLiquidations(this.program, options.feePayer);
    this.hlpLiquidations = new DuskHlpLiquidations(this.program, options.feePayer);
    this.yield = new DuskYield(this.program, options.feePayer);
    this.tranches = new DuskTranches(this.program);
    this.fetch = new DuskIndexerClient({
      baseUrl: options.indexerBaseUrl,
      fetch: options.fetch,
    });
    this.orders = new DuskLeverageOrders(
      createLeverageDelegateProgram({
        provider: this.program.provider as AnchorProvider,
        programId: options.leverageDelegateProgramId,
      })
    );
  }
}
