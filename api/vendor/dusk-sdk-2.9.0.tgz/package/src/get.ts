import type { BN, Program } from "@coral-xyz/anchor";
import {
  ComputeBudgetProgram,
  PublicKey,
  Transaction,
  VersionedTransaction,
  type Commitment,
  type TransactionInstruction,
} from "@solana/web3.js";

/**
 * Previews are simulated, so the budget costs nothing unless it is used, and
 * the default 200,000 units is not enough for the heavier ones.
 */
const DEFAULT_PREVIEW_COMPUTE_UNITS = 1_400_000;
const DEFAULT_PREVIEW_HEAP_FRAME_BYTES = 256 * 1024;

import {
  deriveBorrowPositionAddress,
  deriveFutarchyAuthorityAddress,
  deriveHlpYlpVaultAddress,
  deriveInsuranceAddress,
  deriveLeveragePositionAddress,
  deriveMarketAddress,
  deriveMarketCollateralVaultAddress,
  deriveMarketInterestVaultAddress,
  deriveMarketReserveVaultAddress,
  deriveParameterProposalAddress,
  deriveProposalSupportAddress,
  deriveReferralAccrualAddress,
  deriveReferralPartnerAddress,
  deriveTokenMetadataAddress,
  deriveYieldAccountAddress,
  deriveYieldTransferHookValidationAddress,
  type U64SeedLike,
} from "./constants.js";
import { address, DEFAULT_READONLY_PUBLIC_KEY, normalizeAccountKeys, type AddressLike } from "./address.js";
import {
  decodePreviewAddLiquidityReturnData,
  decodePreviewBorrowCapacityReturnData,
  decodePreviewBorrowPositionReturnData,
  decodePreviewBorrowPositionCapacityReturnData,
  decodePreviewMarketReturnData,
  decodePreviewSwapReturnData,
  type AddLiquidityPreview,
  type BorrowCapacityPreview,
  type BorrowPositionPreview,
  type BorrowPositionCapacityPreview,
  type MarketPreview,
  type PreviewReturnData,
  type SwapPreview,
} from "./preview.js";
import type {
  BorrowPosition,
  FutarchyAuthority,
  LeverageDelegation,
  LeveragePosition,
  Market,
  ParameterProposal,
  ProposalSupport,
  ReferralAccrual,
  ReferralPartner,
  YieldAccount,
} from "./type-aliases.js";
import type { Dusk } from "./types_v2.js";

export const pda = {
  futarchyAuthority: deriveFutarchyAuthorityAddress,
  market: deriveMarketAddress,
  tokenMetadata: deriveTokenMetadataAddress,
  marketReserveVault: deriveMarketReserveVaultAddress,
  marketCollateralVault: deriveMarketCollateralVaultAddress,
  marketInterestVault: deriveMarketInterestVaultAddress,
  borrowPosition: deriveBorrowPositionAddress,
  leveragePosition: deriveLeveragePositionAddress,
  yieldAccount: deriveYieldAccountAddress,
  yieldTransferHookValidation: deriveYieldTransferHookValidationAddress,
  hlpYlpVault: deriveHlpYlpVaultAddress,
  insurance: deriveInsuranceAddress,
  referralPartner: deriveReferralPartnerAddress,
  referralAccrual: deriveReferralAccrualAddress,
  parameterProposal: deriveParameterProposalAddress,
  proposalSupport: deriveProposalSupportAddress,
} as const;

export interface SimulateOptions {
  feePayer?: AddressLike;
  commitment?: Commitment;
  /**
   * Compute units to request. The default 200,000 is not enough for the
   * heavier previews -- borrow capacity exhausts it and returns no data at
   * all, which reads as "the program returned nothing" rather than as a
   * budget problem. Raised well above what any preview needs, because a
   * simulation pays only for what it consumes.
   */
  computeUnitLimit?: number;
  /** Heap for previews that build large intermediate state. */
  heapFrameBytes?: number;
}

export interface PreviewSwapParams extends SimulateOptions {
  market: AddressLike;
  futarchyAuthority?: AddressLike;
  assetInMint: AddressLike;
  assetOutMint: AddressLike;
  exactAssetIn: BN;
}

export interface PreviewAddLiquidityParams extends SimulateOptions {
  market: AddressLike;
  baseMint: AddressLike;
  quoteMint: AddressLike;
  baseDepositAmount: BN;
  quoteDepositAmount: BN;
}

export interface PreviewBorrowCapacityParams extends SimulateOptions {
  market: AddressLike;
  collateralAssetMint: AddressLike;
  debtAssetMint: AddressLike;
  collateralAmount: BN;
  /**
   * Candidate debt amount used for the returned CF and health fields. When
   * omitted, the program quotes at maximum borrow capacity.
   */
  projectedBorrowAmount?: BN | null;
}

export interface PreviewBorrowPositionCapacityParams extends SimulateOptions {
  capacityKind: "borrow" | "withdraw";
  market: AddressLike;
  borrowPosition: AddressLike;
  collateralAssetMint: AddressLike;
  debtAssetMint: AddressLike;
  /** Net credit after transfer fees, or negative collateral vault debit. */
  collateralChange: BN;
  /** Additional debt; omit for maximum additional capacity. */
  projectedBorrowAmount?: BN | null;
}

export interface PreviewBorrowPositionParams extends SimulateOptions {
  market: AddressLike;
  borrowPosition: AddressLike;
}

export class DuskSimulationError extends Error {
  constructor(
    message: string,
    readonly simulation: Awaited<ReturnType<Program<Dusk>["provider"]["connection"]["simulateTransaction"]>>
  ) {
    super(message);
    this.name = "DuskSimulationError";
  }
}

export class DuskGet {
  readonly pda = pda;

  constructor(
    readonly program: Program<Dusk>,
    private readonly defaultFeePayer: AddressLike = DEFAULT_READONLY_PUBLIC_KEY
  ) {}

  async accountInfo(account: AddressLike, commitment?: Commitment) {
    return this.program.provider.connection.getAccountInfo(address(account), commitment);
  }

  async programAccount<T = unknown>(name: string, account: AddressLike): Promise<T> {
    const client = (
      this.program.account as unknown as Record<string, { fetch(address: PublicKey): Promise<T> }>
    )[name];
    if (!client) {
      throw new Error(`Unknown Dusk account type: ${name}`);
    }
    return client.fetch(address(account));
  }

  market(account: AddressLike): Promise<Market> {
    return this.program.account.market.fetch(address(account));
  }

  borrowPosition(account: AddressLike): Promise<BorrowPosition> {
    return this.program.account.borrowPosition.fetch(address(account));
  }

  leveragePosition(account: AddressLike): Promise<LeveragePosition> {
    return this.program.account.leveragePosition.fetch(address(account));
  }

  leverageDelegation(account: AddressLike): Promise<LeverageDelegation> {
    return this.program.account.leverageDelegation.fetch(address(account));
  }

  yieldAccount(account: AddressLike): Promise<YieldAccount> {
    return this.program.account.yieldAccount.fetch(address(account));
  }

  futarchyAuthority(account: AddressLike = deriveFutarchyAuthorityAddress()[0]): Promise<FutarchyAuthority> {
    return this.program.account.futarchyAuthority.fetch(address(account));
  }

  referralPartner(account: AddressLike): Promise<ReferralPartner> {
    return this.program.account.referralPartner.fetch(address(account));
  }

  referralAccrual(account: AddressLike): Promise<ReferralAccrual> {
    return this.program.account.referralAccrual.fetch(address(account));
  }

  parameterProposal(account: AddressLike): Promise<ParameterProposal> {
    return this.program.account.parameterProposal.fetch(address(account));
  }

  proposalSupport(account: AddressLike): Promise<ProposalSupport> {
    return this.program.account.proposalSupport.fetch(address(account));
  }

  parameterProposalFor(
    market: AddressLike,
    proposer: AddressLike,
    nonce: U64SeedLike
  ): Promise<ParameterProposal> {
    const [proposal] = deriveParameterProposalAddress(
      address(market),
      address(proposer),
      nonce,
      this.program.programId
    );
    return this.parameterProposal(proposal);
  }

  proposalSupportFor(
    proposal: AddressLike,
    supporter: AddressLike
  ): Promise<ProposalSupport> {
    const [support] = deriveProposalSupportAddress(
      address(proposal),
      address(supporter),
      this.program.programId
    );
    return this.proposalSupport(support);
  }

  allMarkets() {
    return this.program.account.market.all();
  }

  allBorrowPositions() {
    return this.program.account.borrowPosition.all();
  }

  allLeveragePositions() {
    return this.program.account.leveragePosition.all();
  }

  allReferralPartners() {
    return this.program.account.referralPartner.all();
  }

  allReferralAccruals() {
    return this.program.account.referralAccrual.all();
  }

  allParameterProposals() {
    return this.program.account.parameterProposal.all();
  }

  allProposalSupports() {
    return this.program.account.proposalSupport.all();
  }

  async previewMarket(market: AddressLike, options: SimulateOptions = {}): Promise<MarketPreview> {
    const instruction = await this.program.methods
      .previewMarket()
      .accounts(normalizeAccountKeys({ market }))
      .instruction();

    return decodePreviewMarketReturnData(await this.simulateReturnData(instruction, options));
  }

  async previewAddLiquidity(params: PreviewAddLiquidityParams): Promise<AddLiquidityPreview> {
    const instruction = await this.program.methods
      .previewAddLiquidity({
        baseDepositAmount: params.baseDepositAmount,
        quoteDepositAmount: params.quoteDepositAmount,
      })
      .accounts(
        normalizeAccountKeys({
          market: params.market,
          baseMint: params.baseMint,
          quoteMint: params.quoteMint,
        })
      )
      .instruction();

    return decodePreviewAddLiquidityReturnData(
      await this.simulateReturnData(instruction, params)
    );
  }

  async previewSwap(params: PreviewSwapParams): Promise<SwapPreview> {
    const instruction = await this.program.methods
      .previewSwap({
        exactAssetIn: params.exactAssetIn,
      })
      .accounts(
        normalizeAccountKeys({
          market: params.market,
          futarchyAuthority:
            params.futarchyAuthority ?? deriveFutarchyAuthorityAddress()[0],
          assetInMint: params.assetInMint,
          assetOutMint: params.assetOutMint,
        })
      )
      .instruction();

    return decodePreviewSwapReturnData(await this.simulateReturnData(instruction, params));
  }

  async previewBorrowCapacity(
    params: PreviewBorrowCapacityParams
  ): Promise<BorrowCapacityPreview> {
    const instruction = await this.program.methods
      .previewBorrowCapacity({
        collateralAmount: params.collateralAmount,
        projectedBorrowAmount: params.projectedBorrowAmount ?? null,
      })
      .accounts(
        normalizeAccountKeys({
          market: params.market,
          collateralAssetMint: params.collateralAssetMint,
          debtAssetMint: params.debtAssetMint,
        })
      )
      .instruction();

    return decodePreviewBorrowCapacityReturnData(await this.simulateReturnData(instruction, params));
  }

  async previewBorrowPositionCapacity(
    params: PreviewBorrowPositionCapacityParams
  ): Promise<BorrowPositionCapacityPreview> {
    const instruction = await this.program.methods
      .previewBorrowPositionCapacity({
        capacityKind: params.capacityKind === "borrow" ? { borrow: {} } : { withdraw: {} },
        collateralChange: params.collateralChange,
        projectedBorrowAmount: params.projectedBorrowAmount ?? null,
      })
      .accounts(
        normalizeAccountKeys({
          market: params.market,
          borrowPosition: params.borrowPosition,
          collateralAssetMint: params.collateralAssetMint,
          debtAssetMint: params.debtAssetMint,
        })
      )
      .instruction();

    return decodePreviewBorrowPositionCapacityReturnData(await this.simulateReturnData(instruction, params));
  }

  async previewBorrowPosition(params: PreviewBorrowPositionParams): Promise<BorrowPositionPreview> {
    const instruction = await this.program.methods
      .previewBorrowPosition()
      .accounts(
        normalizeAccountKeys({
          market: params.market,
          borrowPosition: params.borrowPosition,
        })
      )
      .instruction();

    return decodePreviewBorrowPositionReturnData(await this.simulateReturnData(instruction, params));
  }

  async simulateReturnData(
    instruction: TransactionInstruction,
    options: SimulateOptions = {}
  ): Promise<PreviewReturnData> {
    const tx = new Transaction().add(
      ComputeBudgetProgram.requestHeapFrame({
        bytes: options.heapFrameBytes ?? DEFAULT_PREVIEW_HEAP_FRAME_BYTES,
      }),
      ComputeBudgetProgram.setComputeUnitLimit({
        units: options.computeUnitLimit ?? DEFAULT_PREVIEW_COMPUTE_UNITS,
      }),
      instruction
    );
    tx.feePayer = address(options.feePayer ?? this.program.provider.publicKey ?? this.defaultFeePayer);
    // The simulation bank supplies the blockhash. The legacy Transaction
    // overload replaces caller-provided hashes with web3's cached hash, which
    // can expire before its cache refreshes on devnet. A legacy message inside
    // VersionedTransaction uses the config overload without changing accounts
    // or instructions, and avoids a separate blockhash RPC request.
    tx.recentBlockhash = PublicKey.default.toBase58();
    const connection = this.program.provider.connection;
    const simulation = await connection.simulateTransaction(
      new VersionedTransaction(tx.compileMessage()),
      {
        commitment: options.commitment ?? connection.commitment,
        sigVerify: false,
        replaceRecentBlockhash: true,
      }
    );
    if (simulation.value.err) {
      throw new DuskSimulationError("Dusk simulation failed", simulation);
    }
    if (!simulation.value.returnData) {
      throw new DuskSimulationError("Dusk simulation did not return data", simulation);
    }
    if (simulation.value.returnData.programId !== this.program.programId.toBase58()) {
      throw new DuskSimulationError("Dusk simulation returned data from a different program", simulation);
    }
    return simulation.value.returnData;
  }
}
